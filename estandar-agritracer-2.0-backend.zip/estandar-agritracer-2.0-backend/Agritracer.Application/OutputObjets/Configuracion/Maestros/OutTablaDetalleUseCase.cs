﻿
namespace Agritracer.Application.OutputObjets.Configuracion.Maestros
{
    public class OutTablaDetalleUseCase
    {
        public int statusOutputTablaDetalle { get; set; }
        public string messageOutputTablaDetalle { get; set; }
    }
}
