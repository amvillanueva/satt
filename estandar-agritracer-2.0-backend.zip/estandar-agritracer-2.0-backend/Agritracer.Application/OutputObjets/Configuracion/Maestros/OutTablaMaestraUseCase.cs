﻿
namespace Agritracer.Application.OutputObjets.Configuracion.Maestros
{
    public class OutTablaMaestraUseCase
    {
        public int statusOutputTablaMaestra { get; set; }
        public string messageOutputTablaMaestra { get; set; }
    }
}
