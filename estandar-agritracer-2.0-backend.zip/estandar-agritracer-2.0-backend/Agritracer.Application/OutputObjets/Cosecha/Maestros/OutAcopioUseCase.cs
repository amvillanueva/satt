﻿
namespace Agritracer.Application.OutputObjets.Cosecha.Maestros
{
    public class OutAcopioUseCase
    {
        public int statusOutputAcopio { get; set; }
        public string messageOutputAcopio { get; set; }
    }
}
