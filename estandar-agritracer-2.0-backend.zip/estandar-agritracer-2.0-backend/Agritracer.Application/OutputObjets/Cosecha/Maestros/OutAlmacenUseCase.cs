﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Application.OutputObjets.Cosecha.Maestros
{
    public class OutAlmacenUseCase
    {
        public int statusOutputAlmacen { get; set; }
        public string messageOutputAlmacen { get; set; }
    }
}
