﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Application.OutputObjets.Cosecha.Maestros
{
    public class OutBandejaCosechaUseCase
    {
        public int statusOutputBandejaCosecha { get; set; }
        public string messageOutputBandejaCosecha { get; set; }
    }
}
