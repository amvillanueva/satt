﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Application.OutputObjets.Cosecha.Maestros
{
    public class OutCampaniaUseCase
    {
        public int statusOutputCampania { get; set; }
        public string messageOutputCampania { get; set; }
    }
}
