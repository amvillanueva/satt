﻿
namespace Agritracer.Application.OutputObjets.Cosecha.Maestros
{
    public class OutCultivoUseCase
    {
        public int statusOutputCultivo { get; set; }
        public string messageOutputCultivo { get; set; }
    }
}
