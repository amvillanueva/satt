﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Application.OutputObjets.Cosecha.Maestros
{
    public class OutEmpresaUseCase
    {
        public int statusOutputEmpresa { get; set; }
        public string messageOutputEmpresa { get; set; }
    }
}
