﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Application.OutputObjets.Cosecha.Maestros
{
    public class OutFundoUseCase
    {
        public int statusOutputFundo { get; set; }
        public string messageOutputFundo { get; set; }
    }
}
