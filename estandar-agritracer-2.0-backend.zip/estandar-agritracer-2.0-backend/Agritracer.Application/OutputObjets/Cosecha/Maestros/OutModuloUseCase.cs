﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Application.OutputObjets.Cosecha.Maestros
{
    public class OutModuloUseCase
    {
        public int statusOutputModulo { get; set; }
        public string messageOutputModulo { get; set; }
    }
}
