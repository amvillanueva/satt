﻿
namespace Agritracer.Application.OutputObjets.Cosecha.Maestros
{
    public class OutVehiculoUseCase
    {
        public int statusOutputVehiculo { get; set; }
        public string messageOutputVehiculo { get; set; }
    }
}
