﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Application.OutputObjets.Cosecha.Procesos
{
    public class OutGuiaRemisionCampoUseCase
    {
        public int statusOutputGuiaRemisionCampo { get; set; }
        public string messageOutputGuiaRemisionCampo { get; set; }
    }
}
