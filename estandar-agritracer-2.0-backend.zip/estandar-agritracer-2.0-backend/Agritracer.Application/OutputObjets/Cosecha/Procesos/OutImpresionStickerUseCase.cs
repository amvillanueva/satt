﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Application.OutputObjets.Cosecha.Procesos
{
    public class OutImpresionStickerUseCase
    {
        public int statusOutputImpresionSticker { get; set; }
        public string messageOutputImpresionSticker { get; set; }
    }
}
