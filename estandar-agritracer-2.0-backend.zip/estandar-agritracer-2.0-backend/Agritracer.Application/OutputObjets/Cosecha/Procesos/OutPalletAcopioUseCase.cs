﻿
namespace Agritracer.Application.OutputObjets.Cosecha.Procesos
{
    public class OutPalletAcopioUseCase
    {
        public int statusOutputPalletAcopio { get; set; }
        public string messageOutputPalletAcopio { get; set; }
    }
}
