﻿
namespace Agritracer.Application.OutputObjets.ManoObra.Maestros
{
    public class OutGrupoTrabajoDetalleUseCase
    {
        public int statusOutputGrupoTrabajoDetalle { get; set; }
        public string messageOutputGrupoTrabajoDetalle { get; set; }
    }
}
