﻿
namespace Agritracer.Application.OutputObjets.ManoObra.Maestros
{
    public class OutGrupoTrabajoUseCase
    {
        public int statusOutputGrupoTrabajo { get; set; }
        public string messageOutputGrupoTrabajo { get; set; }
    }
}
