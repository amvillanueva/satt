﻿
namespace Agritracer.Application.OutputObjets.ManoObra.Maestros
{
    public class OutTrabajadorUseCase
    {
        public int statusOutputTrabajador { get; set; }
        public string messageOutputTrabajador { get; set; }
    }
}
