﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Application.OutputObjets
{
    public sealed class OutUsuarioUseCase
    {
        public int keyOutputUsuario { get; set; }
        public string loginOutputUsuario { get; set; }  
        public string passwordOutputUsuario { get; set; }
        public int statusOutputUsuario { get; set; }
        public string messageOutputUsuario { get; set; }
    }
}
