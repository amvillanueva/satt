﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Acopio;
using Agritracer.Domain.Acopio.Movil;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Acopio.Movil
{
    public interface IAcopioRepository
    {
        Task<OutResultData<BEDataMaestraAcopio>> GetDataMaestra(BEArgs args);
        Task<OutResultData<List<BEDashboardAcopio>>> GetDashboard(BEArgs args);
        Task<OutResultData<List<BEDespachoCosecha>>> SincronizarDespachoCosecha(List<BEDespachoCosecha> despachoCosechaList);
        Task<OutResultData<string>> SincronizarDespachoIndustrial(List<BEDespachoIndustrial> despachoIndustrialList);
        Task<OutResultData<List<BEDespachoIndustrial>>> GetDespachoIndustrial(BEArgs args);
        Task<OutResultData<List<BERecepcionAcopioCabecera>>> GetDespachoAcopioPrincipal(BEArgs args);
        Task<OutResultData<List<BEDespachoCosecha>>> GetRecepcionesGalera(BEArgs args);
        Task<OutResultData<string>> UpdateRecepcionGalera(BEDespachoCosecha recepcionGalera);
        Task<OutResultData<List<BEDespachoGalera>>> SincronizarDespachoGalera(List<BEDespachoGalera> despachoGaleraList);
        Task<OutResultData<List<BERecepcionAcopio>>> GetRecepcionesAcopio(BEArgs args);
        Task<OutResultData<List<BERecepcionDespachoCosechaI>>> GetRecepcionesIndustrial(BEArgs args);
        Task<OutResultData<string>> UpdateRecepcionIndustrial(BERecepcionIndustrial recepcionIndustrial);
        
        //PRUEBA
        Task<OutResultData<string>> UpdateRecepcionAcopioAPI(BERecepcionAcopioCabecera recepcionAcopioCabecera);

        //Task<OutResultData<string>> UpdateRecepcionAcopio(BERecepcionAcopio recepcionAcopio);

        Task<OutResultData<List<BEPallet>>> SincronizarPallets(List<BEPallet> palletList);
        Task<OutResultData<List<BEDespachoAcopio>>> SincronizarDespachoAcopio(List<BEDespachoAcopio> despachoAcopioList);
        Task<OutResultData<string>> SincronizarDespachoIndustrialAcopio(List<BEDespachoIndustrialAcopio> despachoIndustrialAcopioList);
    }
}
