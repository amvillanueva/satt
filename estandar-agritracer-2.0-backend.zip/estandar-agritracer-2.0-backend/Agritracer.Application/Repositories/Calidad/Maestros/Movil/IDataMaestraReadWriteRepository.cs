﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.OutputObjets.calidad;
using Agritracer.Domain.Calidad;
using Agritracer.Domain.Calidad.Maestros.Movil;
using System;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Calidad.Maestros.Movil
{
    public interface IDataMaestraReadWriteRepository
    {
        Task<OutResultData<BEDataMaestra>> GetBy(int empresaId, int usuarioCodigo);
        Task<ResultJSONData<BEQRLecturar>> DataQR(String qrLecturado);
    }
}
