﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Calidad;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Calidad.Maestros.Web
{
    public interface IAgrupadorRepository
    {
        Task<OutResultData<List<BEAgrupador>>> GetById(int id);
        Task<OutResultData<List<BEAgrupador>>> GetAll(BEArgs args);
        Task<OutResultData<BEAgrupador>> InsertUpdate(BEAgrupador objeto, int accion);
        Task<OutResultData<bool>> DeleteAllSelected(BEArgs args);
        Task<OutResultData<DataTable>> GetTipoConfig(BEArgs args);
    }
}
