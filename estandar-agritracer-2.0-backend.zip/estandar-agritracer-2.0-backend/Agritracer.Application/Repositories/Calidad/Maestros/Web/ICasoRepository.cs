﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Calidad;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Calidad.Maestros.Web
{
    public interface ICasoRepository
    {
        Task<OutResultData<List<BECasoDetalle>>> GetById(int id);
        Task<OutResultData<List<BECaso>>> GetAll(BEArgs args);
        Task<OutResultData<BECaso>> InsertUpdate(BECaso caso, int accion);
        Task<OutResultData<bool>> DeleteAllSelected(BEArgs args);
    }
}
