﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Calidad;
using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Calidad.Maestros.Web
{
    public interface IFormulaRepository
    {
        Task<OutResultData<List<BEFormula>>> GetById(int id);
        Task<OutResultData<List<BEFormula>>> GetAll(BEArgs args);
        Task<OutResultData<BEEvaluacion>> InsertUpdate(BEEvaluacion evaluacion);
        Task<OutResultData<bool>> DeleteAllSelected(BEArgs args);
    }
}
