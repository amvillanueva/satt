﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Calidad;
using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Calidad.Procesos.Web
{
    public interface IRegistroEvaluacionRepository
    {
        Task<OutResultData<BERegistroEvaluacion>> GetById(int id);
        Task<OutResultData<List<BERegistroEvaluacion>>> GetAll(BEArgs args);
        Task<OutResultData<List<BERegistroEvaluacionDetalle>>> GetDetails(int id);
        Task<OutResultData<bool>> Update(BERegistroEvaluacion registroEvaluacion);
        Task<OutResultData<bool>> DeleteAllSelected(BEArgs args);
        Task<OutResultData<DataSet>> ReportesPersonalizados(BEArgs args);
        Task<OutResultData<string>> ListadoUbicaciones(BEArgs args);
        Task<OutResultData<List<BERegistroEvaluacionDetalle>>> GetDatosMuestraItem(BEArgs args);
        Task<OutResultData<bool>> SaveMuestrasItem(BERegistroEvaluacion datos);
        Task<OutResultData<List<BERegistroEvaluacionDetalle>>> GetDatosMuestraIterativo(BEArgs args);
        Task<OutResultData<string>> RegistrarEvaluaciones(List<BERegistroEvaluacion> args, String pathFile);
        Task<OutResultData<List<BERegistroEvaluacion>>> ObtenerRegistrarEvaluaciones(String fecha);
    }
}
