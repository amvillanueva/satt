
﻿using System.Data;
using System.Threading.Tasks;

using Agritracer.Domain.Common;
using Agritracer.Application.OutputObjets;

using System;
using System.Collections.Generic;

using System.Text;


namespace Agritracer.Application.Repositories.Calidad.Reportes
{
    public interface IReportesRepository
    {
        Task<OutResultData<DataTable>> GetReporteGenericoCalidadDT(BEParams args);
        Task<OutResultData<DataSet>> GetReporteGenericoCalidadDS(BEParams args);
        Task<DataSet> GetReporteGenericoCalidad(BEParams args);
        Task<OutResultData<DataTable>> GetFotoInfomacion(string nombre, int id);
    }
}
