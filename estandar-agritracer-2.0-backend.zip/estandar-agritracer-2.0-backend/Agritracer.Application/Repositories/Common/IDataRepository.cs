﻿using System.Data;
using System.Collections.Generic;
using System.Threading.Tasks;
using Agritracer.Application.OutputObjets;

namespace Agritracer.Application.Repositories.Common
{
    public interface IDataRepository
    {
        Task<DataSet> GetDataSetResults(string spName, IDictionary<string, object> valuePairs);
        Task<DataTable> GetDataTableResults(string spName, IDictionary<string, object> valuePairs);
        OutUsuarioUseCase GetRespuesta(string mensaje);
    }
}
