﻿using System.Data;
using System.Threading.Tasks;

using Agritracer.Domain.Common;
using Agritracer.Application.OutputObjets;

namespace Agritracer.Application.Repositories.Common
{
    public interface ILoadExcelRepository
    {
        #region Restriccion Trabajador
        Task<OutResultData<DataSet>> ListadoDatosXLSX(string spName, string nroRegistro);
        Task<OutResultData<string>> ProcesaDatosXLSX(string spName, string nroRegistro);
        #endregion

        //------------------------------------------------------------------------------
        Task<OutResultData<string>> CargaDatosXLS(DataTable dtInfo, string tableName);
        //------------------------------------------------------------------------------

        Task<OutResultData<string>> ProcessDataXlsx(BEParams args);
        Task<OutResultData<BEFormatoXlsx>> ListResultXlsx(BEFormatoXlsx entity);

        Task<OutResultData<DataSet>> GetListFields(int formatoID);

    }
}
