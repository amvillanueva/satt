﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Common.Maestros;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Common
{
    public interface ITrabajadorRepository
    {
        Task<OutResultData<BETrabajador>> GetByCodigo(BEArgs args);
        Task<OutResultData<List<BETrabajador>>> GetAll(BEArgs args);
        Task<OutResultData<DataSet>> Importar(BEArgs args);
        Task<OutResultData<BETrabajador>> Procesar(BEArgs args);
    }
}
