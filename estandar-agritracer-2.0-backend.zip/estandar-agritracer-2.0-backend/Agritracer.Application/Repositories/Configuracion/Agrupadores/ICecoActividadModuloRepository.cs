﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Configuracion.Agrupadores;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Configuracion.Agrupadores
{
    public interface ICecoActividadModuloRepository
    {
        Task<OutResultData<BECecoActividadModulo>> GetById(int id);
        Task<OutResultData<List<BECecoActividadModulo>>> GetAll(BEArgs args);
        Task<OutResultData<BECecoActividadModulo>> InsUpdDel(BECecoActividadModulo objeto, int accion);
        Task<OutResultData<BECecoActividadModulo>> DeleteAllSelected(BEArgs args);
    }
}
