﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Agritracer.Domain.Configuracion.Maestros;

namespace Agritracer.Application.Repositories.Cosecha.Maestros
{
    public interface ICentroCostoReadWriteRepository
    {
        Task<BECentroCosto> GetByID(int id);
        Task<IEnumerable<BECentroCosto>> GetAll(int empresaID,string descripcion,int estado);
        Task<BECentroCosto> AddUpdate(BECentroCosto centrocosto);
        Task<BECentroCosto> Delete(List<int> centrocosto);
    }
}
