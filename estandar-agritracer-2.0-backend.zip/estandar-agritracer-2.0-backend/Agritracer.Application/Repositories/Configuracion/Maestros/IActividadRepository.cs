﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Configuracion.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Configuracion.Maestros
{
    public interface IActividadRepository
    {
        Task<OutResultData<BEActividad>> GetById(int id);
        Task<OutResultData<List<BEActividad>>> GetAll(BEArgs args);
        Task<OutResultData<BEActividad>> InsUpdDel(BEActividad objeto, int accion);
        Task<OutResultData<BEActividad>> DeleteAllSelected(BEArgs args);
    }
}
