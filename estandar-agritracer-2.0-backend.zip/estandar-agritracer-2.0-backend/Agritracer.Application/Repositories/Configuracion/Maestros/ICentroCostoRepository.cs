﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Configuracion.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Configuracion.Maestros
{
    public interface ICentroCostoRepository
    {
        Task<OutResultData<BECentroCosto>> GetById(int id);
        Task<OutResultData<List<BECentroCosto>>> GetAll(BEArgs args);
        Task<OutResultData<BECentroCosto>> InsUpdDel(BECentroCosto objeto, int accion);
        Task<OutResultData<BECentroCosto>> DeleteAllSelected(BEArgs args);
    }
}
