﻿using Agritracer.Domain.Configuracion.Maestros.Movil;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Configuracion.Maestros
{
    public interface ICultivoMovilReadWriteRepository
    {
        Task<IEnumerable<BECultivoMovil>> GetAll(int empresaID);
    }

}
