﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Configuracion.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Configuracion.Maestros
{
    public interface IGrupoActividadRepository
    {
        Task<OutResultData<BEGrupoActividad>> GetById(int id);
        Task<OutResultData<List<BEGrupoActividad>>> GetAll(BEArgs args);
        Task<OutResultData<BEGrupoActividad>> InsUpdDel(BEGrupoActividad objeto, int accion);
        Task<OutResultData<BEGrupoActividad>> DeleteAllSelected(BEArgs args);
    }
}
