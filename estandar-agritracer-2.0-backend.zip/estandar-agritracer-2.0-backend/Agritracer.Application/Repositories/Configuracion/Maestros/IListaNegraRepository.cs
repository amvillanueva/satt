﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Configuracion.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Configuracion.Maestros
{
    public interface IListaNegraRepository
    {
        Task<OutResultData<BEListaNegra>> GetById(int id);
        Task<OutResultData<List<BEListaNegra>>> GetAll(BEArgs args);
        Task<OutResultData<BEListaNegra>> InsUpdDel(BEListaNegra objeto, int accion);
        Task<OutResultData<BEListaNegra>> DeleteAllSelected(BEArgs args);
    }
}
