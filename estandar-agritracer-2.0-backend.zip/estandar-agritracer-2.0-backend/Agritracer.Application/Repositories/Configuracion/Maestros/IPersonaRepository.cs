﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Configuracion.Maestros;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Configuracion.Maestros
{
    public interface IPersonaRepository
    {
        Task<OutResultData<BEPersona>> GetById(int id);
        Task<OutResultData<DataTable>> GetListaNegraTrabajador(int idTrabajador);
        Task<OutResultData<List<BEPersona>>> GetAll(BEArgs args);
        Task<OutResultData<BEPersona>> InsUpdDel(BEPersona objeto, int accion);
        Task<OutResultData<BEPersona>> DeleteAllSelected(BEArgs args);
        Task<OutResultData<List<BETrabajadorPersona>>> GetTrabajadores(BEArgs args);
        Task<OutResultData<DataSet>> Importar(BEArgs args);
        Task<OutResultData<BEPersona>> Procesar(BEArgs args);
    }
}
