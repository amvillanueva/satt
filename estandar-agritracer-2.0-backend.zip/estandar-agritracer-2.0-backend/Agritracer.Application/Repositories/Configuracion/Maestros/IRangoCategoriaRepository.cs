﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Configuracion.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Configuracion.Maestros
{
    public interface IRangoCategoriaRepository
    {
        Task<OutResultData<BERangoCategoria>> GetById(int id);
        Task<OutResultData<List<BERangoCategoria>>> GetAll(BEArgs args);
        Task<OutResultData<BERangoCategoria>> InsUpdDel(BERangoCategoria rangoCategoria, int accion);
        Task<OutResultData<BERangoCategoria>> DeleteAllSelected(BEArgs args);
    }
}
