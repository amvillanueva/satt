﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Configuracion.Maestros;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Configuracion.Maestros
{
   public interface IRangoVariedadRepository
    {
        Task<OutResultData<BERangoVariedad>> GetById(int id);
        Task<OutResultData<List<BERangoVariedad>>> GetAll(int consulta, int modulo, int variedad);
        Task<OutResultData<BERangoVariedad>> InsUpdDel(BERangoVariedad entity, int accion);
        Task<OutResultData<BERangoVariedad>> DeleteAllSelected(BEArgs args);
    }
}
