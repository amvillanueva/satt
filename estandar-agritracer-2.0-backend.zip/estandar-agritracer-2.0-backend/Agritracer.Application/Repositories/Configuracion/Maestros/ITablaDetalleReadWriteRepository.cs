﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Agritracer.Domain.Configuracion.Maestros;

namespace Agritracer.Application.Repositories.Configuracion.Maestros
{
    public interface ITablaDetalleReadWriteRepository
    {
        Task<BETablaDetalle> GetByID(int idPadre, int idHijo);
        Task<IEnumerable<BETablaDetalle>> GetAll(int idPadre);
    }
}
