﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Agritracer.Application.OutputObjets.Configuracion.Maestros;
using Agritracer.Domain.Configuracion.Maestros;

namespace Agritracer.Application.Repositories.Configuracion.Maestros
{
    public interface ITablaMaestraReadWriteRepository
    {
        Task<BETablaMaestra> GetByID(int id);
        Task<IEnumerable<BETablaMaestra>> GetAll();
        Task<BETablaMaestra> AddUpdate(BETablaMaestra maestra);
        Task<OutTablaMaestraUseCase> Delete(List<int> maestras);
    }
}
