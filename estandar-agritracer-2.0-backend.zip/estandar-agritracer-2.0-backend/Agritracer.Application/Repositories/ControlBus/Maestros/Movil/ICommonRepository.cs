﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ControlBus;
using Agritracer.Domain.ControlBus.Movil;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ControlBus.Maestros.Movil
{
    public interface ICommonRepository
    {
        Task<OutResultData<BEDataMaestra>> DataMaestra(int IdUsuario, int IdEmpresa);
        Task<OutResultData<BEViajeDetalle>> DatosPasajero(string CodTrabajador, int IdEmpresa);
        Task<OutResultData<List<BEViajeDetalle>>> DatosPasajerosList(List<BEViajeDetalle> listViajeDetalle);
    }
}
