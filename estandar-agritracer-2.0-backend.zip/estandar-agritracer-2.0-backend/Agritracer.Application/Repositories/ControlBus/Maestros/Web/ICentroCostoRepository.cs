﻿
using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ControlBus.Maestros.Web
{
    public interface ICentroCostoRepository
    {
        Task<OutResultData<List<BECentroCosto>>> GetAll(BEArgs args);
        Task<OutResultData<BECentroCosto>> InsertUpdate(BECentroCosto entity, int accion);
        Task<OutResultData<bool>> DeleteAllSelected(BEArgs args);
    }
}
