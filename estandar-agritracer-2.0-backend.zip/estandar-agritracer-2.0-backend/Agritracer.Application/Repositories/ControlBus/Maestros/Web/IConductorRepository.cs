﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ControlBus.Maestros
{
    public interface IConductorRepository
    {
        Task<OutResultData<BEConductor>> GetById(int id);
        Task<OutResultData<List<BEConductor>>> GetAll(BEArgs args);
        Task<OutResultData<BEConductor>> InsertUpdate(BEConductor entity, int accion);
        Task<OutResultData<bool>> DeleteAllSelected(BEArgs args);
        Task<OutResultData<BEConductor>> GestionUsuarios(BEConductor entity, int accion);
    }
}
