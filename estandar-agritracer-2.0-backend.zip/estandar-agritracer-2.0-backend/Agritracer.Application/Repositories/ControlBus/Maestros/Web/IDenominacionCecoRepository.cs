﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ControlBus.Maestros.Web
{
    public interface IDenominacionCecoRepository
    {
        Task<OutResultData<List<BEDenominacionCeco>>> GetAll(BEArgs args);
        Task<OutResultData<BEDenominacionCeco>> InsertUpdate(BEDenominacionCeco entity, int accion);
        Task<OutResultData<bool>> DeleteAllSelected(BEArgs args);
    }
}
