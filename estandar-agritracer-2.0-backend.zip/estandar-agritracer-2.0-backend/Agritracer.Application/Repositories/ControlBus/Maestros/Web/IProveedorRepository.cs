﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using Agritracer.Domain.Seguridad;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ControlBus.Maestros
{
    public interface IProveedorRepository
    {
        Task<OutResultData<BEProveedor>> GetById(int id);
        Task<OutResultData<List<BEProveedor>>> GetAll(BEArgs args);
        Task<OutResultData<BEProveedor>> InsertUpdate(BEProveedor entity, int accion);
        Task<OutResultData<bool>> DeleteAllSelected(BEArgs args);
        Task<OutResultData<BEUsuarioWeb>> GestionUsuarios(BEUsuarioWeb entity, int accion);
        Task<OutResultData<BEProveedorTarifa>> GestionTarifas(BEProveedor entity, int accion);
    }
}
