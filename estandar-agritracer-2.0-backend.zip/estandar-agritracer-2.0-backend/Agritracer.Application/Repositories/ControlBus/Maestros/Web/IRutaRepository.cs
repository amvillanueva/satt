﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ControlBus.Maestros
{
    public interface IRutaRepository
    {
        Task<OutResultData<BERuta>> GetById(int id);
        Task<OutResultData<List<BERuta>>> GetAll(BEArgs args);
        Task<OutResultData<BERuta>> InsertUpdate(BERuta entity, int accion);
        Task<OutResultData<bool>> DeleteAllSelected(BEArgs args);
    }
}
