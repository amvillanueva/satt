﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ControlBus.Maestros
{
    public interface ITarifaRepository
    {
        Task<OutResultData<BETarifa>> GetById(int id);
        Task<OutResultData<List<BETarifa>>> GetAll(BEArgs args);
        Task<OutResultData<BETarifa>> InsertUpdate(BETarifa entity, int accion);
        Task<OutResultData<bool>> DeleteAllSelected(BEArgs args);
    }
}
