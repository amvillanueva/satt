﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ControlBus.Maestros
{
    public interface IUbicacionRepository
    {
        Task<OutResultData<BEUbicacion>> GetById(int id);
        Task<OutResultData<List<BEUbicacion>>> GetAll(BEArgs args);
        Task<OutResultData<BEUbicacion>> InsertUpdate(BEUbicacion entity, int accion);
        Task<OutResultData<bool>> DeleteAllSelected(BEArgs args);
    }
}
