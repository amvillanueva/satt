﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ControlBus.Porteria
{
    public interface IChoferPorteriaRepository
    {
        Task<OutResultData<BEChoferPorteria>> GetById(int id);
        Task<OutResultData<List<BEChoferPorteria>>> GetAll(BEArgs args);
        Task<OutResultData<BEChoferPorteria>> InsertUpdate(BEChoferPorteria entity, int accion);
        Task<OutResultData<bool>> DeleteAllSelected(BEArgs args);
        Task<OutResultData<bool>> SincronizarChoferes(BEArgs args);
    }
}