﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ControlBus.Porteria
{
    public interface IProveedorPorteriaRepository
    {
        Task<OutResultData<BEProveedorPorteria>> GetById(int id);
        Task<OutResultData<List<BEProveedorPorteria>>> GetAll(BEArgs args);
        Task<OutResultData<BEProveedorPorteria>> InsertUpdate(BEProveedorPorteria entity, int accion);
        Task<OutResultData<bool>> DeleteAllSelected(BEArgs args);
        Task<OutResultData<bool>> SincronizarProveedores(BEArgs args);
    }
}
