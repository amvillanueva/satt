﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ControlBus.Porteria
{
    public interface IReportesPorteriaRepository
    {
        Task<OutResultData<DataSet>> RptPorteria(BEArgs args);
        Task<OutResultData<BEAccesoPorteria>> GetDetails(int id, int tipo);
        Task<OutResultData<List<BEAccesoPorteria>>> GetManifiestos(string json);
    }
}
