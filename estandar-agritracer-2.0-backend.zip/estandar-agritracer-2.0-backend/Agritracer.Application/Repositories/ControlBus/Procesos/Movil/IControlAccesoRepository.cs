﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ControlBus;
using Agritracer.Domain.ControlBus.Movil;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ControlBus.Procesos.Movil
{
    public interface IControlAccesoRepository
    {
        Task<OutResultData<BEVehiculo>> DatosVehiculo(string codigoQR);
        Task<OutResultData<BEChoferPorteria>> DatosChofer(string codigoQR, int IdEmpresa);
        Task<OutResultData<string>> RegistrarControlAcceso(List<BEControlAcceso> args);
    }
}
