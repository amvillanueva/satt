﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ControlBus.Movil;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ControlBus.Procesos.Movil
{
    public interface IViajeRepository
    {
        Task<OutResultData<string>> IniciarViaje(BEViajeRest viajeRest);
        Task<OutResultData<string>> FinalizarViajes(List<BEViajeRest> viajeRestList);
        Task<OutResultData<string>> GenerarQRViaje(BEViajeRest viajeRest);
        Task<OutResultData<BEDataMaestra>> LecturarQRViaje(string CodViajeQR, int IdUsuario, string login, string host);
        Task<OutResultData<string>> ValidarViajeQR(BEViajeQR viajeQr);
        Task<OutResultData<string>> CambiarBus(BEViajeRest viajeQr);
    }
}
