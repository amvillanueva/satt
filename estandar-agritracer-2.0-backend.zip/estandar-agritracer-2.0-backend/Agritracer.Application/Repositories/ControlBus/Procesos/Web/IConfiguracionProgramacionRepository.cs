﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ControlBus.Procesos.Web
{
    public interface IConfiguracionProgramacionRepository
    {
        Task<OutResultData<BEProgramacion>> GetById(int id);
        Task<OutResultData<List<BEProgramacion>>> GetAll(BEArgs args);
        Task<OutResultData<BEProgramacion>> InsertUpdate(BEProgramacion entity, int accion);
        Task<OutResultData<bool>> DeleteAllSelected(BEArgs args);
    }
}
