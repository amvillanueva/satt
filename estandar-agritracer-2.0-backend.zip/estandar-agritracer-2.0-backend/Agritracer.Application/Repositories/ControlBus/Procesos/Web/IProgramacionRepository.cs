﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ControlBus.Procesos.Web
{
    public interface IProgramacionRepository
    {
        Task<OutResultData<List<BEProgramacion>>> GetAll(BEArgs args);
        Task<OutResultData<BEProgramacion>> InsertUpdate(BEProgramacion entity, int accion);
        Task<OutResultData<bool>> DeleteAllSelected(BEArgs args);
        Task<OutResultData<BEProgramacion>> AsignaConductorBus(BEProgramacion entity);
        Task<OutResultData<bool>> GenerarProgramacionAutomatica(BEArgs args);
        Task<OutResultData<bool>> FinalizarProgramaciones(BEArgs args);
    }
}
