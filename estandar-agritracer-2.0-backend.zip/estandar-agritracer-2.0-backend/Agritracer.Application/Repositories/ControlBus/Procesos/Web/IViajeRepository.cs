﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ControlBus.Procesos.Web
{
    public interface IViajeRepository
    {
        Task<OutResultData<List<BEViaje>>> GetAll(BEArgs args);
        Task<OutResultData<BEViaje>> GetDetails(int id, int tipoViajeID);
        Task<OutResultData<BEViaje>> InsertUpdate(BEViaje entity, int accion);
        Task<OutResultData<bool>> DeleteAllSelected(BEArgs args);
        Task<OutResultData<List<BEViajeDetalle>>> GetDatosPasajero(BEArgs args);
        Task<OutResultData<DataSet>> GenerarLiquidacion(BEArgs args);
        Task<OutResultData<DataSet>> ObtenerDashboard(BEArgs args);
        Task<OutResultData<DataSet>> ValidarEnviarLiquidacion(BEArgs args);
        Task<OutResultData<bool>> GuardarFacturaLiquidacion(BEArgs args);
    }
}
