﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ControlBus.Reportes
{
    public interface IReportesRepository
    {
        Task<OutResultData<DataSet>> ControlBuses(BEArgs args);
        Task<OutResultData<DataSet>> LiquidacionServicios(BEArgs args);
        Task<OutResultData<DataSet>> ViajesConductor(BEArgs args);
        Task<OutResultData<DataSet>> ViajesGrafico(BEArgs args);
        Task<OutResultData<DataSet>> PasajerosRestricciones(BEArgs args);
        Task<OutResultData<DataSet>> RatioOcupacion(BEArgs args);
        Task<OutResultData<DataSet>> BusesProveedor(BEArgs args);
        Task<OutResultData<DataSet>> CumplimientoServicios(BEArgs args);
        Task<OutResultData<DataSet>> CostoPasajero(BEArgs args);
    }
}
