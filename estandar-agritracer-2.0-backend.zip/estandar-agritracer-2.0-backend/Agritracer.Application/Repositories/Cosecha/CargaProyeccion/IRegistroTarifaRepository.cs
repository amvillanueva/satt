﻿using System;
using System.Data;
using System.Threading.Tasks;
using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;

namespace Agritracer.Application.Repositories.Cosecha.CargaProyeccion
{
    public interface IRegistroTarifaRepository
    {
        Task<OutResultData<DataTable>> Registrotarifa(int usuarioWebID, string host, int tipoRegistro, string fechapersonal, string tarifanormal, string tarifa1, string tarifa2, string fechaviaje, string tarifakiacam, string tarifacamioneta, string tarifathermoking);
    }
}


