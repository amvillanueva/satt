﻿using System;
using System.Data;
using System.Threading.Tasks;
using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;

namespace Agritracer.Application.Repositories.Cosecha.CargaProyeccion
{
    public interface IRegistroThermokingRepository
    {
        Task<OutResultData<DataTable>> RegistroThermoking(int usuarioWebID, string host, string fechathermoking, string nrothermoking, string nroviajes);
    }
}



