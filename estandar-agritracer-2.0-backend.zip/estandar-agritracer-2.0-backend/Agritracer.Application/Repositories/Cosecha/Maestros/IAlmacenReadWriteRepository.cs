﻿using Agritracer.Application.OutputObjets.Cosecha.Maestros;
using Agritracer.Domain.Cosecha;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Cosecha.Maestros
{
    public interface IAlmacenReadWriteRepository
    {
        Task<BEAlmacen> GetByID(int id);
        Task<IEnumerable<BEAlmacen>> GetAll(int estado,int empresa);
        Task<BEAlmacen> AddUpdate(BEAlmacen almacen);
        Task<OutAlmacenUseCase> Delete(List<int> almacenes);
    }
}
