﻿using Agritracer.Domain.Cosecha.Maestros;
using Agritracer.Application.OutputObjets;
using System.Collections.Generic;
using System.Threading.Tasks;
using Agritracer.Domain.Common;

namespace Agritracer.Application.Repositories.Cosecha.Maestros
{
    public interface IBandejaCosechaRepository
    {
        Task<OutResultData<BEBandejaCosecha>> GetById(int id);
        Task<OutResultData<List<BEBandejaCosecha>>> GetAll(BEArgs args);
        Task<OutResultData<BEBandejaCosecha>> InsUpdDel(BEBandejaCosecha bandejaCosecha, int accion);
        Task<OutResultData<BEBandejaCosecha>> DeleteAllSelected(BEArgs args);
    }
}
