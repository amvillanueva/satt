﻿using Agritracer.Application.OutputObjets.Cosecha.Maestros;
using Agritracer.Domain.Cosecha.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Cosecha.Maestros
{
    public interface ICampaniaReadWriteRepository
    {
        Task<BECampania> GetByID(BECampania campania);
        Task<IEnumerable<BECampania>> GetAll(BECampania campania);
        Task<IEnumerable<BECampania>> GetAllHist(BECampania campania);
        Task<BECampania> AddUpdate(BECampania campania);
        Task<OutCampaniaUseCase> Delete(List<BECampania> campanias);
    }
}
