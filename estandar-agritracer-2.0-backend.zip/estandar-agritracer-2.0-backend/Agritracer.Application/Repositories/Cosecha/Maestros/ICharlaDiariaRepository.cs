﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Cosecha.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Cosecha.Maestros
{
    public interface ICharlaDiariaRepository
    {
        Task<OutResultData<BECharlaDiaria>> GetById(int id);
        Task<OutResultData<List<BECharlaDiaria>>> GetAll(BEArgs args);
        Task<OutResultData<BECharlaDiaria>> InsUpdDel(BECharlaDiaria charla, int accion);
        Task<OutResultData<BECharlaDiaria>> DeleteAllSelected(BEArgs args);
    }
}
