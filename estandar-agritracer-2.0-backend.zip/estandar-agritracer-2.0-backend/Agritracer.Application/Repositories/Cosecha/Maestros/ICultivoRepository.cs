﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Cosecha.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Cosecha.Maestros
{
    public interface ICultivoRepository
    {
        Task<OutResultData<BECultivo>> GetById(int id);
        Task<OutResultData<List<BECultivo>>> GetAll(BEArgs args);
        Task<OutResultData<BECultivo>> InsUpdDel(BECultivo cultivo, int accion);
        Task<OutResultData<BECultivo>> DeleteAllSelected(BEArgs args);
    }
}
