﻿using Agritracer.Application.OutputObjets.Cosecha.Maestros;
using Agritracer.Domain.Configuracion.Maestros;
using Agritracer.Domain.Cosecha;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Cosecha.Maestros
{
    public interface IEmpresaReadWriteRepository
    {
        Task<BEEmpresa> GetByID(int id);
        Task<IEnumerable<BEEmpresa>> GetAll();
        Task<BEEmpresa> AddUpdate(BEEmpresa empresa);
        Task<OutEmpresaUseCase> Delete(List<int> empresas);
    }
}
