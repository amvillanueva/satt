﻿using Agritracer.Application.OutputObjets.Cosecha.Maestros;
using Agritracer.Domain.Cosecha;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Cosecha.Maestros
{
    public interface IFundoReadWriteRepository
    {
        Task<BEFundo> GetByID(int id);
        Task<IEnumerable<BEFundo>> GetAll(int empresa,int estado);
        Task<BEFundo> AddUpdate(BEFundo fundo);
        Task<OutFundoUseCase> Delete(List<int> fundos);
    }
}
