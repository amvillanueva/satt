﻿using System.Collections.Generic;
using Agritracer.Application.OutputObjets.Cosecha.Maestros;
using System.Threading.Tasks;
using Agritracer.Domain.Cosecha.Maestros;
using Agritracer.Domain.Cosecha;

namespace Agritracer.Application.Repositories.Cosecha.Maestros
{
    public interface IMaterialVariedadReadWriteRepository
    {
        Task<IEnumerable<BEMaterialVariedad>> GetAll(int variedadId);
    }
}
