﻿using Agritracer.Application.OutputObjets.Cosecha.Maestros;
using Agritracer.Domain.Cosecha;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Cosecha.Maestros
{
    public interface IModuloReadWriteRepository
    {
        Task<BEModulo> GetByID(int id);
        Task<IEnumerable<BEModulo>> GetAll(int empresa,int fundo,int estado);
        Task<BEModulo> AddUpdate(BEModulo fundo);
        Task<OutModuloUseCase> Delete(List<int> fundos);
    }
}
