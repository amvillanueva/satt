﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Cosecha.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;
using Agritracer.Domain.Common;

namespace Agritracer.Application.Repositories.Cosecha.Maestros
{
    public interface IProductoVariedadRepository
    {
        Task<OutResultData<BEProductoVariedad>> GetById(int id);
        Task<OutResultData<List<BEProductoVariedad>>> GetAll(BEArgs args);
        Task<OutResultData<BEProductoVariedad>> InsUpdDel(BEProductoVariedad productoVariedad, int accion);
        Task<OutResultData<BEProductoVariedad>> DeleteAllSelected(BEArgs args);
    }
}
