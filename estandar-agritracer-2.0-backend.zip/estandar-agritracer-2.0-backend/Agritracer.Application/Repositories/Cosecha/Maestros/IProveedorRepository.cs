﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Cosecha.Maestros;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Cosecha.Maestros
{
    public interface IProveedorRepository
    {
        Task<OutResultData<BEProveedor>> GetById(int id);
        Task<OutResultData<List<BEProveedor>>> GetAll(BEArgs args);
        Task<OutResultData<BEProveedor>> InsUpdDel(BEProveedor vehiculo, int accion);
        Task<OutResultData<BEProveedor>> DeleteAllSelected(BEArgs args);
    }
}
