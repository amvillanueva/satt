﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Cosecha;
using System.Collections.Generic;
using System.Threading.Tasks;
using Agritracer.Domain.Common;

namespace Agritracer.Application.Repositories.Cosecha.Maestros
{
    public interface IVariedadRepository
    {
        Task<OutResultData<BEVariedad>> GetById(int id);
        Task<OutResultData<List<BEVariedad>>> GetAll(BEArgs args);
        Task<OutResultData<BEVariedad>> InsUpdDel(BEVariedad variedad, int accion);
        Task<OutResultData<BEVariedad>> DeleteAllSelected(BEArgs args);
    }
}
