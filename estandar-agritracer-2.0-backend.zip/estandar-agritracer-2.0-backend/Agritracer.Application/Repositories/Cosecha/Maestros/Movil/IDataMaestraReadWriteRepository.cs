﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Cosecha.Maestros.Movil;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Cosecha.Maestros.Movil
{
    public interface IDataMaestraReadWriteRepository
    {
        Task<OutResultData<BEDataMaestra>> GetBy(int empresaId, int usuarioID);
    }
}
