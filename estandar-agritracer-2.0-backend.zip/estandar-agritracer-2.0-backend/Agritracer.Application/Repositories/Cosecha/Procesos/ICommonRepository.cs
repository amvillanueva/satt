﻿using Agritracer.Application.OutputObjets;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Cosecha.Procesos
{
    public interface ICommonRepository
    {
        Task<OutResultData<Dictionary<string, object>>> GetVehiculoByCodeQR(string codigoQR, int grupotrabajoId);
        Task<OutResultData<Dictionary<string, object>>> GetBandejaLecturadaByBandejaQR(string codigoQR, string dniTrabajador, int impresionId, int grupoTrabajoId, int supervisorId);

    }
}
