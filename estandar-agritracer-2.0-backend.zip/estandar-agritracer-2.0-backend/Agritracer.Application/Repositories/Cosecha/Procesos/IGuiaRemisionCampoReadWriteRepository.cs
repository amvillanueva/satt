﻿using Agritracer.Application.OutputObjets.Cosecha.Procesos;
using Agritracer.Domain.Cosecha.Procesos;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Cosecha.Procesos
{
    public interface IGuiaRemisionCampoReadWriteRepository
    {
        Task<BEGuiaRemisionCampo> GetByID(int guiaremisioncampoID);
        Task<IEnumerable<BEGuiaRemisionCampo>> GetAll(string fechaIni, string fechafin, int empresaID, int cultivoID,string guiaremision,bool incluirAnulados);
        Task<BEGuiaRemisionCampo> AddUpdate(BEGuiaRemisionCampo guiaremisionCampo);
        Task<OutGuiaRemisionCampoUseCase> Delete(BEGuiaRemisionCampo guiaremisionCampo);
    }
}
