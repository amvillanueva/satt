﻿using Agritracer.Application.OutputObjets.Cosecha.Procesos;
using Agritracer.Domain.Cosecha;
using Agritracer.Domain.Cosecha.Procesos;
using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Cosecha.Procesos
{
    public interface IImpresionStickerReadWriteRepository
    {
        Task<BEImpresionSticker> GetByID(int impresionStickerID);
        Task<IEnumerable<BEImpresionSticker>> GetAll(string fechaIni, string fechafin, int empresaID, int cultivoID,bool incluirAnulados);
        Task<IEnumerable<BEImpresionStickerResumen>> GetResumenImpresion(string fecha,int empresaID, int cultivoID);
        Task<IEnumerable<BESupervisorCosecha>> GetSupervisoresCosecha(int empresaID);
        Task<BEImpresionSticker> AddUpdate(BEImpresionSticker impresionSticker);
        Task<OutImpresionStickerUseCase> Delete(BEImpresionSticker impresionSticker);
    }
}
