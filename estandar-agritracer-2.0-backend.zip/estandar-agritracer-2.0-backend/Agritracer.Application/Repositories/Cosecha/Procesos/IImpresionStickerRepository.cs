﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Common.Maestros;
using Agritracer.Domain.Cosecha.Procesos;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Cosecha.Procesos
{
    public interface IImpresionStickerRepository
    {
        Task<OutResultData<BEImpresionSticker>> GetById(int id);
        Task<OutResultData<List<BEImpresionSticker>>> GetAll(BEArgs args);
        Task<OutResultData<BEImpresionSticker>> InsUpdDel(BEImpresionSticker impresionSticker, int accion);
        Task<OutResultData<BEImpresionSticker>> DeleteAllSelected(BEArgs args);
        Task<OutResultData<List<BETrabajador>>> GetTrabajadoresByImpresionSticker(BEArgs args);
        Task<OutResultData<BEImpresionSticker>> PrintById(int id);
        Task<OutResultData<string>> ActualizarEstadoImpreso(int id);
        Task<OutResultData<BEImpresionSticker>> ObtenerControlAsistencia(int id);
    }
}
