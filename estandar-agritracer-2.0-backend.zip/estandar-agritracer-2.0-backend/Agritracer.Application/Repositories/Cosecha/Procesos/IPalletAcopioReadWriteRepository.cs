﻿using Agritracer.Application.OutputObjets.Cosecha.Procesos;
using Agritracer.Domain.Cosecha.Procesos;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Cosecha.Procesos
{
    public interface IPalletAcopioReadWriteRepository
    {
        Task<BEPallet> GetByID(int palletAcopioID);
        Task<IEnumerable<BEPallet>> GetAll(string fechaIni, string fechafin, int empresaID, int cultivoID,bool incluirAnulados);
        Task<BEPallet> AddUpdate(BEPallet palletAcopio);
        Task<int> ValidarPallet(int palletID,string barcodePallet, int empresaID, int cultivoID);
        Task<OutPalletAcopioUseCase> Delete(BEPallet palletAcopio);
    }
}
