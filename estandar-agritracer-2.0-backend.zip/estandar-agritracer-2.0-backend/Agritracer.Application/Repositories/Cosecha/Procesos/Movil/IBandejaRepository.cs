﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Cosecha.Maestros.Movil;
using Agritracer.Domain.Cosecha.Procesos.Movil;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlTypes;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Cosecha.Procesos.Movil
{
    public interface IBandejaRepository
    {
        Task<OutResultData<List<BEProduccionMovil>>> RegistrarBandejasCosechadas(SqlXml produccionXML);
        Task<OutResultData<String>> RegistrarDespachoBandejasCosechadas(BEParamsDespachoBandeja despachoBandejas);
        Task<OutResultData<BEGrupoDashBoardCosecha>> ObtenerDatosDashboardCosecha(int grupoTrabajoId);
        Task<OutResultData<DataTable>> ObtenerProduccionLote(int empresaId, int cultivoId, int grupoTrabajoId);
        Task<OutResultData<string>> RegistrarDescarteBandejaCosechada(BEDescarteCosecha descarteBandejaCosecha);
        Task<OutResultData<Dictionary<String, Object>>> ObtenerStockDescarteByParams(int empresaId, int grupoTrabajoId, int fundoId, int moduloId, int cultivoId);

    }
}
