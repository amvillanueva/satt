﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Cosecha.CierreLote.Movil;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Cosecha.Procesos.Movil
{
    public interface ICierreLoteRepository
    {
        Task<OutResultData<string>> RegistrarLoteCerrado(SqlXml produccionXML);
        Task<OutResultData<string>> RegistrarLoteCerrado2(BEArgs produccionXML);
        Task<OutResultData<string>> RegistrarAprobacion(BEArgs produccionXML);
        Task<OutResultData<List<BECierreLote>>> ExecuteListadoCierreLote(BEArgs args);
        Task<OutResultData<List<BECierreLote>>> ExecuteListadoMonitoreoCierreLote(BEArgs args);
        Task<OutResultData<List<BEFoto>>> ExecuteListadoFotos(BEArgs args);

    }
}
