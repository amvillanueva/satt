﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Cosecha.Procesos;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Cosecha.Procesos.Web
{
    public interface ICapturaPesoRepository
    {
        Task<OutResultData<DataTable>> ListadoPallets(BEArgs args);
        Task<OutResultData<BEPalletArgs>> UpdateCapturaPesoPallet(BEPalletArgs args);
    }
}
