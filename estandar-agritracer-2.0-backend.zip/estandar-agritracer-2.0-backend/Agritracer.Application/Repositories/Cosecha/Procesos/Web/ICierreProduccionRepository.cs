﻿using Agritracer.Application.OutputObjets;
using System.Threading.Tasks;
using System.Data;
using Agritracer.Domain.Cosecha.Procesos;

namespace Agritracer.Application.Repositories.Cosecha.Procesos.Web
{
    public interface ICierreProduccionRepository
    {
        Task<OutResultData<DataSet>> GetCierreProduccionPendiente(BEProduccionArgs args);
        Task<OutResultData<DataTable>> GetCierreProduccionResumen(BEProduccionArgs args);

        Task<OutResultData<BEProduccionArgs>> ProcesarCierreProduccion(BEProduccionArgs args);

    }
}
