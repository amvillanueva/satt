﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Cosecha.Procesos;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Cosecha.Procesos.Web
{
    public interface ICosechaDiariaRepository
    {
        Task<OutResultData<DataTable>> GetResumenProduccion(BEArgs args);
        Task<OutResultData<DataSet>> GetDashboardResumen(BEArgs args);
        Task<OutResultData<DataSet>> GetDashboardTransporte(BEArgs args);
        Task<OutResultData<DataTable>> GetDetalleProduccion(BEArgs args);
        Task<List<BEProduccionFirestore>> GetProduccionConsolidado(BEArgs args);

        Task<OutResultData<BEProduccionCampo>> UpdateEstadoProduccionCampo(BEProduccionCampo args);
        Task<OutResultData<BEProduccionCampo>> UpdateBandejaProduccionCampo(BEProduccionCampo args);
        Task<OutResultData<BEProduccionCampo>> UpdateLoteProduccionCampo(BEProduccionCampo args);
        Task<OutResultData<DataSet>> GetDetalleCierreHectarea(BEArgs args);
        Task<OutResultData<DataSet>> GetDetalleTransporteMP(BEArgs args);
    }
}
