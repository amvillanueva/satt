﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Cosecha.Proyecciones;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Data;

namespace Agritracer.Application.Repositories.Cosecha.Proyecciones
{
    public interface IProyeccionRepository
    {
        Task<OutResultData<List<BEProyeccion>>> GetAll(BEArgs args);
        Task<OutResultData<DataSet>> ImportarProyecciones(BEArgs args);
        Task<OutResultData<DataSet>> GuardarProyecciones(BEArgs args);
        Task<OutResultData<BEProyeccion>> CambiarEstadoProyecciones(BEArgs args);
        Task<OutResultData<List<BEProyeccion>>> GetAllDetalle(BEArgs args);
        Task<OutResultData<DataSet>> ImportarProyeccionesDetalle(BEArgs args);
        Task<OutResultData<DataSet>> GuardarProyeccionesDetalle(BEArgs args);
        Task<OutResultData<BEProyeccion>> CambiarEstadoProyeccionesDetalle(BEArgs args);
        Task<OutResultData<List<BEProyeccion>>> GetAllAjuste(BEArgs args);
        Task<OutResultData<BEProyeccion>> GuardarProyeccionesAjuste(BEArgs args);
        Task<OutResultData<BEProyeccion>> CambiarEstadoProyeccionesAjuste(BEArgs args);
        Task<OutResultData<List<BEProyeccion>>> GetAllAjusteMovil(BEArgs args);
    }
}
