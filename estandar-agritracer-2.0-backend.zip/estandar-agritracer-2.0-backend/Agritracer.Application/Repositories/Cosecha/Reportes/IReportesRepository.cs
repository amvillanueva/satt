﻿using System;
using System.Data;
using System.Threading.Tasks;
using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Cosecha.CierreLote.Web;

namespace Agritracer.Application.Repositories.Cosecha.Reportes
{
    public interface IReportesRepository
    {
        Task<OutResultData<DataSet>> RptRankingCosecha(BEArgs args);
        Task<OutResultData<DataTable>> RptCruceTareoCosecha(BEArgs args);
        Task<OutResultData<DataTable>> RptDetalleCosechador(BEArgs args);
        Task<OutResultData<DataTable>> RptCae(BEArgs args);
        Task<OutResultData<DataSet>> RptCharlaDiaria(BEArgs args);
        Task<OutResultData<DataSet>> RptViajesDespachoCosecha(BEArgs args);

        //--------------------------------------------------------------------------
        Task<OutResultData<DataTable>> GetReporteGenericoCosechaDT(BEParams args);
        Task<OutResultData<DataSet>> GetReporteGenericoCosechaDS(BEParams args);

        Task<OutResultData<DataSet>> RptTrazabilidadAcopio(BEArgs args);

        Task<OutResultData<DataSet>> RptViajesDespacho(BEArgs args);
        Task<OutResultData<DataSet>> RptBonificacion(BEArgs args);

        //---------------------------------------------------------------------------

        Task<OutResultData<BECierreLote>> InsUpdDelCierreLote(BECierreLote cierreLote, int accion);
    }
}
