﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;
using Agritracer.Domain.Common;

namespace Agritracer.Application.Repositories.ManoObra.Maestros
{
    public interface IAcopioRepository
    {
        Task<OutResultData<BEAcopio>> GetById(int id);
        Task<OutResultData<List<BEAcopio>>> GetAll(BEArgs args);
        Task<OutResultData<BEAcopio>> InsUpdDel(BEAcopio acopio, int accion);
        Task<OutResultData<BEAcopio>> DeleteAllSelected(BEArgs args);
    }
}
