﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ManoObra.Maestros
{
    public interface IComedorRepository
    {
        Task<OutResultData<BEComedor>> GetById(int id);
        Task<OutResultData<List<BEComedor>>> GetAll(BEArgs args);
        Task<OutResultData<BEComedor>> InsUpdDel(BEComedor comedor, int accion);
        Task<OutResultData<BEComedor>> DeleteAllSelected(BEArgs args);
    }
}
