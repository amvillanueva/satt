﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Maestros;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ManoObra.Maestros
{
    public interface IConductorRepository
    {
        Task<OutResultData<BEConductor>> GetById(int id);
        Task<OutResultData<List<BEConductor>>> GetAll(BEArgs args);
        Task<OutResultData<BEConductor>> InsUpdDel(BEConductor conductor, int accion);
        Task<OutResultData<BEConductor>> DeleteAllSelected(BEArgs args);
    }
}
