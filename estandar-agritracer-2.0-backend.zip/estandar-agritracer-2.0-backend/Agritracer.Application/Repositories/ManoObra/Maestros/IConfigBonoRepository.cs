﻿using System.Data;
using System.Threading.Tasks;

using Agritracer.Domain.Common;
using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Maestros;

namespace Agritracer.Application.Repositories.ManoObra.Maestros
{
    public interface IConfigBonoRepository
    {
        Task<OutResultData<DataTable>> GetAll(BEParams args);
        Task<OutResultData<BEConfigBono>> InsUpd(BEConfigBono entity);
    }
}
