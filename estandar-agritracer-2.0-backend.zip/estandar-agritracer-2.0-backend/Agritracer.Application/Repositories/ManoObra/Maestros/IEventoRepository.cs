﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ManoObra.Maestros
{
    public interface IEventoRepository
    {
        Task<OutResultData<BEEvento>> GetById(int id);
        Task<OutResultData<List<BEEvento>>> GetAll(BEArgs args);
        Task<OutResultData<BEEvento>> InsUpdDel(BEEvento evento, int accion);
    }
}
