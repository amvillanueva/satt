﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ManoObra.Maestros
{
    public interface IGrupoActividadRepository
    {
        Task<OutResultData<BEGrupoActividad>> GetById(int id);
        Task<OutResultData<List<BEGrupoActividad>>> GetAll(BEArgs args);
        Task<OutResultData<BEGrupoActividad>> InsUpdDel(BEGrupoActividad grupoactividad, int accion);
    }
}
