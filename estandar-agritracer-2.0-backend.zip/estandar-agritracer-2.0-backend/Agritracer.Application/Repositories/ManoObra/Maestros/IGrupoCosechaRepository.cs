﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ManoObra.Maestros
{
    public interface IGrupoCosechaRepository
    {
        Task<OutResultData<BEGrupoCosecha>> GetById(int id);
        Task<OutResultData<List<BEGrupoCosecha>>> GetAll(BEArgs args);
        Task<OutResultData<BEGrupoCosecha>> InsUpdDel(BEGrupoCosecha grupoCosecha, int accion);
        Task<OutResultData<BEGrupoCosecha>> DeleteAllSelected(BEArgs args);
        Task<OutResultData<BEGrupoCosecha>> DeleteTrabajador(BEArgs args);
    }
}
