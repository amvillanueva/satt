﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;
using Agritracer.Domain.Common;
using System.Data;

namespace Agritracer.Application.Repositories.ManoObra.Maestros
{
    public interface IImpresionFotocheckRepository
    {
        Task<OutResultData<BEImpresionFotocheck>> GetById(int id);
        Task<OutResultData<List<BEImpresionFotocheck>>> GetAll(BEArgs args);
        Task<OutResultData<BEImpresionFotocheck>> InsUpdDel(BEImpresionFotocheck acopio, int accion);
        Task<OutResultData<BEImpresionFotocheck>> DeleteAllSelected(BEArgs args);
        Task<OutResultData<DataSet>> Importar(BEArgs args);
        Task<OutResultData<BEImpresionFotocheck>> Procesar(BEArgs args);
    }
}
