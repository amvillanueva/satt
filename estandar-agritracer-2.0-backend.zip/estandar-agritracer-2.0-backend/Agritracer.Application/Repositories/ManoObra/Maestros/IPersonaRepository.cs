﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ManoObra.Maestros
{
    public interface IPersonaRepository
    {
        Task<OutResultData<BEPersona>> GetById(int id);
        Task<OutResultData<List<BEPersona>>> GetAll(BEArgs args);
        Task<OutResultData<BEPersona>> InsUpdDel(BEPersona persona, int accion);
    }
}
