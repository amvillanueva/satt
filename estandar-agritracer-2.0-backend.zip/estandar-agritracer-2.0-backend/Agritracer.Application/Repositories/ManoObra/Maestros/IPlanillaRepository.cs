﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ManoObra.Maestros
{
    public interface IPlanillaRepository
    {
        Task<OutResultData<BEPlanilla>> GetById(int id);
        Task<OutResultData<List<BEPlanilla>>> GetAll(BEArgs args);
        Task<OutResultData<BEPlanilla>> InsUpdDel(BEPlanilla planilla, int accion);
    }
}
