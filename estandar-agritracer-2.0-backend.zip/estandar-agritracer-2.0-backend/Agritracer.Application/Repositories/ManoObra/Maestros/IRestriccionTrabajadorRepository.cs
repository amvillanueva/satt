﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using System.Threading.Tasks;
using System.Data;
using Agritracer.Domain.ManoObra.Maestros;

namespace Agritracer.Application.Repositories.ManoObra.Maestros
{
    public interface IRestriccionTrabajadorRepository
    {
        Task<OutResultData<DataTable>> GetListadoRestricciones(BEArgs args);

        Task<OutResultData<BERestriccionTrabajador>> InsUpdDel(BERestriccionTrabajador restriccion, int accion);
        Task<OutResultData<BEArgs>> ActionAllSelected(BEArgs args, int action);
    }
}
