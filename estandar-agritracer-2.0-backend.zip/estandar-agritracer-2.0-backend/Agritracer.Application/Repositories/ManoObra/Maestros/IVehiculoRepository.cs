﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Maestros;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ManoObra.Maestros
{
    public interface IVehiculoRepository
    {
        Task<OutResultData<BEVehiculo>> GetById(int id);
        Task<OutResultData<List<BEVehiculo>>> GetAll(BEArgs args);
        Task<OutResultData<BEVehiculo>> InsUpdDel(BEVehiculo vehiculo, int accion);
        Task<OutResultData<BEVehiculo>> DeleteAllSelected(BEArgs args);
    }
}
