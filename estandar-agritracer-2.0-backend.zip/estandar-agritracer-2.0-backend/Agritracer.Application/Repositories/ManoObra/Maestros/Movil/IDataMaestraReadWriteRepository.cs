﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Maestros.Movil;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ManoObra.Maestros.Movil
{
    public interface IDataMaestraReadWriteRepository
    {
        Task<OutResultData<BEDataMaestra>> GetBy(int empresaId, int usuarioId, int supervisorId);
        Task<OutResultData<BEDataMaestraTPacking>> TareoPackingGetBy(int empresaId, int usuarioId, int supervisorId);
        Task<OutResultData<BEDataMaestraComedor>> ComedorGetBy(int empresaId, int usuarioId, int acopioId);
    }
}
