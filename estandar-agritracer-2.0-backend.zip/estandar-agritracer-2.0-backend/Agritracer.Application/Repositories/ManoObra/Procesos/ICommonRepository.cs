﻿using Agritracer.Application.OutputObjets;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ManoObra.Procesos
{
    public interface ICommonRepository
    {
        Task<OutResultData<Dictionary<string, object>>> GetGrupoByLegajo(string legajo);
        Task<OutResultData<Dictionary<string, object>>> GetGrupoByCodigo(string codigo);
        Task<OutResultData<Dictionary<string, object>>> GetSupervisorByLegajo(string legajo);

    }
}
