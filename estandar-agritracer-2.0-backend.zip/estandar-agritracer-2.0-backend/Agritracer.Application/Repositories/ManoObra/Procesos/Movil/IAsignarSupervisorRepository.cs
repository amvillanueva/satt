﻿using Agritracer.Application.OutputObjets;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ManoObra.Procesos.Movil
{
    public interface IAsignarSupervisorRepository
    {
        Task<OutResultData<string>> RegistrarAsignacion(int supervisorId, string supervisorCodigo, int grupoTrabajoId, string equipos, int userId, string imei);
        Task<OutResultData<string>> EliminarAsignacion(int grupoTrabajoId, int supervisorId, string supervisorCodigo, int userId, string imei);
    }

}
