﻿using Agritracer.Application.OutputObjets;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ManoObra.Procesos.Movil
{
    public interface ICierreLoteRespository
    {
        Task<OutResultData<string>> RegistroProductividadSurcos(SqlXml listaProductivdadXML);
    }
}
