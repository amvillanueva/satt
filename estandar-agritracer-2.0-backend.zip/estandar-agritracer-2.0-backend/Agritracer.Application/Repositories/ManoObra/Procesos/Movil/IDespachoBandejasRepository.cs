﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Procesos.Movil;
using System.Data.SqlTypes;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ManoObra.Procesos.Movil
{
    public interface IDespachoBandejasRepository
    {
        Task<OutResultData<BEDespachoBandejasDetalle>> obtenerBandejaDespacho(string codBandeja, int acopioId);
        Task<OutResultData<string>> registrarDespachoBandejas(SqlXml despachosXML);
    }

}
