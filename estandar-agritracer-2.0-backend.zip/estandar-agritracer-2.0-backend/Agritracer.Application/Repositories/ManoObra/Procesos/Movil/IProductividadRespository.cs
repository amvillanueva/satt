﻿using Agritracer.Application.OutputObjets;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ManoObra.Procesos.Movil
{
    public interface IProductividadRespository
    {
        Task<OutResultData<string>> RegistrarProductividadTrabajadores(SqlXml productividadesXML);
    }
}
