﻿using Agritracer.Application.OutputObjets;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ManoObra.Procesos.Movil
{
    public interface IReasignarGrupoRepository
    {
        Task<OutResultData<string>> RegistrarReAsignacion(int grupoTrabajoAntiguoId, int grupoTrabajoActualId, int trabajadorId, int tipoCambio, string username, string imei);
        Task<OutResultData<string>> EliminarReAsignacion(int grupoTrabajoId, int trabajadorId, string username, string imei);
    }

}
