﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Procesos.Movil;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ManoObra.Procesos.Movil
{
    public interface IRecepcionAlmuerzoRepository
    {
        Task<OutResultData<List<BERecepcionAlmuerzo>>> obtenerSolicitudAlmuerzoDNI(string dni, int acopioId, int empresaId);
        Task<OutResultData<DataTable>> obtenerResumenRecepcion(int usuarioId, int acopioId);
        Task<OutResultData<DataTable>> obtenerDetalleRecepcion(int usuarioId, int acopioId);
        Task<OutResultData<string>> registrarRecepcionAlmuerzo(string recepcionesXML);
        Task<OutResultData<string>> registrarCierreRecepcion(int usuarioId, int acopioId, int empresaId);
        Task<OutResultData<string>> registrarRechazoAlmuerzo(string rechazosXML);
        Task<OutResultData<string>> registrarEmpaqueRecepcion(string recepcionesXML);
    }

}
