﻿using Agritracer.Application.OutputObjets;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ManoObra.Procesos.Movil
{
    public interface IRegistroTareoRespository
    {
        Task<OutResultData<string>> RegistrarTareo(SqlXml planillasXML, int tipoTareo);
        Task<OutResultData<string>> RegistrarTareo2(SqlXml planillasXML, int tipoTareo);
    }
}
