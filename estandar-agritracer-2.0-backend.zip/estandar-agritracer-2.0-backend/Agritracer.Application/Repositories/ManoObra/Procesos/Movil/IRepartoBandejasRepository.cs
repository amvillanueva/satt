﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Procesos.Movil;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ManoObra.Procesos.Movil
{
    public interface IRepartoBandejasRepository
    {
        Task<OutResultData<BERepartoAsignado>> obtenerDespacho(int usuarioID);
        Task<OutResultData<Dictionary<string, object>>> consultarLegajo(string legajo);
        Task<OutResultData<Dictionary<string, object>>> consultarResumen(int usuarioID);
        Task<OutResultData<string>> registrarReparto(SqlXml despachosXML);
        Task<OutResultData<string>> cierreReparto(int usuarioID);
    }

}
