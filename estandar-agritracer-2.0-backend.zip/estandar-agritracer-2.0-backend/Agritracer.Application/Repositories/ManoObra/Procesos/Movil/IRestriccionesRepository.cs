﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Maestros.Movil;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ManoObra.Procesos.Movil
{
    public interface IRestriccionesRepository
    {
        Task<OutResultData<List<BEAsistenciaPlanilla>>> validarRestricionesTrabajadoresPlanilla(SqlXml asistentesXML, int tipoTareo);
    }

}
