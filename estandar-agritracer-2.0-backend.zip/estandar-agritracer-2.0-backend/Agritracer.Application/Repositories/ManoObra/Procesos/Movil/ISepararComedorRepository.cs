﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Maestros;
using Agritracer.Domain.ManoObra.Procesos.Movil;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ManoObra.Procesos.Movil
{
    public interface ISepararComedorRepository
    {
        Task<OutResultData<List<BETrabajadorGrupo>>> obtenerDetalleTrabajadores(int grupoid,int supervisorid);
        Task<OutResultData<List<BETrabajadorGrupo>>> obtenerDetalleTrabajadores(BESolicitudComedorLab padronGrupo);
        Task<OutResultData<List<BEComedor>>> obtenerComedoresDisponibles(int zonaid, int moduloid,int grupoid, int supervisorid);
        Task<OutResultData<string>> registrarPadronComedor(string padronXML);
    }

}
