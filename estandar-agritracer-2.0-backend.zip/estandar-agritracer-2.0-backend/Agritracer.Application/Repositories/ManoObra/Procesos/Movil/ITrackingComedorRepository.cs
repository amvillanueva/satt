﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Maestros;
using Agritracer.Domain.ManoObra.Procesos.Movil;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.ManoObra.Procesos.Movil
{
    public interface ITrackingComedorRepository
    {
        Task<OutResultData<List<BEPadronComedor>>> obtenerPadronGrupo(int grupoid);
        Task<OutResultData<string>> solicitarAlmuerzoEmergencia(string padronXML);
        Task<OutResultData<string>> registrarEntregaAlmuerzo(string entregaXML);
    }

}
