﻿using System;
using System.Data;
using System.Threading.Tasks;
using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;

namespace Agritracer.Application.Repositories.ManoObra.Procesos
{
    public interface IAsignacionRepository
    {
        Task<OutResultData<DataTable>> ObtenerReporteAsignacion(DateTime fechaIni, DateTime fechaFin, int empresaID, int usuarioID);
        Task<OutResultData<string>> EliminarAsignacionSupervisor(BETransaccion transaccion);
    }
}
