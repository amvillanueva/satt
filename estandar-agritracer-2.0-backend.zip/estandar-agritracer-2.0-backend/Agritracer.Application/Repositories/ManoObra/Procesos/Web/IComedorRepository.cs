﻿using System;
using System.Data;
using System.Threading.Tasks;
using Agritracer.Application.OutputObjets;

namespace Agritracer.Application.Repositories.ManoObra.Procesos
{
    public interface IComedorRepository
    {
        Task<OutResultData<DataSet>> ObtenerReporteTrabajadoresComedor(DateTime fechaIni,DateTime fechaFin,int empresaID, int usuarioID);
        Task<OutResultData<DataTable>> ObtenerReporteTrackingAlmuerzos(DateTime fechaIni, DateTime fechaFin, int empresaID, int usuarioID,int supervisorID,int tipoAlmuerzoID);
        Task<OutResultData<DataTable>> ObtenerReporteIncidenciaAcopio(DateTime fechaIni, DateTime fechaFin, int empresaID, int usuarioID);
        Task<OutResultData<DataTable>> ObtenerReporteAvanceRepartos(DateTime fechaIni, DateTime fechaFin, int vehiculoID);
        Task<OutResultData<DataTable>> ObtenerReporteAlmuerzosEmergencia(DateTime fechaIni, DateTime fechaFin, int empresaID, int usuarioID, int supervisorID, int tipoAlmuerzoID);
    }
}
