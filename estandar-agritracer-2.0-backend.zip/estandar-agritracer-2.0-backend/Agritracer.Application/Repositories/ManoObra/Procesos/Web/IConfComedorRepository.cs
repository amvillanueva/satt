﻿using System;
using System.Data;
using System.Threading.Tasks;
using Agritracer.Application.OutputObjets;

namespace Agritracer.Application.Repositories.ManoObra.Procesos
{
    public interface IConfComedorRepository
    {
        Task<OutResultData<DataTable>> GetConfiguracionDia(int zonaID, int comedorID, int empresaID, int usuarioID, DateTime fecha);
        Task<OutResultData<string>> UpdateDisponibilidad(String xmlComedores);
        Task<OutResultData<string>> UpdateSegundoTurno(String xmlComedores);
    }
}
