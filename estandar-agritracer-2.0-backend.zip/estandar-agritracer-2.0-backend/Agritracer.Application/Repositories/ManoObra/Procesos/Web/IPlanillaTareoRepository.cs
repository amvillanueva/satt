﻿using System;
using System.Data;
using System.Threading.Tasks;
using System.Collections.Generic;
using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Procesos;
using Agritracer.Domain.Common;

namespace Agritracer.Application.Repositories.ManoObra.Procesos
{
    public interface IPlanillaTareoRepository
    {
        #region TareoPacking

        Task<OutResultData<DataTable>> GetResumenPLanillasPacking(DateTime fechaIni, DateTime fechaFin, int empresaID, int supervisorID, int usuarioID);

        Task<OutResultData<DataSet>> GetPadronResumenPacking(DateTime? fecha, int empresaID, int supervisorID, int actividadID);
        Task<OutResultData<DataTable>> GetPadronDetallePacking(int planillaID, int empresaID, int actividadID);

        Task<OutResultData<DataTable>> GetPlanillasDetallePacking(int empresaID, int actividadID, int supervisorID, DateTime? fecha);

        Task<OutResultData<BEPlanillaTareo>> InsertPlanillaTareoPacking(BEPlanillaTareo planilla);
        Task<OutResultData<BEPlanillaTareo>> UpdatePlanillaTareoPacking(BEPlanillaTareo planilla);

        #endregion

        //---------------------------------------------------------------------
        Task<OutResultData<DataTable>> GetResumenPLanillas(DateTime fechaIni, DateTime fechaFin, int empresaID, int supervisorID, int usuarioID);
        Task<List<BEPlanillaActividad>> GetPlanillasActividad(int empresaID, int supervisorID, DateTime fecha);
        Task<OutResultData<DataTable>> GetPlanillasCodigo(string codigos);
        Task<OutResultData<DataTable>> GetPlanillasDetalle(int empresaID, int actividadID, int supervisorID, DateTime? fecha);
        Task<OutResultData<DataTable>> GetPlanillasActividadCbo(int actividadID, int supervisorID, DateTime? fecha);
        Task<OutResultData<DataTable>> GetPadronDetalle(int planillaID, int empresaID, int actividadID);
        Task<OutResultData<DataSet>> GetPadronResumen(DateTime? fecha, int empresaID, int supervisorID, int actividadID);

        Task<OutResultData<DataTable>> GetFundos(int empresa);
        Task<OutResultData<DataTable>> GetModulos(int fundo);
        Task<OutResultData<DataTable>> GetTurnoDia(int empresa);
        Task<OutResultData<DataTable>> GetOrdenInv(int empresa);
        Task<OutResultData<DataTable>> GetCentroCosto(int empresaID, int tipoActividadID, int flagPacking);

        Task<OutResultData<DataTable>> GetLineaPacking(int empresa);

        Task<OutResultData<DataTable>> GetActividades(int empresaID, int tipoActividadID, int flagPacking);
        Task<OutResultData<DataTable>> GetActividadesSupervisor(int supervisorID, DateTime? fecha);
        Task<OutResultData<DataTable>> GetCeCoXActividadModulo(int empresa, int actividad, int modulo);
        Task<OutResultData<DataTable>> GetTrabajadorXLegajo(string legajo, string fecha);
        Task<OutResultData<DataTable>> GetListaErroresPlanilla(string codigos);

        //Crear/Actualizar PLanillas
        Task<OutResultData<BEPlanillaTareo>> InsertPlanillaTareo(BEPlanillaTareo planilla);
        Task<OutResultData<BEPlanillaTareo>> UpdatePlanillaTareo(BEPlanillaTareo planilla);
        Task<OutResultData<string>> AddTrabajadorPlanilla(BETrabajadorPlanilla trabajador);
        Task<OutResultData<BEPlanillaTransaccion>> UpdateHorasPlanilla(BEPlanillaTransaccion transaccion);
        Task<OutResultData<BEPlanillaTransaccion>> UpdateHorasPagoPlanilla(BEPlanillaTransaccion transaccion);
        Task<OutResultData<BEPlanillaTransaccion>> CopyPlanillaTrabajador(BEPlanillaTransaccion transaccion);
        Task<OutResultData<BEPlanillaTransaccion>> MovePlanillaTrabajador(BEPlanillaTransaccion transaccion);
        Task<OutResultData<BEPlanillaTransaccion>> UpdateBonoPlanilla(BEPlanillaTransaccion transaccion);
        Task<OutResultData<BEPlanillaTransaccion>> UpdateEstadoPlanilla(BEPlanillaTransaccion transaccion);
        Task<OutResultData<BEPlanillaTransaccion>> DeletePlanilla(BEPlanillaTransaccion transaccion);
        Task<OutResultData<BEPlanillaTransaccion>> DeletePlanillaDetalle(BEPlanillaTransaccion transaccion);
        Task<OutResultData<bool>> AprobarPlanillasSupervisor(BEArgs args);
        Task<OutResultData<BEPlanillaTransaccion>> UpdateDistribucionHorasPagoSupervisor(BEPlanillaTransaccion transaccion);
    }
}
