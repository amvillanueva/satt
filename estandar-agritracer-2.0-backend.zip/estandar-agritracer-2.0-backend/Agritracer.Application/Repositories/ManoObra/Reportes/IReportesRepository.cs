﻿using System;
using System.Data;
using System.Threading.Tasks;
using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;

namespace Agritracer.Application.Repositories.ManoObra.Reportes
{
    public interface IReportesRepository
    {
        #region TareoMovil
        Task<OutResultData<DataTable>> GetReporteAsistenciaTareo(DateTime fechaIni, DateTime fechaFin, int empresaID, int supervisorID, string grupoTrabajo, int usuarioWebID);
        Task<OutResultData<DataTable>> GetReporteSemanalTareo(int usuarioWebID, int empresaID, int supervisorID, int semanaID);
        Task<OutResultData<DataTable>> GetReporteHorasTareo(DateTime fechaIni, DateTime fechaFin, int empresaID, int supervisorID, int perfilID, int actividadID, string grupoTrabajo, string legajo, int tipoReporte, int usuarioWebID);
        Task<OutResultData<DataSet>> GetReporteTrabajadoresPlanilla(int fecha, int empresaID);
        Task<OutResultData<DataTable>> GetReporteProductividad(DateTime fechaIni, DateTime fechaFin, int empresaID, int supervisorID,
            int actividadID, int fundoID, int variedadID, int tipoReporte, int usuarioWebID);
        Task<OutResultData<DataTable>> GetReporteProductividadVariedad(DateTime fechaIni, DateTime fechaFin, int empresaID, int supervisorID,
    int actividadID, int fundoID, int variedadID, int usuarioWebID);
        Task<OutResultData<DataSet>> GetReporteExportacionNisira(string fecha);
        Task<OutResultData<DataTable>> GetReporteHistorialContratos(BEArgs args);
        Task<OutResultData<DataTable>> GetReporteGenericoManoObraDT(BEParams args);
        Task<OutResultData<DataTable>> GetReporteGruposTrabajo(int empresaID, int grupoTrabajoID, string legajo, string nombres);
        #endregion

        #region TareoPacking

        Task<OutResultData<DataTable>> GetReporteAsistenciaTareoPacking(DateTime fechaIni, DateTime fechaFin, int empresaID, int supervisorID, int usuarioWebID);
        Task<OutResultData<DataTable>> GetReporteSemanalTareoPacking(int usuarioWebID, int empresaID, int supervisorID, int semanaID);
        Task<OutResultData<DataTable>> GetReporteHorasTareoPacking
            (DateTime fechaIni,
                DateTime fechaFin,
                int empresaID,
                int supervisorID,
                int perfilID,
                int actividadID,
                string legajo,
                int tipoReporte,
                int usuarioWebID
            );
        Task<OutResultData<DataTable>> GetReporteComedorPacking(DateTime fechaIni, DateTime fechaFin, int empresaID, bool almuerzo, bool cena);

        #endregion
    }
}
