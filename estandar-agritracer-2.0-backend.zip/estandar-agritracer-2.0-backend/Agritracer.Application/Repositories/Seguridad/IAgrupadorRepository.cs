﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Seguridad;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Seguridad
{
    public interface IAgrupadorRepository
    {
        Task<OutResultData<DataTable>> GetByCultivo(int id);
        Task<OutResultData<DataTable>> GetTipoConfig(BEArgs args);
        Task<OutResultData<string>> InsUpdDel(BEAgrupador agrupador, int accion);
        Task<OutResultData<string>> DeleteAllSelected(BEArgs args);
    }
}
