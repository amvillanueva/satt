﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Seguridad;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories
{
    public interface IAuthMovilReadWriteRepository
    {
        Task<BEUsuarioMovil> GetUsuarioMovilByID(int usuarioMovilID);
        Task<OutResultData<BEUsuarioMovil>> GetUsuarioMovilByLoginPass(string login, string pass, int empresaId);
    }
}
