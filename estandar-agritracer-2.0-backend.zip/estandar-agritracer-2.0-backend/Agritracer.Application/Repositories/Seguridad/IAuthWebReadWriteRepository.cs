﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Seguridad;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories
{
    public interface IAuthWebReadWriteRepository
    {
        Task<OutUsuarioUseCase> GetOutUsuarioWebExec(string login, string pass);
        Task<BEUsuarioWeb> GetUsuarioWebByIDExec(int usuarioWebID);
    }
}
