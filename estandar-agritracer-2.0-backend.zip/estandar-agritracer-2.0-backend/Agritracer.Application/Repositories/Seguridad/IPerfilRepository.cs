﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Seguridad;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Seguridad
{
    public interface IPerfilRepository
    {
        Task<OutResultData<BEPerfil>> GetById(int id);
        Task<OutResultData<List<BEPerfil>>> GetAll(BEArgs args);
        Task<OutResultData<BEPerfil>> InsUpdDel(BEPerfil perfil, int accion);
        Task<OutResultData<BEPerfil>> DeleteAllSelected(BEArgs args);
    }
}
