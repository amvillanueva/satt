﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Seguridad;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.Seguridad
{
    public interface IUsuarioRepository
    {
        Task<OutResultData<BEUsuario>> GetById(int id);
        Task<OutResultData<List<BEUsuario>>> GetAll(BEArgs args);
        Task<OutResultData<BEUsuario>> InsUpdDel(BEUsuario perfil, int accion);
        Task<OutResultData<BEUsuario>> DeleteAllSelected(BEArgs args);
    }
}
