﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.Repositories.SmartData.Control
{
    public interface IGisRepository
    {
        Task<OutResultData<DataSet>> GetIndicador(BEArgs args);
        Task<OutResultData<DataTable>> GetDetalleLote(BEArgs args);
    }
}
