﻿using Agritracer.Domain.Seguridad;
using System.Threading.Tasks;

namespace Agritracer.Application.Services
{
    public interface IJwtFactory
    {
        Task<BEToken> GenerateEncodedToken<T>(T usuario);
    }
}
