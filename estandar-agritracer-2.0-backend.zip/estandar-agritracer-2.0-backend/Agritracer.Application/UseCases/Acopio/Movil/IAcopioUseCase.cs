﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Acopio;
using Agritracer.Domain.Acopio.Movil;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Acopio.Movil
{
    public interface IAcopioUseCase
    {
        Task<OutResultData<BEDataMaestraAcopio>> ExecuteGetDataMaestra(BEArgs args);
        Task<OutResultData<List<BEDashboardAcopio>>> ExecuteGetDashboard(BEArgs args);
        Task<OutResultData<List<BEDespachoCosecha>>> ExecuteSincronizarDespachoCosecha(List<BEDespachoCosecha> despachoCosechaList);
        Task<OutResultData<string>> ExecuteSincronizarDespachoIndustrial(List<BEDespachoIndustrial> despachoIndustrialList);
        Task<OutResultData<List<BEDespachoIndustrial>>> ExecuteGetDespachoIndustrial(BEArgs args);
        Task<OutResultData<List<BERecepcionAcopioCabecera>>> ExecuteGetDespachoAcopioPrincipal(BEArgs args);
        Task<OutResultData<List<BEDespachoCosecha>>> ExecuteGetRecepcionesGalera(BEArgs args);
        Task<OutResultData<string>> ExecuteUpdateRecepcionGalera(BEDespachoCosecha recepcionGalera);
        Task<OutResultData<List<BEDespachoGalera>>> ExecuteSincronizarDespachoGalera(List<BEDespachoGalera> despachoGaleraList);
        Task<OutResultData<List<BERecepcionAcopio>>> ExecuteGetRecepcionesAcopio(BEArgs args);
        Task<OutResultData<List<BERecepcionDespachoCosechaI>>> ExecuteGetRecepcionesIndustrial(BEArgs args);

        //PRUEBA
        Task<OutResultData<string>> ExecuteUpdateRecepcionAcopioCabecera(BERecepcionAcopioCabecera recepcionAcopioCabecera);
        //Task<OutResultData<string>> ExecuteUpdateRecepcionAcopio(BERecepcionAcopio recepcionAcopio);

        Task<OutResultData<string>> ExecuteUpdateRecepcionIndustrial(BERecepcionIndustrial recepcionIndustrial);
        Task<OutResultData<List<BEPallet>>> ExecuteSincronizarPallets(List<BEPallet> palletList);
        Task<OutResultData<List<BEDespachoAcopio>>> ExecuteSincronizarDespachoAcopio(List<BEDespachoAcopio> despachoAcopioList);
        Task<OutResultData<string>> ExecuteSincronizarDespachoIndustrialAcopio(List<BEDespachoIndustrialAcopio> despachoIndustrialAcopioList);
    }
}
