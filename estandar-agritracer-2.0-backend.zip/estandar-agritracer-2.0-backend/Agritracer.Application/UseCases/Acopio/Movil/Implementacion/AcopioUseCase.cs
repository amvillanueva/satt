﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.Acopio.Movil;
using Agritracer.Domain.Acopio;
using Agritracer.Domain.Acopio.Movil;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Acopio.Movil.Implementacion
{
    public class AcopioUseCase : IAcopioUseCase
    {
        private readonly IAcopioRepository acopioRepository;

        public AcopioUseCase(IAcopioRepository acopioRepository)
        {
            this.acopioRepository = acopioRepository;
        }

        public async Task<OutResultData<BEDataMaestraAcopio>> ExecuteGetDataMaestra(BEArgs args)
        {
            return await this.acopioRepository.GetDataMaestra(args);
        }

        public async Task<OutResultData<List<BEDashboardAcopio>>> ExecuteGetDashboard(BEArgs args)
        {
            return await this.acopioRepository.GetDashboard(args);
        }

        public async Task<OutResultData<List<BEDespachoCosecha>>> ExecuteSincronizarDespachoCosecha(List<BEDespachoCosecha> despachoCosechaList)
        {
            return await this.acopioRepository.SincronizarDespachoCosecha(despachoCosechaList);
        }

        public async Task<OutResultData<List<BEDespachoCosecha>>> ExecuteGetRecepcionesGalera(BEArgs args)
        {
            return await this.acopioRepository.GetRecepcionesGalera(args);
        }

        public async Task<OutResultData<string>> ExecuteUpdateRecepcionGalera(BEDespachoCosecha recepcionGalera)
        {
            return await this.acopioRepository.UpdateRecepcionGalera(recepcionGalera);
        }

        public async Task<OutResultData<List<BEDespachoGalera>>> ExecuteSincronizarDespachoGalera(List<BEDespachoGalera> despachoGaleraList)
        {
            return await this.acopioRepository.SincronizarDespachoGalera(despachoGaleraList);
        }

        public async Task<OutResultData<List<BERecepcionAcopio>>> ExecuteGetRecepcionesAcopio(BEArgs args)
        {
            return await this.acopioRepository.GetRecepcionesAcopio(args);
        }

        //PRUEBA
        public async Task<OutResultData<string>> ExecuteUpdateRecepcionAcopioCabecera(BERecepcionAcopioCabecera recepcionAcopioCabecera)
        {
            return await this.acopioRepository.UpdateRecepcionAcopioAPI(recepcionAcopioCabecera);
        }

        //public async Task<OutResultData<string>> ExecuteUpdateRecepcionAcopio(BERecepcionAcopio recepcionAcopio)
        //{
        //    return await this.acopioRepository.UpdateRecepcionAcopio(recepcionAcopio);
        //}


        public async Task<OutResultData<string>> ExecuteUpdateRecepcionIndustrial(BERecepcionIndustrial recepcionIndustrial)
        {
            return await this.acopioRepository.UpdateRecepcionIndustrial(recepcionIndustrial);
        }

        public async Task<OutResultData<List<BERecepcionDespachoCosechaI>>> ExecuteGetRecepcionesIndustrial(BEArgs args)
        {
            return await this.acopioRepository.GetRecepcionesIndustrial(args);
        }


        public async Task<OutResultData<List<BEPallet>>> ExecuteSincronizarPallets(List<BEPallet> palletList)
        {
            return await this.acopioRepository.SincronizarPallets(palletList);
        }

        public async Task<OutResultData<List<BEDespachoAcopio>>> ExecuteSincronizarDespachoAcopio(List<BEDespachoAcopio> despachoAcopioList)
        {
            return await this.acopioRepository.SincronizarDespachoAcopio(despachoAcopioList);
        }

        public async Task<OutResultData<string>> ExecuteSincronizarDespachoIndustrial(List<BEDespachoIndustrial> despachoIndustrialList)
        {
            return await this.acopioRepository.SincronizarDespachoIndustrial(despachoIndustrialList);
        }

        public async Task<OutResultData<List<BEDespachoIndustrial>>> ExecuteGetDespachoIndustrial(BEArgs args)
        {
            return await this.acopioRepository.GetDespachoIndustrial(args);
        }


        public async Task<OutResultData<List<BERecepcionAcopioCabecera>>> ExecuteGetDespachoAcopioPrincipal(BEArgs args)
        {
            return await this.acopioRepository.GetDespachoAcopioPrincipal(args);
        }

        public async Task<OutResultData<string>> ExecuteSincronizarDespachoIndustrialAcopio(List<BEDespachoIndustrialAcopio> despachoIndustrialAcopioList)
        {
            return await this.acopioRepository.SincronizarDespachoIndustrialAcopio(despachoIndustrialAcopioList);
        }
    }
}
