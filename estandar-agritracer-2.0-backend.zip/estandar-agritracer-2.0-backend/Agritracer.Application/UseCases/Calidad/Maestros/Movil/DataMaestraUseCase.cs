﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.OutputObjets.calidad;
using Agritracer.Application.Repositories.Calidad.Maestros.Movil;
using Agritracer.Domain.Calidad;
using Agritracer.Domain.Calidad.Maestros.Movil;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Calidad.Maestros.Movil
{
    class DataMaestraUseCase : IDataMaestraUseCase
    {
        private readonly IDataMaestraReadWriteRepository _dataMaestraReadWriteRepository;

        public DataMaestraUseCase(IDataMaestraReadWriteRepository dataMaestraReadWriteRepository)
        {
            _dataMaestraReadWriteRepository = dataMaestraReadWriteRepository;
        }

        public async Task<OutResultData<BEDataMaestra>> Execute(int empresaID, int usuarioCodigo)
        {
            return await _dataMaestraReadWriteRepository.GetBy(empresaID, usuarioCodigo);

        }

        public async Task<ResultJSONData<BEQRLecturar>> ExecuteDataQR(String qrLecturado)
        {
            return await _dataMaestraReadWriteRepository.DataQR(qrLecturado);
        }
    }
}
