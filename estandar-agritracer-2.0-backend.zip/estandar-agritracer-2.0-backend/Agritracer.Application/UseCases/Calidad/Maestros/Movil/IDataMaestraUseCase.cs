﻿using Agritracer.Domain.Calidad.Maestros.Movil;
using Agritracer.Application.OutputObjets;
using System.Threading.Tasks;
using Agritracer.Domain.Calidad;
using System;
using Agritracer.Application.OutputObjets.calidad;

namespace Agritracer.Application.UseCases.Calidad.Maestros.Movil
{
    public interface IDataMaestraUseCase
    {
        Task<OutResultData<BEDataMaestra>> Execute(int empresaID, int usuarioCodigo);
        Task<ResultJSONData<BEQRLecturar>> ExecuteDataQR(String qrLecturado);
    }
}
