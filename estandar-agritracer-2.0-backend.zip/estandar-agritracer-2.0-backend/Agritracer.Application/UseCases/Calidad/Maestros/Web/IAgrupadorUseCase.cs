﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Calidad;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Calidad.Maestros.Web
{
    public interface IAgrupadorUseCase
    {
        Task<OutResultData<List<BEAgrupador>>> ExecGetById(int id);
        Task<OutResultData<List<BEAgrupador>>> ExecGetAll(BEArgs args);
        Task<OutResultData<BEAgrupador>> ExecInsertUpdate(BEAgrupador objeto, int accion);
        Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args);
        Task<OutResultData<DataTable>> ExecGetTipoConfig(BEArgs args);
    }
}
