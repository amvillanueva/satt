﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Calidad;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Calidad.Maestros.Web
{
    public interface ICasoUseCase
    {
        Task<OutResultData<List<BECasoDetalle>>> ExecGetById(int id);
        Task<OutResultData<List<BECaso>>> ExecGetAll(BEArgs args);
        Task<OutResultData<BECaso>> ExecInsertUpdate(BECaso caso, int accion);
        Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args);
    }
}
