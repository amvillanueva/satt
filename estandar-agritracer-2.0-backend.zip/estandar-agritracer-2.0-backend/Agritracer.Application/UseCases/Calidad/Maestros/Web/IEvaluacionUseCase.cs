﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Calidad;
using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Calidad.Maestros.Web
{
    public interface IEvaluacionUseCase
    {
        Task<OutResultData<BEEvaluacion>> ExecGetById(int id);
        Task<OutResultData<List<BEEvaluacion>>> ExecGetAll(BEArgs args);
        Task<OutResultData<BEEvaluacion>> ExecInsertUpdate(BEEvaluacion evaluacion, int accion);
        Task<OutResultData<BEEvaluacion>> ExecDeleteAllSelected(BEArgs args);
    }
}
