﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Calidad;
using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Calidad.Maestros.Web
{
    public interface IFormulaUseCase
    {
        Task<OutResultData<List<BEFormula>>> ExecGetById(int id);
        Task<OutResultData<List<BEFormula>>> ExecGetAll(BEArgs args);
        Task<OutResultData<BEEvaluacion>> ExecInsertUpdate(BEEvaluacion evaluacion);
        Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args);
    }
}
