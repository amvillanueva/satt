﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.Calidad.Maestros.Web;
using Agritracer.Domain.Calidad;
using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Calidad.Maestros.Web.Implementacion
{
    public class AgrupadorUseCase : IAgrupadorUseCase
    {
        private readonly IAgrupadorRepository agrupadorRepository;
        public AgrupadorUseCase(IAgrupadorRepository agrupadorRepository)
        {
            this.agrupadorRepository = agrupadorRepository;
        }
        public async Task<OutResultData<List<BEAgrupador>>> ExecGetById(int id)
        {
            return await this.agrupadorRepository.GetById(id);
        }
        public async Task<OutResultData<List<BEAgrupador>>> ExecGetAll(BEArgs args)
        {
            return await this.agrupadorRepository.GetAll(args);
        }
        public async Task<OutResultData<BEAgrupador>> ExecInsertUpdate(BEAgrupador objeto, int accion)
        {
            return await this.agrupadorRepository.InsertUpdate(objeto, accion);
        }
        public async Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args)
        {
            return await this.agrupadorRepository.DeleteAllSelected(args);
        }
        public async Task<OutResultData<DataTable>> ExecGetTipoConfig(BEArgs args)
        {
            return await this.agrupadorRepository.GetTipoConfig(args);
        }
    }
}
