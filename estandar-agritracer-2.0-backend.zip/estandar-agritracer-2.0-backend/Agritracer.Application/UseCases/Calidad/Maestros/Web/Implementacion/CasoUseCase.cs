﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.Calidad.Maestros.Web;
using Agritracer.Domain.Calidad;
using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Calidad.Maestros.Web.Implementacion
{
    public class CasoUseCase : ICasoUseCase
    {
        private readonly ICasoRepository casoRepository;
        public CasoUseCase(ICasoRepository casoRepository)
        {
            this.casoRepository = casoRepository;
        }
        public async Task<OutResultData<List<BECasoDetalle>>> ExecGetById(int id)
        {
            return await this.casoRepository.GetById(id);
        }
        public async Task<OutResultData<List<BECaso>>> ExecGetAll(BEArgs args)
        {
            return await this.casoRepository.GetAll(args);
        }
        public async Task<OutResultData<BECaso>> ExecInsertUpdate(BECaso caso, int accion)
        {
            return await this.casoRepository.InsertUpdate(caso, accion);
        } 
        public async Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args)
        {
            return await this.casoRepository.DeleteAllSelected(args);
        }
    }
}
