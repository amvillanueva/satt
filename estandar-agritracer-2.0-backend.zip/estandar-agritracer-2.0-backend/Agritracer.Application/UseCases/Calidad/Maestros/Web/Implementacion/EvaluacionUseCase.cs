﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.Calidad.Maestros.Web;
using Agritracer.Domain.Calidad;
using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Calidad.Maestros.Web.Implementacion
{
    public class EvaluacionUseCase : IEvaluacionUseCase
    {
        private readonly IEvaluacionRepository evaluacionRepository;
        public EvaluacionUseCase(IEvaluacionRepository evaluacionRepository)
        {
            this.evaluacionRepository = evaluacionRepository;
        }
        public async Task<OutResultData<BEEvaluacion>> ExecGetById(int id)
        {
            return await this.evaluacionRepository.GetById(id);
        }
        public async Task<OutResultData<List<BEEvaluacion>>> ExecGetAll(BEArgs args)
        {
            return await this.evaluacionRepository.GetAll(args);
        }
        public async Task<OutResultData<BEEvaluacion>> ExecInsertUpdate(BEEvaluacion evaluacion, int accion)
        {
            return await this.evaluacionRepository.InsertUpdate(evaluacion, accion);
        }
        public async Task<OutResultData<BEEvaluacion>> ExecDeleteAllSelected(BEArgs args)
        {
            return await this.evaluacionRepository.DeleteAllSelected(args);
        }
    }
}
