﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.Calidad.Maestros.Web;
using Agritracer.Domain.Calidad;
using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Calidad.Maestros.Web.Implementacion
{
    public class FormulaUseCase : IFormulaUseCase
    {
        private readonly IFormulaRepository formulaRepository;
        public FormulaUseCase(IFormulaRepository formulaRepository)
        {
            this.formulaRepository = formulaRepository;
        }
        public async Task<OutResultData<List<BEFormula>>> ExecGetById(int id)
        {
            return await this.formulaRepository.GetById(id);
        }
        public async Task<OutResultData<List<BEFormula>>> ExecGetAll(BEArgs args)
        {
            return await this.formulaRepository.GetAll(args);
        }
        public async Task<OutResultData<BEEvaluacion>> ExecInsertUpdate(BEEvaluacion evaluacion)
        {
            return await this.formulaRepository.InsertUpdate(evaluacion);
        }
        public async Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args)
        {
            return await this.formulaRepository.DeleteAllSelected(args);
        }
    }
}
