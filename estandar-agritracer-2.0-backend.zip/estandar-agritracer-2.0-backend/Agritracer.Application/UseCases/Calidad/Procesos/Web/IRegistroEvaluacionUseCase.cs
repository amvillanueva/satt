﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Calidad;
using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Calidad.Procesos.Web
{
    public interface IRegistroEvaluacionUseCase
    {
        Task<OutResultData<BERegistroEvaluacion>> ExecGetById(int id);
        Task<OutResultData<List<BERegistroEvaluacion>>> ExecGetAll(BEArgs args);
        Task<OutResultData<List<BERegistroEvaluacionDetalle>>> ExecGetDetails(int id);
        Task<OutResultData<bool>> ExecUpdate(BERegistroEvaluacion registroEvaluacion);
        Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args);
        Task<OutResultData<DataSet>> ExecReportesPersonalizados(BEArgs args);
        Task<OutResultData<string>> ExecListadoUbicaciones(BEArgs args);
        Task<OutResultData<List<BERegistroEvaluacionDetalle>>> ExecGetDatosMuestraItem(BEArgs args);
        Task<OutResultData<bool>> ExecSaveMuestrasItem(BERegistroEvaluacion datos);
        Task<OutResultData<List<BERegistroEvaluacionDetalle>>> ExecGetDatosMuestraIterativo(BEArgs args);
        Task<OutResultData<string>> ExecuteRegistrarEvaluaciones(List<BERegistroEvaluacion> datos, String pathFile);
        Task<OutResultData<List<BERegistroEvaluacion>>> ExecuteObtenerRegistroEvaluaciones(String fecha);

    }
}
