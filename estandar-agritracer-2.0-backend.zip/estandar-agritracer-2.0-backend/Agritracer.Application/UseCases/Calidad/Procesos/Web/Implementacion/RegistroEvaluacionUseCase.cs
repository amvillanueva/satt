﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.Calidad.Procesos.Web;
using Agritracer.Domain.Calidad;
using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Calidad.Procesos.Web.Implementacion
{
    public class RegistroEvaluacionUseCase : IRegistroEvaluacionUseCase
    {
        private readonly IRegistroEvaluacionRepository registroEvaluacionRepository;
        public RegistroEvaluacionUseCase(IRegistroEvaluacionRepository registroEvaluacionRepository)
        {
            this.registroEvaluacionRepository = registroEvaluacionRepository;
        }
        public async Task<OutResultData<BERegistroEvaluacion>> ExecGetById(int id)
        {
            return await this.registroEvaluacionRepository.GetById(id);
        }
        public async Task<OutResultData<List<BERegistroEvaluacion>>> ExecGetAll(BEArgs args)
        {
            return await this.registroEvaluacionRepository.GetAll(args);
        }
        public async Task<OutResultData<List<BERegistroEvaluacionDetalle>>> ExecGetDetails(int id)
        {
            return await this.registroEvaluacionRepository.GetDetails(id);
        }
        public async Task<OutResultData<bool>> ExecUpdate(BERegistroEvaluacion registroEvaluacion)
        {
            return await this.registroEvaluacionRepository.Update(registroEvaluacion);
        }
        public async Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args)
        {
            return await this.registroEvaluacionRepository.DeleteAllSelected(args);
        }
        public async Task<OutResultData<DataSet>> ExecReportesPersonalizados(BEArgs args)
        {
            return await this.registroEvaluacionRepository.ReportesPersonalizados(args);
        }
        public async Task<OutResultData<string>> ExecListadoUbicaciones(BEArgs args)
        {
            return await this.registroEvaluacionRepository.ListadoUbicaciones(args);
        }

        public async Task<OutResultData<List<BERegistroEvaluacionDetalle>>> ExecGetDatosMuestraItem(BEArgs args)
        {
            return await this.registroEvaluacionRepository.GetDatosMuestraItem(args);
        }

        public async Task<OutResultData<bool>> ExecSaveMuestrasItem(BERegistroEvaluacion datos)
        {
            return await this.registroEvaluacionRepository.SaveMuestrasItem(datos);
        }

        public async Task<OutResultData<List<BERegistroEvaluacionDetalle>>> ExecGetDatosMuestraIterativo(BEArgs args)
        {
            return await this.registroEvaluacionRepository.GetDatosMuestraIterativo(args);
        }

        public async Task<OutResultData<string>> ExecuteRegistrarEvaluaciones(List<BERegistroEvaluacion> datos, String pathFile)
        {
            return await this.registroEvaluacionRepository.RegistrarEvaluaciones(datos, pathFile);
        }

        public async Task<OutResultData<List<BERegistroEvaluacion>>> ExecuteObtenerRegistroEvaluaciones(String fecha)
        {
            return await this.registroEvaluacionRepository.ObtenerRegistrarEvaluaciones(fecha);
        }
    }
}
