﻿using System.Data;
using System.Threading.Tasks;

using Agritracer.Domain.Common;
using Agritracer.Application.OutputObjets;

namespace Agritracer.Application.UseCases.Calidad.Reportes
{
    public interface IReportesUseCase
    {
        Task<OutResultData<DataTable>> ExecuteReporteGenericoCalidadDT(BEParams args);
        Task<OutResultData<DataSet>> ExecuteReporteGenericoCalidadDS(BEParams args);
        Task<OutResultData<DataTable>> GetFotoInfomacion(string nombre, int id);
    }
}
