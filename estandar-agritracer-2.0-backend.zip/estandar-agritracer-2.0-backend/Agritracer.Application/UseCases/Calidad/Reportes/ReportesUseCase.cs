﻿using System.Data;
using System.Threading.Tasks;

using Agritracer.Domain.Common;
using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.Calidad.Reportes;
using System;

namespace Agritracer.Application.UseCases.Calidad.Reportes
{
    public class ReportesUseCase : IReportesUseCase
    {
        private readonly IReportesRepository _reporteRepository;

        public ReportesUseCase(IReportesRepository reporteRepository)
        {
            _reporteRepository = reporteRepository;
        }

        //---------------------------------------------------------------

        public async Task<OutResultData<DataTable>> ExecuteReporteGenericoCalidadDT(BEParams args)
        {
            return await _reporteRepository.GetReporteGenericoCalidadDT(args);
        }

        public async Task<OutResultData<DataSet>> ExecuteReporteGenericoCalidadDS(BEParams args)
        {
            return  await _reporteRepository.GetReporteGenericoCalidadDS(args);
        }

        public async Task<OutResultData<DataTable>> GetFotoInfomacion(string nombre, int id)
        {
            return await _reporteRepository.GetFotoInfomacion(nombre, id);
        }
    }
}
