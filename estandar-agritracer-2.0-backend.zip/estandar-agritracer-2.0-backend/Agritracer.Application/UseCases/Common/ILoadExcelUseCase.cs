﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Common
{
    public interface ILoadExcelUseCase
    {
        #region Restriccion Trabajador
        Task<OutResultData<DataSet>> ExecuteListadoRestriccionesXLSX(BELoadRestriccionTrabajadorXLSX args);
        Task<OutResultData<string>> ExecuteProcesaRestriccionesXLSX(BELoadRestriccionTrabajadorXLSX entity);
        #endregion

        //DataTable ToDataTable<T>(IList<T> data, string nroRegistro);


        Task<OutResultData<BEFormatoXlsx>> ExecuteLoadDataXlsx(BEFormatoXlsx entity);
        Task<OutResultData<string>> ExecuteProcessDataXlsx(BEParams args);

        Task<OutResultData<DataSet>> GetListFields(int formatoID);
        //Task<OutResultData<BEFormatoXlsx>> ExecuteListResultXlsx(BEFormatoXlsx entity);

        // DataTable ToDataTableFromDic<T>(List<Dictionary<string, object>> data, string nroRegistro);

        DataTable ToDataTable<T>(List<IEnumerable<string>> data, string nroRegistro);

    }
}
