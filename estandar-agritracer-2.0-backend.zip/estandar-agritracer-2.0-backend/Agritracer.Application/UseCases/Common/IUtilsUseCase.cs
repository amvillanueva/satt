﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Common
{
    public interface IUtilsUseCase
    {
        Task<OutResultData<DataSet>> GetListCombo(BEArgs args);
        Task<OutResultData<DataTable>> GetListSupervisor(BEArgs args);
        Task<OutResultData<DataSet>> GetListComboManoObra(BEArgs args);
        Task<OutResultData<DataTable>> GetListComboProduccion(BEArgs args);
        Task<OutResultData<DataSet>> GetListComboSemana();
        Task<OutResultData<DataSet>> ObtenerDatosTrabajadores(BEArgs args);
        Task<OutResultData<DataSet>> GetListComboCas(BEArgs args);
        Task<OutResultData<DataSet>> GetListComboCalidad(BEArgs args);

        #region CONTROL TRUCK
        //CONTROL TRUCK
        Task<OutResultData<DataTable>> GetListComboControlTruck(Dictionary<string, object> valuePairs);
        Task<OutResultData<DataSet>> GetListItemsControlTruck(Dictionary<string, object> valuePairs);
        Task<OutResultData<string>> DelRegistrosControlTruck(Dictionary<string, object> valuePairs);
        Task<OutResultData<string>> UpdEstadosControlTruck(Dictionary<string, object> valuePairs);

        #endregion
        Task<OutResultData<DataSet>> GetListComboControlBus(BEArgs args);
    }
}
