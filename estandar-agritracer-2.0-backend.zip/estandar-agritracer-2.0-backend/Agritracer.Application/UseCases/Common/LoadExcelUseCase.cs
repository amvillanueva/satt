﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.Common;
using Agritracer.Domain.Common;
using Agritracer.Domain.ManoObra.Maestros;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Common
{
    public class LoadExcelUseCase : ILoadExcelUseCase
    {
        private readonly ILoadExcelRepository loadExcelRepository;
        public LoadExcelUseCase(ILoadExcelRepository _loadExcelRepository)
        {
            this.loadExcelRepository = _loadExcelRepository;
        }

        #region Restriccion Trabajador

        public async Task<OutResultData<DataSet>> ExecuteListadoRestriccionesXLSX(BELoadRestriccionTrabajadorXLSX args)
        {
            string nroReg = DateTime.Today.ToString("yyMMdd") + DateTime.Now.ToString("HHmmss");

            DataTable dtTarifas = this.ToDataTable<BERestriccionTrabajadorXLSX>(args.lista_restricciones, nroReg);

            var load = await this.loadExcelRepository.CargaDatosXLS(dtTarifas, "[manoobra].[RestriccionTrabajadorInterface]");

            if (load.statusCode == 1)
            {
                args.nro_registro = nroReg;
                return await this.loadExcelRepository.ListadoDatosXLSX("[manoobra].[usp_app_listado_restricciontrabajadorinterface_xslx]", args.nro_registro);
            }
            else
                return new OutResultData<DataSet>();
        }

        public async Task<OutResultData<string>> ExecuteProcesaRestriccionesXLSX(BELoadRestriccionTrabajadorXLSX entity)
        {
            return await this.loadExcelRepository.ProcesaDatosXLSX("[manoobra].[usp_app_procesa_restricciontrabajadorinterface_xslx]", entity.nro_registro);
        }

        #endregion

        //OTRO

        public DataTable ToDataTable<T>(IList<T> data, string nroRegistro)
        {
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(typeof(T));
            DataTable table = new DataTable();

            foreach (PropertyDescriptor prop in properties)
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);

            //-----------------------------------------------------------------------------------
            table.Columns.Add("nro_registro", typeof(string));

            foreach (T item in data)
            {
                DataRow row = table.NewRow();
                //-------------------------------------------------------------
                foreach (PropertyDescriptor prop in properties)
                    row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                //-------------------------------------------------------------
                row["nro_registro"] = nroRegistro;

                table.Rows.Add(row);
            }

            return table;
        }

        //-----------------------------------------------------------------------------------------

        public async Task<OutResultData<DataSet>> GetListFields(int formatoID)
        {
            return await loadExcelRepository.GetListFields(formatoID);
        }

        public async Task<OutResultData<string>> ExecuteProcessDataXlsx(BEParams args)
        {
            return await this.loadExcelRepository.ProcessDataXlsx(args);
        }

        public async Task<OutResultData<BEFormatoXlsx>> ExecuteLoadDataXlsx(BEFormatoXlsx entity)
        {
            OutResultData<BEFormatoXlsx> resultJSON = new OutResultData<BEFormatoXlsx>();

            string nroReg = DateTime.Today.ToString("yyMMdd") + DateTime.Now.ToString("HHmmss");
            DataTable dtTarifas = ToDataTable<DataTable>(entity.lista_items, nroReg);
            string tableName = "";

            switch (entity.formato_id)
            {
                case 1:
                    tableName = "produccion.InterfacePresupuestoArandanoVariedadTemp";
                    break;
                case 2:
                    tableName = "produccion.InterfacePresupuestoArandanoTurnosTemp";
                    break;
                case 3:
                    tableName = "produccion.InterfaceProyectadoArandanoTemp";
                    break;
                case 4:
                    tableName = "produccion.InterfaceEvaluacionFrutaTemp";
                    break;
                case 5:
                    tableName = "produccion.InterfaceKilosPackingTemp";
                    break;
                case 6:
                    tableName = "produccion.InterfaceContenedoresCalidadTemp";
                    break;
                case 7:
                    tableName = "produccion.InterfaceContenedoresCostosTemp";
                    break;
                case 8:
                    tableName = "produccion.InterfaceOpexPresupuestadoTemp";
                    break;
                case 9:
                    tableName = "produccion.InterfaceOpexTemp";
                    break;
                //Block Inicio SmartData
                case 10:
                    tableName = "[smartdata].[LaminasRiegoSemanalTemp]";
                    break;
                case 11:
                    tableName = "[smartdata].[TiemposRiegoTemp]";
                    break;
                case 12:
                    tableName = "[smartdata].[CalidadAguaTemp]";
                    break;
                case 13:
                    tableName = "[smartdata].[FallasTemp]";
                    break;
                case 14:
                    tableName = "[smartdata].[CaudalesRiegoTemp]";
                    break;
                case 15:
                    tableName = "[smartdata].[SolucionSueloTemp]";
                    break;
                case 18:
                    tableName = "smartdata.DataMetereologicaTemp";
                    break;
                case 19:
                    tableName = "smartdata.FallasRiegoV2Temp";
                    break;
                case 20:
                    tableName = "smartdata.CaudalesRiegoV2Temp";
                    break;
                case 21:
                    tableName = "smartdata.CalidadAguaV2Temp";
                    break;
                case 22:
                    tableName = "[smartdata].[RegulacionPresionesTemp]";
                    break;
                case 23:
                    tableName = "[smartdata].[CaudalesDeGoteroTemp]";
                    break;
                case 24:
                    tableName = "[smartdata].[AnalisisDeAguaTemp]";
                    break;
                case 25:
                    tableName = "[smartdata].[AplicacionDeBioestimulanteTemp]";
                    break;
                case 27:
                    tableName = "[smartdata].[MonitoreoCpPhTemp]";
                    break;
                case 28:
                    tableName = "[smartdata].[SolucionSueloTempV2]";
                    break;
                case 29:
                    tableName = "[smartdata].[ConsumoDeAguaTemp]";
                    break;
                case 30:
                    tableName = "[smartdata].[BomDataPesosCalibresTemp]";
                    break;
                case 31:
                    tableName = "[smartdata].[QuimaTemp]";
                    break;

                //Block Fin SmartData
                case 16:
                    tableName = "produccion.InterfaceCapexTemp";
                    break;
                case 17:
                    tableName = "produccion.InterfaceCapexPresupuestoTemp";
                    break;
            }

            var load = await this.loadExcelRepository.CargaDatosXLS(dtTarifas, tableName);

            if (load.statusCode == 1)
            {
                entity.nro_registro = nroReg;
                return await this.loadExcelRepository.ListResultXlsx(entity);
            }
            else
            {
                resultJSON.message = load.message;
                resultJSON.statusCode = load.statusCode;
                return resultJSON;
            }
        }

        //-------------------------------------------------------------------------------------------------------

        public DataTable ToDataTableFromDic<T>(List<Dictionary<string, object>> data, string nroRegistro)
        {
            try
            {
                DataTable table = new DataTable();

                for (int i = 0; i < data.Count; i++)
                {
                    Dictionary<string, object> Dics = data[i];

                    if (i == 0)
                    {
                        foreach (KeyValuePair<string, object> col in Dics)
                            table.Columns.Add(col.Key.ToString());

                        table.Columns.Add("nro_registro", typeof(string));
                    }

                    DataRow row = table.NewRow();
                    //-------------------------------------------------------------
                    foreach (KeyValuePair<string, object> Item in Dics)
                        row[Item.Key.ToString()] = Item.Value;

                    //-------------------------------------------------------------
                    row["nro_registro"] = nroRegistro;

                    table.Rows.Add(row);
                }

                return table;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public DataTable ToDataTable<T>(List<IEnumerable<string>> data, string nroRegistro)
        {
            try
            {
                DataTable table = new DataTable();

                IEnumerator headers = data[0].GetEnumerator();
                while (headers.MoveNext())
                {
                    table.Columns.Add(headers.Current.ToString());
                }
                table.Columns.Add("nro_registro", typeof(string));

                for (int i = 1; i < data.Count; i++)
                {
                    DataRow row = table.NewRow();
                    IEnumerator records = data[i].GetEnumerator();
                    int idx = 0;
                    while (records.MoveNext())
                    {
                        row[idx] = (records.Current is string) ? (string.IsNullOrEmpty(records.Current.ToString()) ? DBNull.Value : records.Current) : records.Current;
                        idx++;
                    }
                    row["nro_registro"] = nroRegistro;
                    table.Rows.Add(row);
                }

                return table;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
