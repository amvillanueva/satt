﻿using Agritracer.Domain.Configuracion.Maestros.Movil;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Common.Maestros
{
    public interface ICultivoMovilUseCase
    {
        Task<IEnumerable<BECultivoMovil>> Execute(int empresaID);
    }
}
