﻿using Agritracer.Domain.Configuracion.Maestros;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Common.Maestros
{
    public interface IEmpresaUseCase
    {
        Task<IEnumerable<BEEmpresa>> Execute(int empresaID);
    }

}
