﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Common.Maestros;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Common.Maestros
{
    public interface ITrabajadorUseCase
    {
        Task<OutResultData<BETrabajador>> ExecuteGetByCodigo(BEArgs args);
        Task<OutResultData<List<BETrabajador>>> ExecuteGetAll(BEArgs args);
        Task<OutResultData<DataSet>> ExecuteImportar(BEArgs args);
        Task<OutResultData<BETrabajador>> ExecuteProcesar(BEArgs args);
    }
}
