﻿using Agritracer.Application.Repositories.Configuracion.Maestros;
using Agritracer.Domain.Configuracion.Maestros.Movil;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Common.Maestros.Implementacion
{
    public class CultivoMovilUseCase : ICultivoMovilUseCase
    {
        private readonly ICultivoMovilReadWriteRepository _cultivoMovilReadWriteRepository;

        public CultivoMovilUseCase(ICultivoMovilReadWriteRepository cultivoMovilReadWriteRepository)
        {
            _cultivoMovilReadWriteRepository = cultivoMovilReadWriteRepository;
        }

        public async Task<IEnumerable<BECultivoMovil>> Execute(int empresaID)
        {
            return await _cultivoMovilReadWriteRepository.GetAll(empresaID);
        }

    }

}
