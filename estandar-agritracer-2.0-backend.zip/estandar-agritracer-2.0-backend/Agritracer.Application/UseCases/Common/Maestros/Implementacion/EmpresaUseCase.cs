﻿using Agritracer.Application.Repositories.Cosecha.Maestros;
using Agritracer.Domain.Configuracion.Maestros;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Common.Maestros.Implementacion
{
    public class EmpresaUseCase : IEmpresaUseCase
    {
        private readonly IEmpresaReadWriteRepository _empresaReadWriteRepository;

        public EmpresaUseCase(IEmpresaReadWriteRepository empresaReadWriteRepository)
        {
            _empresaReadWriteRepository = empresaReadWriteRepository;
        }

        public async Task<IEnumerable<BEEmpresa>> Execute(int empresaID)
        {
            if (empresaID != -1)
            {
                List<BEEmpresa> lst = new List<BEEmpresa>();
                BEEmpresa empresaRpta = await _empresaReadWriteRepository.GetByID(empresaID);

                if (empresaRpta != null)
                {
                    if (empresaRpta.empresaID != -1)
                        lst.Add(empresaRpta);
                }

                return lst;
            }
            else
            {
                return await _empresaReadWriteRepository.GetAll();
            }
        }

    }

}
