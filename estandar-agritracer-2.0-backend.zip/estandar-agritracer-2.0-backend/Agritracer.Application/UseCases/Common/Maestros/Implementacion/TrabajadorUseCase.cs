﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.Common;
using Agritracer.Domain.Common;
using Agritracer.Domain.Common.Maestros;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Common.Maestros
{
    public class TrabajadorUseCase : ITrabajadorUseCase
    {
        private readonly ITrabajadorRepository trabajadorRepository;

        public TrabajadorUseCase(ITrabajadorRepository trabajadorRepository)
        {
            this.trabajadorRepository = trabajadorRepository;
        }

        public async Task<OutResultData<BETrabajador>> ExecuteGetByCodigo(BEArgs args)
        {
            return await this.trabajadorRepository.GetByCodigo(args);
        }

        public async Task<OutResultData<List<BETrabajador>>> ExecuteGetAll(BEArgs args)
        {
            return await this.trabajadorRepository.GetAll(args);
        }

        public async Task<OutResultData<DataSet>> ExecuteImportar(BEArgs args)
        {
            return await this.trabajadorRepository.Importar(args);
        }

        public async Task<OutResultData<BETrabajador>> ExecuteProcesar(BEArgs args)
        {
            return await this.trabajadorRepository.Procesar(args);
        }
    }
}
