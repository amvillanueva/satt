﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.Common;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Common
{
    public class UtilsUseCase : IUtilsUseCase
    {
        private readonly IUtilsRepository utilsRepository;
        public UtilsUseCase(IUtilsRepository utilsRepository)
        {
            this.utilsRepository = utilsRepository;
        }
        public async Task<OutResultData<DataSet>> GetListCombo(BEArgs args)
        {
            return await utilsRepository.GetListCombo(args);
        }
        public async Task<OutResultData<DataSet>> GetListComboSemana()
        {
            return await utilsRepository.GetListComboSemana();
        }
        public async Task<OutResultData<DataTable>> GetListSupervisor(BEArgs args)
        {
            return await utilsRepository.GetListSupervisor(args);
        }
        public async Task<OutResultData<DataSet>> GetListComboManoObra(BEArgs args)
        {
            return await utilsRepository.GetListComboManoObra(args);
        }
        public async Task<OutResultData<DataTable>> GetListComboProduccion(BEArgs args)
        {
            return await utilsRepository.GetListComboProduccion(args);
        }
        public async Task<OutResultData<DataSet>> ObtenerDatosTrabajadores(BEArgs args)
        {
            return await utilsRepository.ObtenerDatosTrabajadores(args);
        }
        public async Task<OutResultData<DataSet>> GetListComboCas(BEArgs args)
        {
            return await utilsRepository.GetListComboCas(args);
        }

        public async Task<OutResultData<DataSet>> GetListComboCalidad(BEArgs args)
        {
            return await utilsRepository.GetListComboCalidad(args);
        }

        #region CONTROL TRUCK
        //MAQUINARIA
        public async Task<OutResultData<DataTable>> GetListComboControlTruck(Dictionary<string, object> valuePairs)
        {
            return await utilsRepository.GetListComboControlTruck(valuePairs);
        }

        public async Task<OutResultData<DataSet>> GetListItemsControlTruck(Dictionary<string, object> valuePairs)
        {
            return await utilsRepository.GetListItemsControlTruck(valuePairs);
        }

        public async Task<OutResultData<string>> DelRegistrosControlTruck(Dictionary<string, object> valuePairs)
        {
            return await this.utilsRepository.DelRegistrosControlTruck(valuePairs);
        }

        public async Task<OutResultData<string>> UpdEstadosControlTruck(Dictionary<string, object> valuePairs)
        {
            return await this.utilsRepository.UpdEstadosControlTruck(valuePairs);
        }

        #endregion
        public async Task<OutResultData<DataSet>> GetListComboControlBus(BEArgs args)
        {
            return await utilsRepository.GetListComboControlBus(args);
        }
    }
}
