﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Configuracion.Agrupadores;
using Agritracer.Application.Repositories.Configuracion.Agrupadores;
using System.Collections.Generic;
using System.Threading.Tasks;
using Agritracer.Domain.Common;

namespace Agritracer.Application.UseCases.Configuracion.Agrupadores.CecoActividadModulo
{
    public class CecoActividadModuloUseCase : ICecoActividadModuloUseCase
    {
        private readonly ICecoActividadModuloRepository cecoActividadModuloRepository;

        public CecoActividadModuloUseCase(ICecoActividadModuloRepository cecoActividadModuloRepository)
        {
            this.cecoActividadModuloRepository = cecoActividadModuloRepository;
        }

        public async Task<OutResultData<BECecoActividadModulo>> ExecuteGetById(int id)
        {
            return await this.cecoActividadModuloRepository.GetById(id);
        }

        public async Task<OutResultData<List<BECecoActividadModulo>>> ExecuteGetAll(BEArgs args)
        {
            return await this.cecoActividadModuloRepository.GetAll(args);
        }

        public async Task<OutResultData<BECecoActividadModulo>> ExecuteInsUpdDel(BECecoActividadModulo objeto, int accion)
        {
            return await this.cecoActividadModuloRepository.InsUpdDel(objeto, accion);
        }

        public async Task<OutResultData<BECecoActividadModulo>> ExecuteDeleteAllSelected(BEArgs args)
        {
            return await this.cecoActividadModuloRepository.DeleteAllSelected(args);
        }
    }
}
