﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Configuracion.Agrupadores;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Configuracion.Agrupadores.CecoActividadModulo
{
    public interface ICecoActividadModuloUseCase
    {
        Task<OutResultData<BECecoActividadModulo>> ExecuteGetById(int id);
        Task<OutResultData<List<BECecoActividadModulo>>> ExecuteGetAll(BEArgs args);
        Task<OutResultData<BECecoActividadModulo>> ExecuteInsUpdDel(BECecoActividadModulo objeto, int accion);
        Task<OutResultData<BECecoActividadModulo>> ExecuteDeleteAllSelected(BEArgs args);
    }
}
