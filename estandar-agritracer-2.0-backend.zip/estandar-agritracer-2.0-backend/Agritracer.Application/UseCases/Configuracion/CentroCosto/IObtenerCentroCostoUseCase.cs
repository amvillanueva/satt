﻿using Agritracer.Domain.Configuracion;
using Agritracer.Domain.Cosecha;
using Agritracer.Domain.Configuracion.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public interface IObtenerCentroCostoUseCase
    {
        Task<IEnumerable<BECentroCosto>> Execute(int cecoID,int empresaID,string descripcion,int estado);
    }
}
