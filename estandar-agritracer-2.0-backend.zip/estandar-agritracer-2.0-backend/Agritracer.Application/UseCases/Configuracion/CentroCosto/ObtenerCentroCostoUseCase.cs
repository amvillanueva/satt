﻿using Agritracer.Application.Repositories.Cosecha.Maestros;
using Agritracer.Domain.Configuracion;
using Agritracer.Domain.Cosecha;
using Agritracer.Domain.Configuracion.Maestros;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public class ObtenerCentroCostoUseCase : IObtenerCentroCostoUseCase
    {
        private readonly ICentroCostoReadWriteRepository _centroCostoReadWriteRepository;

        public ObtenerCentroCostoUseCase(ICentroCostoReadWriteRepository centroCostoReadWriteRepository)
        {
            _centroCostoReadWriteRepository = centroCostoReadWriteRepository;
        }

        public async Task<IEnumerable<BECentroCosto>> Execute(int cecoID,int empresaID,string descripcion,int estado)
        {
            if (cecoID != -1)
            {
                List<BECentroCosto> lst = new List<BECentroCosto>();
                BECentroCosto cecoRpta = await _centroCostoReadWriteRepository.GetByID(cecoID);

                if (cecoRpta != null)
                {
                    if(cecoRpta.centroCostoID!=-1)
                        lst.Add(cecoRpta);
                }
                return lst;
            }
            else
            {
                return await _centroCostoReadWriteRepository.GetAll(empresaID,String.IsNullOrEmpty(descripcion)?"":descripcion,estado);
            }
        }
    }
}
