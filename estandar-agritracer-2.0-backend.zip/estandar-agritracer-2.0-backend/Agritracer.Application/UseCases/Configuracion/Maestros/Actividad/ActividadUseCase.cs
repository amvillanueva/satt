﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Configuracion.Maestros;
using Agritracer.Application.Repositories.Configuracion.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;
using Agritracer.Domain.Common;

namespace Agritracer.Application.UseCases.Configuracion.Maestros.Actividad
{
    public class ActividadUseCase : IActividadUseCase
    {
        private readonly IActividadRepository actividadRepository;

        public ActividadUseCase(IActividadRepository actividadRepository)
        {
            this.actividadRepository = actividadRepository;
        }

        public async Task<OutResultData<BEActividad>> ExecuteGetById(int id)
        {
            return await this.actividadRepository.GetById(id);
        }

        public async Task<OutResultData<List<BEActividad>>> ExecuteGetAll(BEArgs args)
        {
            return await this.actividadRepository.GetAll(args);
        }

        public async Task<OutResultData<BEActividad>> ExecuteInsUpdDel(BEActividad objeto, int accion)
        {
            return await this.actividadRepository.InsUpdDel(objeto, accion);
        }

        public async Task<OutResultData<BEActividad>> ExecuteDeleteAllSelected(BEArgs args)
        {
            return await this.actividadRepository.DeleteAllSelected(args);
        }
    }
}
