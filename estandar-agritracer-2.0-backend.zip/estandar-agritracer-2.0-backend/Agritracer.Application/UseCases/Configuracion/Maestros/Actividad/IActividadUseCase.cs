﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Configuracion.Maestros;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Configuracion.Maestros.Actividad
{
    public interface IActividadUseCase
    {
        Task<OutResultData<BEActividad>> ExecuteGetById(int id);
        Task<OutResultData<List<BEActividad>>> ExecuteGetAll(BEArgs args);
        Task<OutResultData<BEActividad>> ExecuteInsUpdDel(BEActividad objeto, int accion);
        Task<OutResultData<BEActividad>> ExecuteDeleteAllSelected(BEArgs args);
    }
}
