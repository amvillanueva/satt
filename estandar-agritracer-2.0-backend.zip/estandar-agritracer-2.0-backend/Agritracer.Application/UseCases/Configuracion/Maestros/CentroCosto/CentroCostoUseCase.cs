﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Configuracion.Maestros;
using Agritracer.Application.Repositories.Configuracion.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;
using Agritracer.Domain.Common;

namespace Agritracer.Application.UseCases.Configuracion.Maestros.CentroCosto
{
    public class CentroCostoUseCase : ICentroCostoUseCase
    {
        private readonly ICentroCostoRepository centroCostoRepository;

        public CentroCostoUseCase(ICentroCostoRepository centroCostoRepository)
        {
            this.centroCostoRepository = centroCostoRepository;
        }

        public async Task<OutResultData<BECentroCosto>> ExecuteGetById(int id)
        {
            return await this.centroCostoRepository.GetById(id);
        }

        public async Task<OutResultData<List<BECentroCosto>>> ExecuteGetAll(BEArgs args)
        {
            return await this.centroCostoRepository.GetAll(args);
        }

        public async Task<OutResultData<BECentroCosto>> ExecuteInsUpdDel(BECentroCosto objeto, int accion)
        {
            return await this.centroCostoRepository.InsUpdDel(objeto, accion);
        }

        public async Task<OutResultData<BECentroCosto>> ExecuteDeleteAllSelected(BEArgs args)
        {
            return await this.centroCostoRepository.DeleteAllSelected(args);
        }
    }
}
