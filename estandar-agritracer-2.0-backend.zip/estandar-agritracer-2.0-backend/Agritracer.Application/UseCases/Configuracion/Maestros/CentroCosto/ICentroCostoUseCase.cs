﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Configuracion.Maestros;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Configuracion.Maestros.CentroCosto
{
    public interface ICentroCostoUseCase
    {
        Task<OutResultData<BECentroCosto>> ExecuteGetById(int id);
        Task<OutResultData<List<BECentroCosto>>> ExecuteGetAll(BEArgs args);
        Task<OutResultData<BECentroCosto>> ExecuteInsUpdDel(BECentroCosto objeto, int accion);
        Task<OutResultData<BECentroCosto>> ExecuteDeleteAllSelected(BEArgs args);
    }
}
