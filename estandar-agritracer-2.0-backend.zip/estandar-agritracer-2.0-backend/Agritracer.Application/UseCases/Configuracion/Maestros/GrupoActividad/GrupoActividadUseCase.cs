﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Configuracion.Maestros;
using Agritracer.Application.Repositories.Configuracion.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;
using Agritracer.Domain.Common;

namespace Agritracer.Application.UseCases.Configuracion.Maestros.GrupoActividad
{
    public class GrupoActividadUseCase : IGrupoActividadUseCase
    {
        private readonly IGrupoActividadRepository grupoActividadRepository;

        public GrupoActividadUseCase(IGrupoActividadRepository grupoActividadRepository)
        {
            this.grupoActividadRepository = grupoActividadRepository;
        }

        public async Task<OutResultData<BEGrupoActividad>> ExecuteGetById(int id)
        {
            return await this.grupoActividadRepository.GetById(id);
        }

        public async Task<OutResultData<List<BEGrupoActividad>>> ExecuteGetAll(BEArgs args)
        {
            return await this.grupoActividadRepository.GetAll(args);
        }

        public async Task<OutResultData<BEGrupoActividad>> ExecuteInsUpdDel(BEGrupoActividad objeto, int accion)
        {
            return await this.grupoActividadRepository.InsUpdDel(objeto, accion);
        }

        public async Task<OutResultData<BEGrupoActividad>> ExecuteDeleteAllSelected(BEArgs args)
        {
            return await this.grupoActividadRepository.DeleteAllSelected(args);
        }
    }
}
