﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Configuracion.Maestros;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Configuracion.Maestros.GrupoActividad
{
    public interface IGrupoActividadUseCase
    {
        Task<OutResultData<BEGrupoActividad>> ExecuteGetById(int id);
        Task<OutResultData<List<BEGrupoActividad>>> ExecuteGetAll(BEArgs args);
        Task<OutResultData<BEGrupoActividad>> ExecuteInsUpdDel(BEGrupoActividad objeto, int accion);
        Task<OutResultData<BEGrupoActividad>> ExecuteDeleteAllSelected(BEArgs args);
    }
}
