﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Configuracion.Maestros;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Configuracion.Maestros
{
    public interface IListaNegraUseCase
    {
        Task<OutResultData<BEListaNegra>> ExecuteGetById(int id);
        Task<OutResultData<List<BEListaNegra>>> ExecuteGetAll(BEArgs args);
        Task<OutResultData<BEListaNegra>> ExecuteInsUpdDel(BEListaNegra objeto, int accion);
        Task<OutResultData<BEListaNegra>> ExecuteDeleteAllSelected(BEArgs args);
    }
}
