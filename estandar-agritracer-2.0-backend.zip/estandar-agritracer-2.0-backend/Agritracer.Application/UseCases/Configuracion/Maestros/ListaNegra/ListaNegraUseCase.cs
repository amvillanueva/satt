﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Configuracion.Maestros;
using Agritracer.Application.Repositories.Configuracion.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;
using Agritracer.Domain.Common;

namespace Agritracer.Application.UseCases.Configuracion.Maestros
{
    public class ListaNegraUseCase : IListaNegraUseCase
    {
        private readonly IListaNegraRepository listaNegraRepository;

        public ListaNegraUseCase(IListaNegraRepository _listaNegraRepository)
        {
            listaNegraRepository = _listaNegraRepository;
        }

        public async Task<OutResultData<BEListaNegra>> ExecuteGetById(int id)
        {
            return await listaNegraRepository.GetById(id);
        }

        public async Task<OutResultData<List<BEListaNegra>>> ExecuteGetAll(BEArgs args)
        {
            return await listaNegraRepository.GetAll(args);
        }

        public async Task<OutResultData<BEListaNegra>> ExecuteInsUpdDel(BEListaNegra objeto, int accion)
        {
            return await listaNegraRepository.InsUpdDel(objeto, accion);
        }

        public async Task<OutResultData<BEListaNegra>> ExecuteDeleteAllSelected(BEArgs args)
        {
            return await listaNegraRepository.DeleteAllSelected(args);
        }
    }
}
