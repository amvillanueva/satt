﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Configuracion.Maestros;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Data;

namespace Agritracer.Application.UseCases.Configuracion.Maestros.Persona
{
    public interface IPersonaUseCase
    {
        Task<OutResultData<BEPersona>> ExecuteGetById(int id);
        Task<OutResultData<DataTable>> ExecuteGetListaNegraTrabajador(int idtrabajador);
        Task<OutResultData<List<BEPersona>>> ExecuteGetAll(BEArgs args);
        Task<OutResultData<BEPersona>> ExecuteInsUpdDel(BEPersona objeto, int accion);
        Task<OutResultData<BEPersona>> ExecuteDeleteAllSelected(BEArgs args);
        Task<OutResultData<List<BETrabajadorPersona>>> ExecuteGetTrabajadores(BEArgs args);
        Task<OutResultData<DataSet>> ExecuteImportar(BEArgs args);
        Task<OutResultData<BEPersona>> ExecuteProcesar(BEArgs args);
    }
}
