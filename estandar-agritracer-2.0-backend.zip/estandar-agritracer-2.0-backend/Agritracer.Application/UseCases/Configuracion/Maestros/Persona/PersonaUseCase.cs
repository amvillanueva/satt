﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Configuracion.Maestros;
using Agritracer.Application.Repositories.Configuracion.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;
using Agritracer.Domain.Common;
using System.Data;

namespace Agritracer.Application.UseCases.Configuracion.Maestros.Persona
{
    public class PersonaUseCase : IPersonaUseCase
    {
        private readonly IPersonaRepository personaRepository;

        public PersonaUseCase(IPersonaRepository personaRepository)
        {
            this.personaRepository = personaRepository;
        }

        public async Task<OutResultData<BEPersona>> ExecuteGetById(int id)
        {
            return await this.personaRepository.GetById(id);
        }

        public async Task<OutResultData<DataTable>> ExecuteGetListaNegraTrabajador(int idtrabajador)
        {
            return await this.personaRepository.GetListaNegraTrabajador(idtrabajador);
        }

        public async Task<OutResultData<List<BEPersona>>> ExecuteGetAll(BEArgs args)
        {
            return await this.personaRepository.GetAll(args);
        }

        public async Task<OutResultData<BEPersona>> ExecuteInsUpdDel(BEPersona objeto, int accion)
        {
            return await this.personaRepository.InsUpdDel(objeto, accion);
        }

        public async Task<OutResultData<BEPersona>> ExecuteDeleteAllSelected(BEArgs args)
        {
            return await this.personaRepository.DeleteAllSelected(args);
        }

        public async Task<OutResultData<List<BETrabajadorPersona>>> ExecuteGetTrabajadores(BEArgs args)
        {
            return await this.personaRepository.GetTrabajadores(args);
        }
        public async Task<OutResultData<DataSet>> ExecuteImportar(BEArgs args)
        {
            return await this.personaRepository.Importar(args);
        }
        public async Task<OutResultData<BEPersona>> ExecuteProcesar(BEArgs args)
        {
            return await this.personaRepository.Procesar(args);
        }
    }
}
