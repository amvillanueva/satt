﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Configuracion.Maestros;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Configuracion.Maestros.RangoCategoria
{
    public interface IRangoCategoriaUseCase
    {
        Task<OutResultData<BERangoCategoria>> ExecuteGetById(int id);
        Task<OutResultData<List<BERangoCategoria>>> ExecuteGetAll(BEArgs args);
        Task<OutResultData<BERangoCategoria>> ExecuteInsUpdDel(BERangoCategoria cultivo, int accion);
        Task<OutResultData<BERangoCategoria>> ExecuteDeleteAllSelected(BEArgs args);
    }
}
