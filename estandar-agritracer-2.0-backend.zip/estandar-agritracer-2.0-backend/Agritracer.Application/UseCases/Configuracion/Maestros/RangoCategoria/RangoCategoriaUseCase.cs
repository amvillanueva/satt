﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Configuracion.Maestros;
using Agritracer.Application.Repositories.Configuracion.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;
using Agritracer.Domain.Common;

namespace Agritracer.Application.UseCases.Configuracion.Maestros.RangoCategoria
{
    public class RangoCategoriaUseCase : IRangoCategoriaUseCase
    {
        private readonly IRangoCategoriaRepository rangoCategoriaRepository;
        public RangoCategoriaUseCase(IRangoCategoriaRepository rangoCategoriaRepository)
        {
            this.rangoCategoriaRepository = rangoCategoriaRepository;
        }
        public async Task<OutResultData<BERangoCategoria>> ExecuteGetById(int id)
        {
            return await this.rangoCategoriaRepository.GetById(id);
        }
        public async Task<OutResultData<List<BERangoCategoria>>> ExecuteGetAll(BEArgs args)
        {
            return await this.rangoCategoriaRepository.GetAll(args);
        }
        public async Task<OutResultData<BERangoCategoria>> ExecuteInsUpdDel(BERangoCategoria rangoCategoria, int accion)
        {
            return await this.rangoCategoriaRepository.InsUpdDel(rangoCategoria, accion);
        }
        public async Task<OutResultData<BERangoCategoria>> ExecuteDeleteAllSelected(BEArgs args)
        {
            return await this.rangoCategoriaRepository.DeleteAllSelected(args);
        }

    }
}
