﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Configuracion.Maestros;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Data;

namespace Agritracer.Application.UseCases.Configuracion.Maestros.RangoVariedad
{
    public interface IRangoVariedadUseCase
    {
        Task<OutResultData<BERangoVariedad>> ExecuteGetById(int id);
        Task<OutResultData<List<BERangoVariedad>>> ExecuteGetAll(int consulta,int modulo,int variedad);
        Task<OutResultData<BERangoVariedad>> ExecuteInsUpdDel(BERangoVariedad entity, int accion);
        Task<OutResultData<BERangoVariedad>> ExecuteDeleteAllSelected(BEArgs args);
    }
}
