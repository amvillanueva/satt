﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.Configuracion.Maestros;
using Agritracer.Domain.Common;
using Agritracer.Domain.Configuracion.Maestros;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Configuracion.Maestros.RangoVariedad
{
    public class RangoVariedadUseCase : IRangoVariedadUseCase
    {
        private readonly IRangoVariedadRepository rangoVariedadRepository;
        public RangoVariedadUseCase(IRangoVariedadRepository rangoVariedadRepository)
        {
            this.rangoVariedadRepository = rangoVariedadRepository;
        }
        public async Task<OutResultData<BERangoVariedad>> ExecuteDeleteAllSelected(BEArgs args)
        {
            return await this.rangoVariedadRepository.DeleteAllSelected(args);
        }

        public async Task<OutResultData<BERangoVariedad>> ExecuteGetById(int id)
        {
            return await this.rangoVariedadRepository.GetById(id);
        }

        public async Task<OutResultData<BERangoVariedad>> ExecuteInsUpdDel(BERangoVariedad entity, int accion)
        {
            return await this.rangoVariedadRepository.InsUpdDel(entity, accion);
        }

        public async Task<OutResultData<List<BERangoVariedad>>> ExecuteGetAll(int consulta, int modulo, int variedad)
        {
            return await this.rangoVariedadRepository.GetAll(consulta,modulo,variedad);
        }
    }
}
