﻿using Agritracer.Domain.Configuracion.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Configuracion.Maestros.TablaDetalle
{
    public interface IObtenerTablaDetalleUseCase
    {
        Task<IEnumerable<BETablaDetalle>> Execute(int idPadre, int detalleID);
    }
}
