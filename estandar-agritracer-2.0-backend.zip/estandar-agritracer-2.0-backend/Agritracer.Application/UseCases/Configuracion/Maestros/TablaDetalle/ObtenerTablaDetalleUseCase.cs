﻿using Agritracer.Application.Repositories.Configuracion.Maestros;
using Agritracer.Domain.Configuracion.Maestros;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Configuracion.Maestros.TablaDetalle
{
    public class ObtenerTablaDetalleUseCase : IObtenerTablaDetalleUseCase
    {
        private readonly ITablaDetalleReadWriteRepository _tablaDetalleReadWriteRepository;

        public ObtenerTablaDetalleUseCase(ITablaDetalleReadWriteRepository tablaDetalleReadWriteRepository)
        {
            _tablaDetalleReadWriteRepository = tablaDetalleReadWriteRepository;
        }

        public async Task<IEnumerable<BETablaDetalle>> Execute(int idPadre, int idHijo)
        {
            if (idHijo != -1)
            {
                List<BETablaDetalle> lst = new List<BETablaDetalle>();
                BETablaDetalle tablaMaestraRpta = await _tablaDetalleReadWriteRepository.GetByID(idPadre, idHijo);

                if (tablaMaestraRpta != null)
                {
                    if (tablaMaestraRpta.maestraID != -1)
                        lst.Add(tablaMaestraRpta);
                }

                return lst;
            }
            else
            {
                return await _tablaDetalleReadWriteRepository.GetAll(idPadre);
            }
        }
    }
}
