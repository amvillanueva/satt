﻿using Agritracer.Application.OutputObjets.Configuracion.Maestros;
using Agritracer.Application.Repositories.Configuracion.Maestros;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Configuracion.Maestros.TablaMestra
{
    public class EliminarTablaMaestraUseCase : IEliminarTablaMaestraUseCase
    {
        private readonly ITablaMaestraReadWriteRepository _maestraReadWriteRepository;

        public EliminarTablaMaestraUseCase(ITablaMaestraReadWriteRepository maestraReadWriteRepository)
        {
            _maestraReadWriteRepository = maestraReadWriteRepository;
        }

        public async Task<OutTablaMaestraUseCase> Execute(List<int> maestraIDs)
        {
            return await _maestraReadWriteRepository.Delete(maestraIDs);
        }
    }
}
