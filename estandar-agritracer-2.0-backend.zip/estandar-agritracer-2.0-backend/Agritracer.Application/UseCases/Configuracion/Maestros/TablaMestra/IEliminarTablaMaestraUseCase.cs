﻿using Agritracer.Application.OutputObjets.Configuracion.Maestros;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Configuracion.Maestros.TablaMestra
{
    public interface IEliminarTablaMaestraUseCase
    {
        Task<OutTablaMaestraUseCase> Execute(List<int> maestrosIds);
    }
}
