﻿using Agritracer.Domain.Configuracion.Maestros;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Configuracion.Maestros.TablaMestra
{
    public interface INuevoActTablaMaestraUseCase
    {
        Task<BETablaMaestra> Execute(BETablaMaestra maestra);
    }
}
