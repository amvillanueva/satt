﻿
using Agritracer.Domain.Configuracion.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Configuracion.Maestros.TablaMestra
{
    public interface IObtenerTablaMaestraUseCase
    {
        Task<IEnumerable<BETablaMaestra>> Execute(int detalleID);
    }
}
