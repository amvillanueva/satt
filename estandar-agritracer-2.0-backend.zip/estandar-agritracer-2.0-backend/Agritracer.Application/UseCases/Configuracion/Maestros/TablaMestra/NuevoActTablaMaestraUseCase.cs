﻿using Agritracer.Application.Repositories.Configuracion.Maestros;
using Agritracer.Domain.Configuracion.Maestros;
using System;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Agritracer.Application.UseCases.Configuracion.Maestros.TablaMestra
{
    public class NuevoActTablaMaestraUseCase : INuevoActTablaMaestraUseCase
    {
        private readonly ITablaMaestraReadWriteRepository _maestraReadWriteRepository;

        public NuevoActTablaMaestraUseCase(ITablaMaestraReadWriteRepository maestraReadWriteRepository)
        {
            _maestraReadWriteRepository = maestraReadWriteRepository;
        }

        public async Task<BETablaMaestra> Execute(BETablaMaestra maestra)
        {
            try
            {
                string xml = "";
                var xEle = new XElement("r",
                from detalle in maestra.maestraDetalles
                select new XElement("detalle",
                    new XAttribute("detalleID", detalle.detalleID),
                    new XAttribute("detalleNombre", detalle.detalleNombre),
                    new XAttribute("detalleDescripcion", detalle.detalleDescripcion),
                    new XAttribute("detalleStatus", detalle.detalleStatus)));

                xml = Convert.ToString(xEle);
                maestra.maestraDetallesXML = xml;

                return await _maestraReadWriteRepository.AddUpdate(maestra);
            }
            catch (Exception ex)
            {
                return new BETablaMaestra()
                {
                    maestraID = -1,
                    maestraIdServidor = -1,
                    maestraMsgServidor = ex.Message
                };
            }
        }
    }
}
