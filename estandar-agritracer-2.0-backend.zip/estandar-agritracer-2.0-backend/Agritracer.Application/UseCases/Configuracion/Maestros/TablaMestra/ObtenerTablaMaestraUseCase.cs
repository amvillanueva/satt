﻿using Agritracer.Application.Repositories.Configuracion.Maestros;
using Agritracer.Domain.Configuracion.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Configuracion.Maestros.TablaMestra
{
    public class ObtenerTablaMaestraUseCase : IObtenerTablaMaestraUseCase
    {
        private readonly ITablaMaestraReadWriteRepository _tablaMaestraReadWriteRepository;

        public ObtenerTablaMaestraUseCase(ITablaMaestraReadWriteRepository tablaMaestraReadWriteRepository)
        {
            _tablaMaestraReadWriteRepository = tablaMaestraReadWriteRepository;
        }

        public async Task<IEnumerable<BETablaMaestra>> Execute(int empresaID)
        {
            if (empresaID != -1)
            {
                List<BETablaMaestra> lst = new List<BETablaMaestra>();
                BETablaMaestra tablaMaestraRpta = await _tablaMaestraReadWriteRepository.GetByID(empresaID);

                if (tablaMaestraRpta != null)
                {
                    if (tablaMaestraRpta.maestraID != -1)
                        lst.Add(tablaMaestraRpta);
                }

                return lst;
            }
            else
            {
                return await _tablaMaestraReadWriteRepository.GetAll();
            }
        }
    }
}
