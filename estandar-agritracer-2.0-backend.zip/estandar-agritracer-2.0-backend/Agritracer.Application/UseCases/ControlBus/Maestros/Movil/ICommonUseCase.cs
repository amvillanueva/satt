﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ControlBus;
using Agritracer.Domain.ControlBus.Movil;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Maestros.Movil
{
    public interface ICommonUseCase
    {
        Task<OutResultData<BEDataMaestra>> ExecuteDataMaestra(int IdUsuario, int IdEmpresa);
        Task<OutResultData<BEViajeDetalle>> ExecuteDatosPasajero(string CodTrabajador, int IdEmpresa);
        Task<OutResultData<List<BEViajeDetalle>>> ExecuteDatosPasajerosList(List<BEViajeDetalle> listViajeDetalle);
    }
}
