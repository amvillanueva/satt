﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ControlBus.Maestros.Movil;
using Agritracer.Domain.ControlBus;
using Agritracer.Domain.ControlBus.Movil;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Maestros.Movil.Implementacion
{
    public class CommonUseCase : ICommonUseCase
    {
        private readonly ICommonRepository _commonRepository;

        public CommonUseCase(ICommonRepository commonRepository)
        {
            _commonRepository = commonRepository;
        }

        public async Task<OutResultData<BEDataMaestra>> ExecuteDataMaestra(int IdUsuario, int IdEmpresa)
        {
            return await _commonRepository.DataMaestra(IdUsuario, IdEmpresa);
        }

        public async Task<OutResultData<BEViajeDetalle>> ExecuteDatosPasajero(string CodTrabajador, int IdEmpresa)
        {
            return await _commonRepository.DatosPasajero(CodTrabajador, IdEmpresa);
        }

        public async Task<OutResultData<List<BEViajeDetalle>>> ExecuteDatosPasajerosList(List<BEViajeDetalle> listViajeDetalle)
        {
            return await _commonRepository.DatosPasajerosList(listViajeDetalle);
        }
    }
}
