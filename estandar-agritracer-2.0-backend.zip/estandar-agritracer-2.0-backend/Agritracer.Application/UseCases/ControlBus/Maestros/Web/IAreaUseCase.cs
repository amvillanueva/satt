﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Maestros.Web
{
    public interface IAreaUseCase
    {
        Task<OutResultData<List<BEArea>>> ExecGetAll(BEArgs args);
        Task<OutResultData<BEArea>> ExecInsertUpdate(BEArea entity, int accion);
        Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args);
    }
}
