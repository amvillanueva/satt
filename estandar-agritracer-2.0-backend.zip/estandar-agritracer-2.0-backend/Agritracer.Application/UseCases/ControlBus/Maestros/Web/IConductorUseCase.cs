﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Maestros
{
    public interface IConductorUseCase
    {
        Task<OutResultData<BEConductor>> ExecGetById(int id);
        Task<OutResultData<List<BEConductor>>> ExecGetAll(BEArgs args);
        Task<OutResultData<BEConductor>> ExecInsertUpdate(BEConductor entity, int accion);
        Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args);
        Task<OutResultData<BEConductor>> ExecGestionUsuarios(BEConductor entity, int accion);
    }
}
