﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Maestros.Web
{
    public interface IDenominacionCecoUseCase
    {
        Task<OutResultData<List<BEDenominacionCeco>>> ExecGetAll(BEArgs args);
        Task<OutResultData<BEDenominacionCeco>> ExecInsertUpdate(BEDenominacionCeco entity, int accion);
        Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args);
    }
}
