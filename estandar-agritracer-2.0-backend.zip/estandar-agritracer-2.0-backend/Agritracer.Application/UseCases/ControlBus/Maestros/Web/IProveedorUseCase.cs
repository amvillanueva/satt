﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using Agritracer.Domain.Seguridad;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Maestros
{
    public interface IProveedorUseCase
    {
        Task<OutResultData<BEProveedor>> ExecGetById(int id);
        Task<OutResultData<List<BEProveedor>>> ExecGetAll(BEArgs args);
        Task<OutResultData<BEProveedor>> ExecInsertUpdate(BEProveedor entity, int accion);
        Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args);
        Task<OutResultData<BEUsuarioWeb>> ExecGestionUsuarios(BEUsuarioWeb entity, int accion);
        Task<OutResultData<BEProveedorTarifa>> ExecGestionTarifas(BEProveedor entity, int accion);
    }
}
