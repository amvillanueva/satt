﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Maestros
{
    public interface IRutaUseCase
    {
        Task<OutResultData<BERuta>> ExecGetById(int id);
        Task<OutResultData<List<BERuta>>> ExecGetAll(BEArgs args);
        Task<OutResultData<BERuta>> ExecInsertUpdate(BERuta entity, int accion);
        Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args);
    }
}
