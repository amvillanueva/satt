﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Maestros.Web
{
    public interface IUbigeoUseCase
    {
        Task<OutResultData<List<BEUbigeo>>> ExecGetAll(BEArgs args);
        Task<OutResultData<BEUbigeo>> ExecInsertUpdate(BEUbigeo entity, int accion);
        Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args);
    }
}
