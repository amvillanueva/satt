﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ControlBus.Maestros;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Maestros.Web.Implementacion
{
    public class BusUseCase : IBusUseCase
    {
        private readonly IBusRepository busRepository;
        public BusUseCase(IBusRepository busRepository)
        {
            this.busRepository = busRepository;
        }
        public async Task<OutResultData<BEBus>> ExecGetById(int id)
        {
            return await this.busRepository.GetById(id);
        }
        public async Task<OutResultData<List<BEBus>>> ExecGetAll(BEArgs args)
        {
            return await this.busRepository.GetAll(args);
        }
        public async Task<OutResultData<BEBus>> ExecInsertUpdate(BEBus entity, int accion)
        {
            return await this.busRepository.InsertUpdate(entity, accion);
        }
        public async Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args)
        {
            return await this.busRepository.DeleteAllSelected(args);
        }
    }
}
