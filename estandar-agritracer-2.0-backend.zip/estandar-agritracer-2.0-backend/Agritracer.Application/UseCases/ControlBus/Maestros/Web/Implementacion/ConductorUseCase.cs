﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ControlBus.Maestros;
using Agritracer.Domain.Common;
using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Maestros.Web.Implementacion
{
    public class ConductorUseCase : IConductorUseCase
    {
        private readonly IConductorRepository conductorRepository;
        public ConductorUseCase(IConductorRepository conductorRepository)
        {
            this.conductorRepository = conductorRepository;
        }
        public async Task<OutResultData<BEConductor>> ExecGetById(int id)
        {
            return await this.conductorRepository.GetById(id);
        }
        public async Task<OutResultData<List<BEConductor>>> ExecGetAll(BEArgs args)
        {
            return await this.conductorRepository.GetAll(args);
        }
        public async Task<OutResultData<BEConductor>> ExecInsertUpdate(BEConductor entity, int accion)
        {
            return await this.conductorRepository.InsertUpdate(entity, accion);
        }
        public async Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args)
        {
            return await this.conductorRepository.DeleteAllSelected(args);
        }
        public async Task<OutResultData<BEConductor>> ExecGestionUsuarios(BEConductor entity, int accion)
        {
            return await this.conductorRepository.GestionUsuarios(entity, accion);
        }
    }
}
