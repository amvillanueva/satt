﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ControlBus.Maestros;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Maestros.Web.Implementacion
{
    public class CorreoUseCase : ICorreoUseCase
    {
        private readonly ICorreoRepository correoRepository;
        public CorreoUseCase(ICorreoRepository correoRepository)
        {
            this.correoRepository = correoRepository;
        }

        public async Task<OutResultData<List<BECorreo>>> ExecGetAll(BEArgs args)
        {
            return await this.correoRepository.GetAll(args);
        }
        public async Task<OutResultData<BECorreo>> ExecInsertUpdate(BECorreo entity, int accion)
        {
            return await this.correoRepository.InsertUpdate(entity, accion);
        }
        public async Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args)
        {
            return await this.correoRepository.DeleteAllSelected(args);
        }
    }
}
