﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ControlBus.Maestros.Web;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Maestros.Web.Implementacion
{
    public class DenominacionCecoUseCase : IDenominacionCecoUseCase
    {
        private readonly IDenominacionCecoRepository denominacionCecoRepository;

        public DenominacionCecoUseCase(IDenominacionCecoRepository denominacionCecoRepository)
        {
            this.denominacionCecoRepository = denominacionCecoRepository;
        }

        public async Task<OutResultData<List<BEDenominacionCeco>>> ExecGetAll(BEArgs args)
        {
            return await this.denominacionCecoRepository.GetAll(args);
        }

        public async Task<OutResultData<BEDenominacionCeco>> ExecInsertUpdate(BEDenominacionCeco entity, int accion)
        {
            return await this.denominacionCecoRepository.InsertUpdate(entity, accion);
        }

        public async Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args)
        {
            return await this.denominacionCecoRepository.DeleteAllSelected(args);
        }
    }
}
