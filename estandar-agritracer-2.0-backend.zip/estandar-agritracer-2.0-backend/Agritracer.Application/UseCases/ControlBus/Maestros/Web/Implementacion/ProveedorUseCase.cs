﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ControlBus.Maestros;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using Agritracer.Domain.Seguridad;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Maestros.Web.Implementacion
{
    public class ProveedorUseCase : IProveedorUseCase
    {
        private readonly IProveedorRepository proveedorRepository;

        public ProveedorUseCase(IProveedorRepository proveedorRepository)
        {
            this.proveedorRepository = proveedorRepository;
        }

        public async Task<OutResultData<BEProveedor>> ExecGetById(int id)
        {
            return await this.proveedorRepository.GetById(id);
        }

        public async Task<OutResultData<List<BEProveedor>>> ExecGetAll(BEArgs args)
        {
            return await this.proveedorRepository.GetAll(args);
        }

        public async Task<OutResultData<BEProveedor>> ExecInsertUpdate(BEProveedor entity, int accion)
        {
            return await this.proveedorRepository.InsertUpdate(entity, accion);
        }

        public async Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args)
        {
            return await this.proveedorRepository.DeleteAllSelected(args);
        }

        public async Task<OutResultData<BEUsuarioWeb>> ExecGestionUsuarios(BEUsuarioWeb entity, int accion)
        {
            return await this.proveedorRepository.GestionUsuarios(entity, accion);
        }

        public async Task<OutResultData<BEProveedorTarifa>> ExecGestionTarifas(BEProveedor entity, int accion)
        {
            return await this.proveedorRepository.GestionTarifas(entity, accion);
        }
    }
}
