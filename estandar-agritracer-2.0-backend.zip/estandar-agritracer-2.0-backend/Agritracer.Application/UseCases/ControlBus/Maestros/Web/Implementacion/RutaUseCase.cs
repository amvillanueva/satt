﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ControlBus.Maestros;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Maestros.Web.Implementacion
{
    public class RutaUseCase : IRutaUseCase
    {
        private readonly IRutaRepository rutaRepository;
        public RutaUseCase(IRutaRepository rutaRepository)
        {
            this.rutaRepository = rutaRepository;
        }
        public async Task<OutResultData<BERuta>> ExecGetById(int id)
        {
            return await this.rutaRepository.GetById(id);
        }
        public async Task<OutResultData<List<BERuta>>> ExecGetAll(BEArgs args)
        {
            return await this.rutaRepository.GetAll(args);
        }
        public async Task<OutResultData<BERuta>> ExecInsertUpdate(BERuta entity, int accion)
        {
            return await this.rutaRepository.InsertUpdate(entity, accion);
        }
        public async Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args)
        {
            return await this.rutaRepository.DeleteAllSelected(args);
        }
    }
}
