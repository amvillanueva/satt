﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ControlBus.Maestros;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Maestros.Web.Implementacion
{
    public class TarifaUseCase : ITarifaUseCase
    {
        private readonly ITarifaRepository rutaRepository;

        public TarifaUseCase(ITarifaRepository rutaRepository)
        {
            this.rutaRepository = rutaRepository;
        }

        public async Task<OutResultData<BETarifa>> ExecGetById(int id)
        {
            return await this.rutaRepository.GetById(id);
        }

        public async Task<OutResultData<List<BETarifa>>> ExecGetAll(BEArgs args)
        {
            return await this.rutaRepository.GetAll(args);
        }

        public async Task<OutResultData<BETarifa>> ExecInsertUpdate(BETarifa entity, int accion)
        {
            return await this.rutaRepository.InsertUpdate(entity, accion);
        }

        public async Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args)
        {
            return await this.rutaRepository.DeleteAllSelected(args);
        }
    }
}
