﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ControlBus.Maestros;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Maestros.Web.Implementacion
{
    public class UbicacionUseCase : IUbicacionUseCase
    {
        private readonly IUbicacionRepository ubicacionRepository;
        public UbicacionUseCase(IUbicacionRepository ubicacionRepository)
        {
            this.ubicacionRepository = ubicacionRepository;
        }
        public async Task<OutResultData<BEUbicacion>> ExecGetById(int id)
        {
            return await this.ubicacionRepository.GetById(id);
        }
        public async Task<OutResultData<List<BEUbicacion>>> ExecGetAll(BEArgs args)
        {
            return await this.ubicacionRepository.GetAll(args);
        }
        public async Task<OutResultData<BEUbicacion>> ExecInsertUpdate(BEUbicacion entity, int accion)
        {
            return await this.ubicacionRepository.InsertUpdate(entity, accion);
        }
        public async Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args)
        {
            return await this.ubicacionRepository.DeleteAllSelected(args);
        }
    }
}
