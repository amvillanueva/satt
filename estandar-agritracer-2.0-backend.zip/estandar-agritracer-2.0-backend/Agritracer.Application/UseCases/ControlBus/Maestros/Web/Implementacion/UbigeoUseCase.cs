﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ControlBus.Maestros.Web;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Maestros.Web.Implementacion
{
    public class UbigeoUseCase : IUbigeoUseCase
    {
        private readonly IUbigeoRepository ubigeoRepository;

        public UbigeoUseCase(IUbigeoRepository ubigeoRepository)
        {
            this.ubigeoRepository = ubigeoRepository;
        }

        public async Task<OutResultData<List<BEUbigeo>>> ExecGetAll(BEArgs args)
        {
            return await this.ubigeoRepository.GetAll(args);
        }

        public async Task<OutResultData<BEUbigeo>> ExecInsertUpdate(BEUbigeo entity, int accion)
        {
            return await this.ubigeoRepository.InsertUpdate(entity, accion);
        }

        public async Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args)
        {
            return await this.ubigeoRepository.DeleteAllSelected(args);
        }
    }
}
