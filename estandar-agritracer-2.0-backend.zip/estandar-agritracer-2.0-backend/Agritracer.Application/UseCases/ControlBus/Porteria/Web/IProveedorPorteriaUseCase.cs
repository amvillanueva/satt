﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Porteria
{
    public interface IProveedorPorteriaUseCase
    {
        Task<OutResultData<BEProveedorPorteria>> ExecGetById(int id);
        Task<OutResultData<List<BEProveedorPorteria>>> ExecGetAll(BEArgs args);
        Task<OutResultData<BEProveedorPorteria>> ExecInsertUpdate(BEProveedorPorteria entity, int accion);
        Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args);
        Task<OutResultData<bool>> ExecSincronizarProveedores(BEArgs args);
    }
}
