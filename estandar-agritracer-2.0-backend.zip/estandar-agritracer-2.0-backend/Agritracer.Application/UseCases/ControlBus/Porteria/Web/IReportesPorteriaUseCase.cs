﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Porteria
{
    public interface IReportesPorteriaUseCase
    {
        Task<OutResultData<DataSet>> ExecRptPorteria(BEArgs args);
        Task<OutResultData<BEAccesoPorteria>> ExecGetDetails(int id, int accion);
        Task<OutResultData<List<BEAccesoPorteria>>> ExecGetManifiestos(string json);
    }
}
