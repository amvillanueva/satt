﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Porteria
{
    public interface IVehiculoPorteriaUseCase
    {
        Task<OutResultData<BEVehiculoPorteria>> ExecGetById(int id);
        Task<OutResultData<List<BEVehiculoPorteria>>> ExecGetAll(BEArgs args);
        Task<OutResultData<BEVehiculoPorteria>> ExecInsertUpdate(BEVehiculoPorteria entity, int accion);
        Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args);
        Task<OutResultData<bool>> ExecSincronizarVehiculos(BEArgs args);
    }
}
