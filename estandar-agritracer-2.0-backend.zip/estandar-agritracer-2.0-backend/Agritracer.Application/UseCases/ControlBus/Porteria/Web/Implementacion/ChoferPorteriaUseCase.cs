﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ControlBus.Porteria;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Porteria.Web.Implementacion
{
    public class ChoferPorteriaUseCase : IChoferPorteriaUseCase
    {
        private readonly IChoferPorteriaRepository choferPorteriaRepository;

        public ChoferPorteriaUseCase(IChoferPorteriaRepository choferPorteriaRepository)
        {
            this.choferPorteriaRepository = choferPorteriaRepository;
        }

        public async Task<OutResultData<BEChoferPorteria>> ExecGetById(int id)
        {
            return await this.choferPorteriaRepository.GetById(id);
        }

        public async Task<OutResultData<List<BEChoferPorteria>>> ExecGetAll(BEArgs args)
        {
            return await this.choferPorteriaRepository.GetAll(args);
        }

        public async Task<OutResultData<BEChoferPorteria>> ExecInsertUpdate(BEChoferPorteria entity, int accion)
        {
            return await this.choferPorteriaRepository.InsertUpdate(entity, accion);
        }

        public async Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args)
        {
            return await this.choferPorteriaRepository.DeleteAllSelected(args);
        }

        public async Task<OutResultData<bool>> ExecSincronizarChoferes(BEArgs args)
        {
            return await this.choferPorteriaRepository.SincronizarChoferes(args);
        }
    }
}
