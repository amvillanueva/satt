﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ControlBus.Porteria;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Porteria.Web.Implementacion
{
    public class ProveedorPorteriaUseCase : IProveedorPorteriaUseCase
    {
        private readonly IProveedorPorteriaRepository proveedorPorteriaRepository;
        public ProveedorPorteriaUseCase(IProveedorPorteriaRepository proveedorPorteriaRepository)
        {
            this.proveedorPorteriaRepository = proveedorPorteriaRepository;
        }
        public async Task<OutResultData<BEProveedorPorteria>> ExecGetById(int id)
        {
            return await this.proveedorPorteriaRepository.GetById(id);
        }
        public async Task<OutResultData<List<BEProveedorPorteria>>> ExecGetAll(BEArgs args)
        {
            return await this.proveedorPorteriaRepository.GetAll(args);
        }
        public async Task<OutResultData<BEProveedorPorteria>> ExecInsertUpdate(BEProveedorPorteria entity, int accion)
        {
            return await this.proveedorPorteriaRepository.InsertUpdate(entity, accion);
        }
        public async Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args)
        {
            return await this.proveedorPorteriaRepository.DeleteAllSelected(args);
        }
        public async Task<OutResultData<bool>> ExecSincronizarProveedores(BEArgs args)
        {
            return await this.proveedorPorteriaRepository.SincronizarProveedores(args);
        }
    }
}
