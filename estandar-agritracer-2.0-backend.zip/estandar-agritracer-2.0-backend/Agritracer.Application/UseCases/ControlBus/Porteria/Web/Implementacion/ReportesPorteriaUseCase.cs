﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ControlBus.Porteria;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Porteria.Implementacion
{
    public class ReportesPorteriaUseCase : IReportesPorteriaUseCase
    {
        private readonly IReportesPorteriaRepository reportesPorteriaRepository;
        public ReportesPorteriaUseCase(IReportesPorteriaRepository reportesPorteriaRepository)
        {
            this.reportesPorteriaRepository = reportesPorteriaRepository;
        }
        public async Task<OutResultData<DataSet>> ExecRptPorteria(BEArgs args)
        {
            return await this.reportesPorteriaRepository.RptPorteria(args);
        }
        public async Task<OutResultData<BEAccesoPorteria>> ExecGetDetails(int id, int accion)
        {
            return await this.reportesPorteriaRepository.GetDetails(id, accion);
        }
        public async Task<OutResultData<List<BEAccesoPorteria>>> ExecGetManifiestos(string json)
        {
            return await this.reportesPorteriaRepository.GetManifiestos(json);
        }
    }
}
