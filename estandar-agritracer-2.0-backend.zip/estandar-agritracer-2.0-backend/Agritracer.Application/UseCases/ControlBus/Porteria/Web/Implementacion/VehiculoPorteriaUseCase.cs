﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ControlBus.Porteria;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Porteria.Web.Implementacion
{
    public class VehiculoPorteriaUseCase : IVehiculoPorteriaUseCase
    {
        private readonly IVehiculoPorteriaRepository vehiculoPorteriaRepository;
        public VehiculoPorteriaUseCase(IVehiculoPorteriaRepository vehiculoPorteriaRepository)
        {
            this.vehiculoPorteriaRepository = vehiculoPorteriaRepository;
        }
        public async Task<OutResultData<BEVehiculoPorteria>> ExecGetById(int id)
        {
            return await this.vehiculoPorteriaRepository.GetById(id);
        }
        public async Task<OutResultData<List<BEVehiculoPorteria>>> ExecGetAll(BEArgs args)
        {
            return await this.vehiculoPorteriaRepository.GetAll(args);
        }
        public async Task<OutResultData<BEVehiculoPorteria>> ExecInsertUpdate(BEVehiculoPorteria entity, int accion)
        {
            return await this.vehiculoPorteriaRepository.InsertUpdate(entity, accion);
        }
        public async Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args)
        {
            return await this.vehiculoPorteriaRepository.DeleteAllSelected(args);
        }
        public async Task<OutResultData<bool>> ExecSincronizarVehiculos(BEArgs args)
        {
            return await this.vehiculoPorteriaRepository.SincronizarVehiculos(args);
        }
    }
}
