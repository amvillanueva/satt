﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ControlBus;
using Agritracer.Domain.ControlBus.Movil;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Procesos.Movil
{
    public interface IControlAccesoUseCase
    {
        Task<OutResultData<BEVehiculo>> ExecuteDatosVehiculo(string codigoQR);
        Task<OutResultData<BEChoferPorteria>> ExecuteDatosChofer(string codigoQR, int IdEmpresa);
        Task<OutResultData<string>> ExecuteRegistrarControlAcceso(List<BEControlAcceso> datos);
    }
}
