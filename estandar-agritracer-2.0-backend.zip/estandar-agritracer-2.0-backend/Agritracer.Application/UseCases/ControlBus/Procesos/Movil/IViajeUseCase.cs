﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ControlBus.Movil;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Procesos.Movil
{
    public interface IViajeUseCase
    {
        Task<OutResultData<string>> ExecuteIniciarViaje(BEViajeRest viajeRest);
        Task<OutResultData<string>> ExecuteFinalizarViajes(List<BEViajeRest> viajeRestList);
        Task<OutResultData<string>> ExecuteGenerarQRViaje(BEViajeRest viajeRest);
        Task<OutResultData<BEDataMaestra>> ExecuteLecturarQRViaje(string CodViajeQR, int IdUsuario, string login, string host);
        Task<OutResultData<string>> ExecuteValidarViajeQR(BEViajeQR viajeQr);
        Task<OutResultData<string>> ExecuteCambiarBus(BEViajeRest viajeRest);
    }
}
