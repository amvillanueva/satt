﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ControlBus.Procesos.Movil;
using Agritracer.Domain.ControlBus;
using Agritracer.Domain.ControlBus.Movil;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Procesos.Movil.Implementacion
{
    public class ControlAccesoUseCase : IControlAccesoUseCase
    {
        private readonly IControlAccesoRepository _controlAccesoRepository;

        public ControlAccesoUseCase(IControlAccesoRepository controlAccesoRepository)
        {
            _controlAccesoRepository = controlAccesoRepository;
        }

        public async Task<OutResultData<BEVehiculo>> ExecuteDatosVehiculo(string codigoQR)
        {
            return await _controlAccesoRepository.DatosVehiculo(codigoQR);
        }

        public async Task<OutResultData<BEChoferPorteria>> ExecuteDatosChofer(string codigoQR, int IdEmpresa)
        {
            return await _controlAccesoRepository.DatosChofer(codigoQR, IdEmpresa);
        }


        public async Task<OutResultData<string>> ExecuteRegistrarControlAcceso(List<BEControlAcceso> datos)
        {
            return await this._controlAccesoRepository.RegistrarControlAcceso(datos);
        }
    }
}
