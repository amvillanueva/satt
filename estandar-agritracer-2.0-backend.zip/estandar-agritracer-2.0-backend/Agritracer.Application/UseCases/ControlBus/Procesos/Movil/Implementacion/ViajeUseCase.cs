﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ControlBus.Procesos.Movil;
using Agritracer.Domain.ControlBus.Movil;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Procesos.Movil.Implementacion
{
    public class ViajeUseCase : IViajeUseCase
    {
        private readonly IViajeRepository _viajeRepository;

        public ViajeUseCase(IViajeRepository viajeRepository)
        {
            _viajeRepository = viajeRepository;
        }

        public async Task<OutResultData<string>> ExecuteIniciarViaje(BEViajeRest viajeRest)
        {
            return await _viajeRepository.IniciarViaje(viajeRest);
        }

        public async Task<OutResultData<string>> ExecuteFinalizarViajes(List<BEViajeRest> viajeRestList)
        {
            return await _viajeRepository.FinalizarViajes(viajeRestList);
        }

        public async Task<OutResultData<string>> ExecuteGenerarQRViaje(BEViajeRest viajeRest)
        {
            return await _viajeRepository.GenerarQRViaje(viajeRest);
        }

        public async Task<OutResultData<BEDataMaestra>> ExecuteLecturarQRViaje(string CodViajeQR, int IdUsuario, string login, string host)
        {
            return await _viajeRepository.LecturarQRViaje(CodViajeQR, IdUsuario, login, host);
        }

        public async Task<OutResultData<string>> ExecuteValidarViajeQR(BEViajeQR viajeQr)
        {
            return await _viajeRepository.ValidarViajeQR(viajeQr);
        }

        public async Task<OutResultData<string>> ExecuteCambiarBus(BEViajeRest viajeRest)
        {
            return await _viajeRepository.CambiarBus(viajeRest);
        }
    }
}
