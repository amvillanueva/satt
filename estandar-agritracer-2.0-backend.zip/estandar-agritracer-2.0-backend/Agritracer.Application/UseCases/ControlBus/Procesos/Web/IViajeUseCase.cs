﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Procesos.Web
{
    public interface IViajeUseCase
    {
        Task<OutResultData<List<BEViaje>>> ExecGetAll(BEArgs args);
        Task<OutResultData<BEViaje>> ExecGetDetails(int id, int tipoViajeID);
        Task<OutResultData<BEViaje>> ExecInsertUpdate(BEViaje entity, int accion);
        Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args);
        Task<OutResultData<List<BEViajeDetalle>>> ExecGetDatosPasajero(BEArgs args);
        Task<OutResultData<DataSet>> ExecGenerarLiquidacion(BEArgs args);
        Task<OutResultData<DataSet>> ExecObtenerDashboard(BEArgs args);
        Task<OutResultData<DataSet>> ExecValidarEnviarLiquidacion(BEArgs args);
        Task<OutResultData<bool>> ExecGuardarFacturaLiquidacion(BEArgs args);
    }
}
