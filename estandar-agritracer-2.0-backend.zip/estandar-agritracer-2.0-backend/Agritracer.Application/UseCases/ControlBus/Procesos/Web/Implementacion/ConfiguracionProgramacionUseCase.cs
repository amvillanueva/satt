﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ControlBus.Procesos.Web;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Procesos.Web.Implementacion
{
    public class ConfiguracionProgramacionUseCase : IConfiguracionProgramacionUseCase
    {
        private readonly IConfiguracionProgramacionRepository programacionRepository;
        public ConfiguracionProgramacionUseCase(IConfiguracionProgramacionRepository programacionRepository)
        {
            this.programacionRepository = programacionRepository;
        }
        public async Task<OutResultData<BEProgramacion>> ExecGetById(int id)
        {
            return await this.programacionRepository.GetById(id);
        }
        public async Task<OutResultData<List<BEProgramacion>>> ExecGetAll(BEArgs args)
        {
            return await this.programacionRepository.GetAll(args);
        }
        public async Task<OutResultData<BEProgramacion>> ExecInsertUpdate(BEProgramacion entity, int accion)
        {
            return await this.programacionRepository.InsertUpdate(entity, accion);
        }
        public async Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args)
        {
            return await this.programacionRepository.DeleteAllSelected(args);
        }
    }
}
