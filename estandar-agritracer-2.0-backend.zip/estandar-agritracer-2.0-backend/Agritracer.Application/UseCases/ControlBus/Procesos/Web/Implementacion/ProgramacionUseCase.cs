﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ControlBus.Procesos.Web;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Procesos.Web.Implementacion
{
    public class ProgramacionUseCase : IProgramacionUseCase
    {
        private readonly IProgramacionRepository programacionRepository;

        public ProgramacionUseCase(IProgramacionRepository programacionRepository)
        {
            this.programacionRepository = programacionRepository;
        }

        public async Task<OutResultData<List<BEProgramacion>>> ExecGetAll(BEArgs args)
        {
            return await this.programacionRepository.GetAll(args);
        }

        public async Task<OutResultData<BEProgramacion>> ExecInsertUpdate(BEProgramacion entity, int accion)
        {
            return await this.programacionRepository.InsertUpdate(entity, accion);
        }

        public async Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args)
        {
            return await this.programacionRepository.DeleteAllSelected(args);
        }

        public async Task<OutResultData<BEProgramacion>> ExecAsignaConductorBus(BEProgramacion entity)
        {
            return await this.programacionRepository.AsignaConductorBus(entity);
        }

        public async Task<OutResultData<bool>> ExecGenerarProgramacionAutomatica(BEArgs args)
        {
            return await this.programacionRepository.GenerarProgramacionAutomatica(args);
        }

        public async Task<OutResultData<bool>> ExecFinalizarProgramaciones(BEArgs args)
        {
            return await this.programacionRepository.FinalizarProgramaciones(args);
        }
    }
}
