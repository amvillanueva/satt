﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ControlBus.Procesos.Web;
using Agritracer.Domain.Common;
using Agritracer.Domain.ControlBus;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Procesos.Web.Implementacion
{
    public class ViajeUseCase : IViajeUseCase
    {
        private readonly IViajeRepository viajeRepository;

        public ViajeUseCase(IViajeRepository viajeRepository)
        {
            this.viajeRepository = viajeRepository;
        }

        public async Task<OutResultData<List<BEViaje>>> ExecGetAll(BEArgs args)
        {
            return await this.viajeRepository.GetAll(args);
        }

        public async Task<OutResultData<BEViaje>> ExecGetDetails(int id, int tipoViajeID)
        {
            return await this.viajeRepository.GetDetails(id, tipoViajeID);
        }

        public async Task<OutResultData<BEViaje>> ExecInsertUpdate(BEViaje entity, int accion)
        {
            return await this.viajeRepository.InsertUpdate(entity, accion);
        }

        public async Task<OutResultData<bool>> ExecDeleteAllSelected(BEArgs args)
        {
            return await this.viajeRepository.DeleteAllSelected(args);
        }

        public async Task<OutResultData<List<BEViajeDetalle>>> ExecGetDatosPasajero(BEArgs args)
        {
            return await this.viajeRepository.GetDatosPasajero(args);
        }

        public async Task<OutResultData<DataSet>> ExecGenerarLiquidacion(BEArgs args)
        {
            return await this.viajeRepository.GenerarLiquidacion(args);
        }

        public async Task<OutResultData<DataSet>> ExecObtenerDashboard(BEArgs args)
        {
            return await this.viajeRepository.ObtenerDashboard(args);
        }

        public async Task<OutResultData<DataSet>> ExecValidarEnviarLiquidacion(BEArgs args)
        {
            return await this.viajeRepository.ValidarEnviarLiquidacion(args);
        }

        public async Task<OutResultData<bool>> ExecGuardarFacturaLiquidacion(BEArgs args)
        {
            return await this.viajeRepository.GuardarFacturaLiquidacion(args);
        }
    }
}
