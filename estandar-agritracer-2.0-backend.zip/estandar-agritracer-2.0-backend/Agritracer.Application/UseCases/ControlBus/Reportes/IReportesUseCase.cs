﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Reportes
{
    public interface IReportesUseCase
    {
        Task<OutResultData<DataSet>> ExecControlBuses(BEArgs args);
        Task<OutResultData<DataSet>> ExecLiquidacionServicios(BEArgs args);
        Task<OutResultData<DataSet>> ExecViajesConductor(BEArgs args);
        Task<OutResultData<DataSet>> ExecViajesGrafico(BEArgs args);
        Task<OutResultData<DataSet>> ExecPasajerosRestricciones(BEArgs args);
        Task<OutResultData<DataSet>> ExecRatioOcupacion(BEArgs args);
        Task<OutResultData<DataSet>> ExecBusesProveedor(BEArgs args);
        Task<OutResultData<DataSet>> ExecCumplimientoServicios(BEArgs args);
        Task<OutResultData<DataSet>> ExecCostoPasajero(BEArgs args);
    }
}
