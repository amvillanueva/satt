﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ControlBus.Reportes;
using Agritracer.Domain.Common;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ControlBus.Reportes.Implementacion
{
    public class ReportesUseCase : IReportesUseCase
    {
        private readonly IReportesRepository reportesRepository;
        public ReportesUseCase(IReportesRepository reportesRepository)
        {
            this.reportesRepository = reportesRepository;
        }

        public async Task<OutResultData<DataSet>> ExecControlBuses(BEArgs args)
        {
            return await this.reportesRepository.ControlBuses(args);
        }

        public async Task<OutResultData<DataSet>> ExecLiquidacionServicios(BEArgs args)
        {
            return await this.reportesRepository.LiquidacionServicios(args);
        }

        public async Task<OutResultData<DataSet>> ExecViajesConductor(BEArgs args)
        {
            return await this.reportesRepository.ViajesConductor(args);
        }

        public async Task<OutResultData<DataSet>> ExecViajesGrafico(BEArgs args)
        {
            return await this.reportesRepository.ViajesGrafico(args);
        }

        public async Task<OutResultData<DataSet>> ExecPasajerosRestricciones(BEArgs args)
        {
            return await this.reportesRepository.PasajerosRestricciones(args);
        }

        public async Task<OutResultData<DataSet>> ExecRatioOcupacion(BEArgs args)
        {
            return await this.reportesRepository.RatioOcupacion(args);
        }

        public async Task<OutResultData<DataSet>> ExecBusesProveedor(BEArgs args)
        {
            return await this.reportesRepository.BusesProveedor(args);
        }

        public async Task<OutResultData<DataSet>> ExecCumplimientoServicios(BEArgs args)
        {
            return await this.reportesRepository.CumplimientoServicios(args);
        }

        public async Task<OutResultData<DataSet>> ExecCostoPasajero(BEArgs args)
        {
            return await this.reportesRepository.CostoPasajero(args);
        }
    }
}
