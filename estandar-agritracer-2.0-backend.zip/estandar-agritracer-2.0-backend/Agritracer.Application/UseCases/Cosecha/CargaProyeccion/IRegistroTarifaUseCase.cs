﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.CargaProyeccion
{
    public interface IRegistroTarifaUseCase
    {
        Task<OutResultData<DataTable>> RegistrotarifaExec(BEArgs args);
        //Task<OutResultData<string>> EliminarAsignacionSupervisorExec(BEArgs args);
    }
}

