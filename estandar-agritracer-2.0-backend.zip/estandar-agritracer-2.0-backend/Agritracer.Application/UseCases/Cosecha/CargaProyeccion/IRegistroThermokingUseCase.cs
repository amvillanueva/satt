﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.CargaProyeccion
{
    public interface IRegistroThermokingUseCase
    {
        Task<OutResultData<DataTable>> RegistroThermokingExec(BEArgs args);
    }
}

