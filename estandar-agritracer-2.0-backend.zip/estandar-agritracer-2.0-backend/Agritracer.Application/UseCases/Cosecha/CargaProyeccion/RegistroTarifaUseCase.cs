﻿using System.Threading.Tasks;
using Agritracer.Application.Repositories.Cosecha.CargaProyeccion;
using Agritracer.Application.OutputObjets;
using System.Data;
using Agritracer.Domain.Common;

namespace Agritracer.Application.UseCases.Cosecha.CargaProyeccion
{
    public class RegistroTarifaUseCase : IRegistroTarifaUseCase
    {
        private readonly IRegistroTarifaRepository _registroTarifaRepository;

        public RegistroTarifaUseCase(IRegistroTarifaRepository registroTarifaRepository)
        {
            _registroTarifaRepository = registroTarifaRepository;
        }

        public async Task<OutResultData<DataTable>> RegistrotarifaExec(BEArgs args)
        {
            return await _registroTarifaRepository.Registrotarifa(args.usuarioID, args.host, args.tipoRegistro, args.fechapersonal, args.tarifanormal, args.tarifa1, args.tarifa2, args.fechaviaje, args.tarifakiacam, args.tarifacamioneta, args.tarifathermoking);
        }
    }
}
