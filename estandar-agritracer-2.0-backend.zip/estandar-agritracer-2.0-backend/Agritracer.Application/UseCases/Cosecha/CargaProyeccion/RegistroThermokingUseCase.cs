﻿using System.Threading.Tasks;
using Agritracer.Application.Repositories.Cosecha.CargaProyeccion;
using Agritracer.Application.OutputObjets;
using System.Data;
using Agritracer.Domain.Common;

namespace Agritracer.Application.UseCases.Cosecha.CargaProyeccion
{
    public class RegistroThermokingUseCase : IRegistroThermokingUseCase
    {
        private readonly IRegistroThermokingRepository _registroThermokingRepository;

        public RegistroThermokingUseCase(IRegistroThermokingRepository registroThermokingRepository)
        {
            _registroThermokingRepository = registroThermokingRepository;
        }

        public async Task<OutResultData<DataTable>> RegistroThermokingExec(BEArgs args)
        {
            return await _registroThermokingRepository.RegistroThermoking(args.usuarioID, args.host, args.fechathermoking ,args.nrothermoking, args.nroviajes);
        }
    }
}

