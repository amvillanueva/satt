﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Cosecha.KpiCosecha;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Data;

namespace Agritracer.Application.UseCases.Cosecha.KpiCosecha
{
    public interface IKpiCosechaUseCase
    {
        Task<OutResultData<List<BERegistroCalidad>>> ExecuteListarRegistrosCalidad(string fecha, string grupo, int zona);
    }
}
