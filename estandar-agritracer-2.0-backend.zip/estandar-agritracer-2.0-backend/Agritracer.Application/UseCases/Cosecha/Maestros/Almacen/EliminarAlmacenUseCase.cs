﻿using Agritracer.Application.OutputObjets.Cosecha.Maestros;
using Agritracer.Application.Repositories.Cosecha.Maestros;
using Agritracer.Domain.Cosecha;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public class EliminarAlmacenUseCase : IEliminarAlmacenUseCase
    {
        private readonly IAlmacenReadWriteRepository _almacenReadWriteRepository;

        public EliminarAlmacenUseCase(IAlmacenReadWriteRepository almacenReadWriteRepository)
        {
            _almacenReadWriteRepository = almacenReadWriteRepository;
        }

        public async Task<OutAlmacenUseCase> Execute(List<int> almacenIDs)
        {
            return await _almacenReadWriteRepository.Delete(almacenIDs);
        }
    }
}
