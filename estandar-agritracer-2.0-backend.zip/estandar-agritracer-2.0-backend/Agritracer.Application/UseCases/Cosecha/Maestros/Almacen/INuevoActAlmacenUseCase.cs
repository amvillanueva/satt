﻿using Agritracer.Domain.Cosecha;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public interface INuevoActAlmacenUseCase
    {
        Task<BEAlmacen> Execute(BEAlmacen almacen);
    }
}
