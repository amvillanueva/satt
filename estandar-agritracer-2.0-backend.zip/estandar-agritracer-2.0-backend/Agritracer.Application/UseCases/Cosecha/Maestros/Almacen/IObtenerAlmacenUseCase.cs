﻿using Agritracer.Domain.Cosecha;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public interface IObtenerAlmacenUseCase
    {
        Task<IEnumerable<BEAlmacen>> Execute(int almacenID,int estado,int empresa);
    }
}
