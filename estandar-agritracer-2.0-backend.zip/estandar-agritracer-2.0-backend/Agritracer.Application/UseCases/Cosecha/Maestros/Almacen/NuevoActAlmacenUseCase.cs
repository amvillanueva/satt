﻿using Agritracer.Application.Repositories.Cosecha.Maestros;
using Agritracer.Domain.Cosecha;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public class NuevoActAlmacenUseCase : INuevoActAlmacenUseCase
    {
        private readonly IAlmacenReadWriteRepository _almacenReadWriteRepository;

        public NuevoActAlmacenUseCase(IAlmacenReadWriteRepository almacenReadWriteRepository)
        {
            _almacenReadWriteRepository = almacenReadWriteRepository;
        }

        public async Task<BEAlmacen> Execute(BEAlmacen almacen)
        {
            return await _almacenReadWriteRepository.AddUpdate(almacen);
        }
    }
}
