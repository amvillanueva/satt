﻿using Agritracer.Application.Repositories.Cosecha.Maestros;
using Agritracer.Domain.Cosecha;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public class ObtenerAlmacenUseCase : IObtenerAlmacenUseCase
    {
        private readonly IAlmacenReadWriteRepository _almacenReadWriteRepository;

        public ObtenerAlmacenUseCase(IAlmacenReadWriteRepository almacenReadWriteRepository)
        {
            _almacenReadWriteRepository = almacenReadWriteRepository;
        }

        public async Task<IEnumerable<BEAlmacen>> Execute(int almacenID,int estado,int empresa)
        {
            if (almacenID != -1)
            {
                List<BEAlmacen> lst = new List<BEAlmacen>();
                BEAlmacen almacenRpta = await _almacenReadWriteRepository.GetByID(almacenID);

                if (almacenRpta != null)
                {
                    if(almacenRpta.almacenID!=-1)
                        lst.Add(almacenRpta);
                }
                
                return lst;
            }
            else
            {
                return await _almacenReadWriteRepository.GetAll(estado,empresa);
            }
        }
    }
}
