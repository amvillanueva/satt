﻿using Agritracer.Application.OutputObjets.Cosecha.Maestros;
using Agritracer.Application.Repositories.Cosecha.Maestros;
using Agritracer.Domain.Cosecha;
using Agritracer.Domain.Cosecha.Maestros;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public class CampaniaUseCase:ICampaniaUseCase
    {
        private readonly ICampaniaReadWriteRepository _campaniaReadWriteRepository;

        public CampaniaUseCase(ICampaniaReadWriteRepository campaniaReadWriteRepository)
        {
            _campaniaReadWriteRepository = campaniaReadWriteRepository;
        }

        public async Task<OutCampaniaUseCase> AnularExec(List<BECampania> campanias)
        {
            return await _campaniaReadWriteRepository.Delete(campanias);
        }
        
        public async Task<BECampania> NuevoActualizarExec(BECampania campania)
        {
            return await _campaniaReadWriteRepository.AddUpdate(campania);
        }

        public async Task<IEnumerable<BECampania>> ObtenerExec(BECampania campania)
        {
            if (campania.campaniaID != -1)
            {
                List<BECampania> lst = new List<BECampania>();
                BECampania campaniaRpta = await _campaniaReadWriteRepository.GetByID(campania);

                if (campaniaRpta != null)
                {
                    if (campaniaRpta.campaniaID != -1)
                        lst.Add(campaniaRpta);
                }

                return lst;
            }
            else
            {
                return await _campaniaReadWriteRepository.GetAll(campania);
            }
        }

        public async Task<IEnumerable<BECampania>> ObtenerHistExec(BECampania campania)
        {
            return await _campaniaReadWriteRepository.GetAllHist(campania);
        }
    }
}
