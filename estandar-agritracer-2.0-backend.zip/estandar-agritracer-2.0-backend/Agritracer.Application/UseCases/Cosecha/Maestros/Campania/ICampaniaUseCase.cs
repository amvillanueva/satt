﻿using Agritracer.Application.OutputObjets.Cosecha.Maestros;
using Agritracer.Domain.Cosecha;
using Agritracer.Domain.Cosecha.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public interface ICampaniaUseCase
    {
        Task<IEnumerable<BECampania>> ObtenerExec(BECampania campania);
        Task<IEnumerable<BECampania>> ObtenerHistExec(BECampania campania);
        Task<BECampania> NuevoActualizarExec(BECampania campania);
        Task<OutCampaniaUseCase> AnularExec(List<BECampania> campanias);
    }
}
