﻿using Agritracer.Application.OutputObjets.Cosecha.Maestros;
using Agritracer.Application.Repositories.Cosecha.Maestros;
using Agritracer.Domain.Cosecha;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public class EliminarFundoUseCase : IEliminarFundoUseCase
    {
        private readonly IFundoReadWriteRepository _fundoReadWriteRepository;

        public EliminarFundoUseCase(IFundoReadWriteRepository fundoReadWriteRepository)
        {
            _fundoReadWriteRepository = fundoReadWriteRepository;
        }

        public async Task<OutFundoUseCase> Execute(List<int> fundoIDs)
        {
            return await _fundoReadWriteRepository.Delete(fundoIDs);
        }
    }
}
