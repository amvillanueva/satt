﻿using Agritracer.Application.OutputObjets.Cosecha.Maestros;
using Agritracer.Domain.Cosecha;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public interface IEliminarFundoUseCase
    {
        Task<OutFundoUseCase> Execute(List<int> fundoIDs);
    }
}
