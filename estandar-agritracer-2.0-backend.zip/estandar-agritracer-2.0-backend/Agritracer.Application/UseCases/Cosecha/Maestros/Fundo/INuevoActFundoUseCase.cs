﻿using Agritracer.Domain.Cosecha;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public interface INuevoActFundoUseCase
    {
        Task<BEFundo> Execute(BEFundo fundo);
    }
}
