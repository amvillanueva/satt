﻿using Agritracer.Application.Repositories.Cosecha.Maestros;
using Agritracer.Domain.Cosecha;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public class NuevoActFundoUseCase : INuevoActFundoUseCase
    {
        private readonly IFundoReadWriteRepository _fundoReadWriteRepository;

        public NuevoActFundoUseCase(IFundoReadWriteRepository fundoReadWriteRepository)
        {
            _fundoReadWriteRepository = fundoReadWriteRepository;
        }

        public async Task<BEFundo> Execute(BEFundo fundo)
        {
            return await _fundoReadWriteRepository.AddUpdate(fundo);
        }
    }
}
