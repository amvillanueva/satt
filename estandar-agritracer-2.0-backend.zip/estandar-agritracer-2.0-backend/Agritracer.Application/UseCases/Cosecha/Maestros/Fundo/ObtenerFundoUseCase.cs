﻿using Agritracer.Application.Repositories.Cosecha.Maestros;
using Agritracer.Domain.Cosecha;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public class ObtenerFundoUseCase : IObtenerFundoUseCase
    {
        private readonly IFundoReadWriteRepository _fundoReadWriteRepository;

        public ObtenerFundoUseCase(IFundoReadWriteRepository fundoReadWriteRepository)
        {
            _fundoReadWriteRepository = fundoReadWriteRepository;
        }

        public async Task<IEnumerable<BEFundo>> Execute(int fundoID,int empresa,int estado)
        {
            if (fundoID != -1)
            {
                List<BEFundo> lst = new List<BEFundo>();
                BEFundo fundoRpta = await _fundoReadWriteRepository.GetByID(fundoID);

                if (fundoRpta != null)
                {
                    if(fundoRpta.fundoID!=-1)
                        lst.Add(fundoRpta);
                }
                
                return lst;
            }
            else
            {
                return await _fundoReadWriteRepository.GetAll(empresa,estado);
            }
        }
    }
}
