﻿using Agritracer.Domain.Cosecha.Maestros;
using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public interface IBandejaCosechaUseCase
    {
        Task<OutResultData<BEBandejaCosecha>> ExecuteGetById(int id);
        Task<OutResultData<List<BEBandejaCosecha>>> ExecuteGetAll(BEArgs args);
        Task<OutResultData<BEBandejaCosecha>> ExecuteInsUpdDel(BEBandejaCosecha bandejaCosecha, int accion);
        Task<OutResultData<BEBandejaCosecha>> ExecuteDeleteAllSelected(BEArgs args);
    }
}
