﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Cosecha.Maestros;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros.CharlaDiaria
{
    public interface ICharlaDiariaUseCase
    {
        Task<OutResultData<BECharlaDiaria>> ExecuteGetById(int id);
        Task<OutResultData<List<BECharlaDiaria>>> ExecuteGetAll(BEArgs args);
        Task<OutResultData<BECharlaDiaria>> ExecuteInsUpdDel(BECharlaDiaria charla, int accion);
        Task<OutResultData<BECharlaDiaria>> ExecuteDeleteAllSelected(BEArgs args);
    }
}
