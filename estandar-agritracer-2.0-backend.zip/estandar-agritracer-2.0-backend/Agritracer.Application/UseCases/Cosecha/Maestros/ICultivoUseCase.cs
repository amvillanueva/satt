﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Cosecha.Maestros;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros.Cultivo
{
    public interface ICultivoUseCase
    {
        Task<OutResultData<BECultivo>> ExecuteGetById(int id);
        Task<OutResultData<List<BECultivo>>> ExecuteGetAll(BEArgs args);
        Task<OutResultData<BECultivo>> ExecuteInsUpdDel(BECultivo cultivo, int accion);
        Task<OutResultData<BECultivo>> ExecuteDeleteAllSelected(BEArgs args);
    }
}
