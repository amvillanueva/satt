﻿using Agritracer.Domain.Cosecha.Maestros;
using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;


namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public interface IProductoVariedadUseCase
    {
        Task<OutResultData<BEProductoVariedad>> ExecuteGetById(int id);
        Task<OutResultData<List<BEProductoVariedad>>> ExecuteGetAll(BEArgs args);
        Task<OutResultData<BEProductoVariedad>> ExecuteInsUpdDel(BEProductoVariedad productoVariedad, int accion);
        Task<OutResultData<BEProductoVariedad>> ExecuteDeleteAllSelected(BEArgs args);
    }
}
