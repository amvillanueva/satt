﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Cosecha;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public interface IVariedadUseCase
    {
        Task<OutResultData<BEVariedad>> ExecuteGetById(int id);
        Task<OutResultData<List<BEVariedad>>> ExecuteGetAll(BEArgs args);
        Task<OutResultData<BEVariedad>> ExecuteInsUpdDel(BEVariedad cultivo, int accion);
        Task<OutResultData<BEVariedad>> ExecuteDeleteAllSelected(BEArgs args);
    }
}
