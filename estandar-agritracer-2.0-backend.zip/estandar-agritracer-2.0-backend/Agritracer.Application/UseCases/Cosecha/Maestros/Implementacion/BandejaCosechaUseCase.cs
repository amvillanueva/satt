﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.Cosecha.Maestros;
using Agritracer.Domain.Cosecha.Maestros;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public class BandejaCosechaUseCase : IBandejaCosechaUseCase
    {
        private readonly IBandejaCosechaRepository bandejaCosechaRepository;

        public BandejaCosechaUseCase(IBandejaCosechaRepository bandejaCosechaRepository)
        {
            this.bandejaCosechaRepository = bandejaCosechaRepository;
        }

        public async Task<OutResultData<BEBandejaCosecha>> ExecuteGetById(int id)
        {
            return await this.bandejaCosechaRepository.GetById(id);
        }

        public async Task<OutResultData<List<BEBandejaCosecha>>> ExecuteGetAll(BEArgs args)
        {
            return await this.bandejaCosechaRepository.GetAll(args);
        }

        public async Task<OutResultData<BEBandejaCosecha>> ExecuteInsUpdDel(BEBandejaCosecha bandejaCosecha, int accion)
        {
            return await this.bandejaCosechaRepository.InsUpdDel(bandejaCosecha, accion);
        }

        public async Task<OutResultData<BEBandejaCosecha>> ExecuteDeleteAllSelected(BEArgs args)
        {
            return await this.bandejaCosechaRepository.DeleteAllSelected(args);
        }
    }
}
