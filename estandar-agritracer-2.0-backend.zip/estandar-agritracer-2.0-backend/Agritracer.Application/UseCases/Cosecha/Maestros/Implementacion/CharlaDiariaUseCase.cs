﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Cosecha.Maestros;
using Agritracer.Application.Repositories.Cosecha.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;
using Agritracer.Domain.Common;

namespace Agritracer.Application.UseCases.Cosecha.Maestros.CharlaDiaria
{
    public class CharlaDiariaUseCase : ICharlaDiariaUseCase
    {
        private readonly ICharlaDiariaRepository charlaDiariaRepository;
        public CharlaDiariaUseCase(ICharlaDiariaRepository charlaDiariaRepository)
        {
            this.charlaDiariaRepository = charlaDiariaRepository;
        }
        public async Task<OutResultData<BECharlaDiaria>> ExecuteGetById(int id)
        {
            return await this.charlaDiariaRepository.GetById(id);
        }
        public async Task<OutResultData<List<BECharlaDiaria>>> ExecuteGetAll(BEArgs args)
        {
            return await this.charlaDiariaRepository.GetAll(args);
        }
        public async Task<OutResultData<BECharlaDiaria>> ExecuteInsUpdDel(BECharlaDiaria charla, int accion)
        {
            return await this.charlaDiariaRepository.InsUpdDel(charla, accion);
        }
        public async Task<OutResultData<BECharlaDiaria>> ExecuteDeleteAllSelected(BEArgs args)
        {
            return await this.charlaDiariaRepository.DeleteAllSelected(args);
        }
    }
}
