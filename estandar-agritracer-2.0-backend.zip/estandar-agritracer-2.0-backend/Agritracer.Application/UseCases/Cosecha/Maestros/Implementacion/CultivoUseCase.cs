﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Cosecha.Maestros;
using Agritracer.Application.Repositories.Cosecha.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;
using Agritracer.Domain.Common;

namespace Agritracer.Application.UseCases.Cosecha.Maestros.Cultivo
{
    public class CultivoUseCase : ICultivoUseCase
    {
        private readonly ICultivoRepository cultivoRepository;
        public CultivoUseCase(ICultivoRepository cultivoRepository)
        {
            this.cultivoRepository = cultivoRepository;
        }
        public async Task<OutResultData<BECultivo>> ExecuteGetById(int id)
        {
            return await this.cultivoRepository.GetById(id);
        }
        public async Task<OutResultData<List<BECultivo>>> ExecuteGetAll(BEArgs args)
        {
            return await this.cultivoRepository.GetAll(args);
        }
        public async Task<OutResultData<BECultivo>> ExecuteInsUpdDel(BECultivo cultivo, int accion)
        {
            return await this.cultivoRepository.InsUpdDel(cultivo, accion);
        }
        public async Task<OutResultData<BECultivo>> ExecuteDeleteAllSelected(BEArgs args)
        {
            return await this.cultivoRepository.DeleteAllSelected(args);
        }

    }
}
