﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Cosecha.Maestros;
using Agritracer.Application.Repositories.Cosecha.Maestros;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public class ProductoVariedadUseCase : IProductoVariedadUseCase
    {
        private readonly IProductoVariedadRepository productoVariedadRepository;
        public ProductoVariedadUseCase(IProductoVariedadRepository productoVariedadRepository)
        {
            this.productoVariedadRepository = productoVariedadRepository;
        }
        public async Task<OutResultData<BEProductoVariedad>> ExecuteGetById(int id)
        {
            return await this.productoVariedadRepository.GetById(id);
        }
        public async Task<OutResultData<List<BEProductoVariedad>>> ExecuteGetAll(BEArgs args)
        {
            return await this.productoVariedadRepository.GetAll(args);
        }
        public async Task<OutResultData<BEProductoVariedad>> ExecuteInsUpdDel(BEProductoVariedad productoVariedad, int accion)
        {
            return await this.productoVariedadRepository.InsUpdDel(productoVariedad, accion);
        }
        public async Task<OutResultData<BEProductoVariedad>> ExecuteDeleteAllSelected(BEArgs args)
        {
            return await this.productoVariedadRepository.DeleteAllSelected(args);
        }
    }
}
