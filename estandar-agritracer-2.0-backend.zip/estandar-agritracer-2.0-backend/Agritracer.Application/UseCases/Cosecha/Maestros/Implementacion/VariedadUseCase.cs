﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Application.Repositories.Cosecha.Maestros;
using Agritracer.Domain.Cosecha;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public class VariedadUseCase : IVariedadUseCase
    {
        private readonly IVariedadRepository variedadRepository;
        public VariedadUseCase(IVariedadRepository variedadRepository)
        {
            this.variedadRepository = variedadRepository;
        }
        public async Task<OutResultData<BEVariedad>> ExecuteGetById(int id)
        {
            return await this.variedadRepository.GetById(id);
        }
        public async Task<OutResultData<List<BEVariedad>>> ExecuteGetAll(BEArgs args)
        {
            return await this.variedadRepository.GetAll(args);
        }
        public async Task<OutResultData<BEVariedad>> ExecuteInsUpdDel(BEVariedad variedad, int accion)
        {
            return await this.variedadRepository.InsUpdDel(variedad, accion);
        }
        public async Task<OutResultData<BEVariedad>> ExecuteDeleteAllSelected(BEArgs args)
        {
            return await this.variedadRepository.DeleteAllSelected(args);
        }
    }
}
