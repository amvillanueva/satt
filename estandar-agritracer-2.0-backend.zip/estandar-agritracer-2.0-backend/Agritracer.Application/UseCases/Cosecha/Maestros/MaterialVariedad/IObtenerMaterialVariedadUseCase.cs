﻿using Agritracer.Domain.Cosecha;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public interface IObtenerMaterialVariedadUseCase
    {
        Task<IEnumerable<BEMaterialVariedad>> Execute(int variedadID);
    }
}
