﻿using Agritracer.Application.Repositories.Cosecha.Maestros;
using Agritracer.Domain.Cosecha;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public class ObtenerMaterialVariedadUseCase : IObtenerMaterialVariedadUseCase
    {
        private readonly IMaterialVariedadReadWriteRepository _materialvariedadReadWriteRepository;

        public ObtenerMaterialVariedadUseCase(IMaterialVariedadReadWriteRepository materialvariedadReadWriteRepository)
        {
            _materialvariedadReadWriteRepository = materialvariedadReadWriteRepository;
        }

        public async Task<IEnumerable<BEMaterialVariedad>> Execute(int variedadID)
        {
            return await _materialvariedadReadWriteRepository.GetAll(variedadID);
           
        }
    }
}
