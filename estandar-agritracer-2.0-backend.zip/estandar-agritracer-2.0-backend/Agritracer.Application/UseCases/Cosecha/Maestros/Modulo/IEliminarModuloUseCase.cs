﻿using Agritracer.Application.OutputObjets.Cosecha.Maestros;
using Agritracer.Domain.Cosecha;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public interface IEliminarModuloUseCase
    {
        Task<OutModuloUseCase> Execute(List<int> moduloIDs);
    }
}
