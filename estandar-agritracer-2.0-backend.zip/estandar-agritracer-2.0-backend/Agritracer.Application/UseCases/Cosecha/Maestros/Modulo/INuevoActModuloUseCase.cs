﻿using Agritracer.Domain.Cosecha;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public interface INuevoActModuloUseCase
    {
        Task<BEModulo> Execute(BEModulo modulo);
    }
}
