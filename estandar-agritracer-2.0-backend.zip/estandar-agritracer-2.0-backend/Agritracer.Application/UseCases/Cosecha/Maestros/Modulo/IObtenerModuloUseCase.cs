﻿using Agritracer.Domain.Cosecha;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public interface IObtenerModuloUseCase
    {
        Task<IEnumerable<BEModulo>> Execute(int modulo,int empresa,int fundo,int estado);
    }
}
