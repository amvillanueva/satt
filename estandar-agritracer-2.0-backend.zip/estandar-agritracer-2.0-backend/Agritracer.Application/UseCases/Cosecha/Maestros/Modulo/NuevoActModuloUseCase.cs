﻿using Agritracer.Application.Repositories.Cosecha.Maestros;
using Agritracer.Domain.Cosecha;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public class NuevoActModuloUseCase : INuevoActModuloUseCase
    {
        private readonly IModuloReadWriteRepository _moduloReadWriteRepository;

        public NuevoActModuloUseCase(IModuloReadWriteRepository moduloReadWriteRepository)
        {
            _moduloReadWriteRepository = moduloReadWriteRepository;
        }

        public async Task<BEModulo> Execute(BEModulo modulo)
        {
            try
            {
                String xml = "";
                var xEle = new XElement("r",
                from turno in modulo.moduloTurnos
                select new XElement("turnos",
                    new XAttribute("empresaID", turno.empresaID),
                    new XAttribute("moduloID", turno.moduloID),
                    new XAttribute("turnoID", turno.turnoID),
                    new XAttribute("turnoCodigo", turno.turnoCodigo),
                    new XAttribute("turnoNombre", turno.turnoNombre),
                    new XAttribute("turnoArea", turno.turnoArea),
                    new XAttribute("turnoStatus", turno.turnoStatus),
                    new XAttribute("turnoUsuario", turno.turnoUsuario),
                    from lote in turno.turnoLotes
                    select new XElement("lotes",
                        new XAttribute("turnoID", lote.turnoID),
                        new XAttribute("loteID", lote.loteID),
                        new XAttribute("empresaID", lote.empresaID),
                        new XAttribute("loteCodigo", lote.loteCodigo),
                        new XAttribute("loteNombre", lote.loteNombre),
                        new XAttribute("loteArea", lote.loteArea),
                        new XAttribute("loteDensidad", lote.loteDensidad),
                        new XAttribute("loteFechaPlantacion", lote.loteFechaPlantacion),
                        new XAttribute("loteSpaceAG", lote.loteSpaceAG),
                        new XAttribute("loteStatus", lote.loteStatus),
                        new XAttribute("loteUsuario", lote.loteUsuario),
                        from variedad in lote.loteVariedades
                        select new XElement("variedades",
                            new XAttribute("loteID", variedad.loteID),
                            new XAttribute("variedadID", variedad.variedadID),
                            new XAttribute("variedadloteID", variedad.variedadloteID),
                            new XAttribute("variedadloteStatus", variedad.variedadloteStatus),
                            new XAttribute("variedadloteUsuario", variedad.variedadloteUsuario)))
                    ));

                xml = Convert.ToString(xEle);
                modulo.moduloTurnosStr = xml;
                return await _moduloReadWriteRepository.AddUpdate(modulo);
            }
            catch (Exception ex) {
                return new BEModulo()
                {
                    moduloID = -1,
                    moduloIDServidor = -1,
                    moduloMsgServidor = ex.Message
                };
            }
        }
    }
}
