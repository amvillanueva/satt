﻿using Agritracer.Application.Repositories.Cosecha.Maestros;
using Agritracer.Domain.Cosecha;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public class ObtenerModuloUseCase : IObtenerModuloUseCase
    {
        private readonly IModuloReadWriteRepository _moduloReadWriteRepository;

        public ObtenerModuloUseCase(IModuloReadWriteRepository moduloReadWriteRepository)
        {
            _moduloReadWriteRepository = moduloReadWriteRepository;
        }

        public async Task<IEnumerable<BEModulo>> Execute(int modulo,int empresa,int fundo,int estado)
        {
            if (modulo != -1)
            {
                List<BEModulo> lst = new List<BEModulo>();
                BEModulo moduloRpta = await _moduloReadWriteRepository.GetByID(modulo);

                if (moduloRpta != null)
                {
                    if(moduloRpta.moduloID!=-1)
                        lst.Add(moduloRpta);
                }
                
                return lst;
            }
            else
            {
                return await _moduloReadWriteRepository.GetAll(empresa,fundo,estado);
            }
        }
    }
}
