﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Cosecha.Maestros.Movil;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros.Movil
{
    public interface IObtenerDataMestraUseCase
    {
        Task<OutResultData<BEDataMaestra>> Execute(int empresaID, int usuarioID);
    }

}
