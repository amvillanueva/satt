﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.Cosecha.Maestros.Movil;
using Agritracer.Domain.Cosecha.Maestros.Movil;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros.Movil
{
    class ObtenerDataMestraUseCase : IObtenerDataMestraUseCase
    {
        private readonly IDataMaestraReadWriteRepository _dataMaestraReadWriteRepository;

        public ObtenerDataMestraUseCase(IDataMaestraReadWriteRepository dataMaestraReadWriteRepository)
        {
            _dataMaestraReadWriteRepository = dataMaestraReadWriteRepository;
        }

        public async Task<OutResultData<BEDataMaestra>> Execute(int empresaID, int usuarioID)
        {
            return await _dataMaestraReadWriteRepository.GetBy(empresaID, usuarioID);

        }
    }

}
