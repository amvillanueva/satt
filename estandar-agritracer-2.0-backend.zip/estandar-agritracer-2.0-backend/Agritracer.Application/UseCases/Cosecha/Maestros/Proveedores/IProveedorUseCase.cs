﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Cosecha.Maestros;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros.Proveedores
{
    public interface IProveedorUseCase
    {
        Task<OutResultData<BEProveedor>> ExecuteGetById(int id);
        Task<OutResultData<List<BEProveedor>>> ExecuteGetAll(BEArgs args);
        Task<OutResultData<BEProveedor>> ExecuteInsUpdDel(BEProveedor vehiculo, int accion);
        Task<OutResultData<BEProveedor>> ExecuteDeleteAllSelected(BEArgs args);
    }
}
