﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.Cosecha.Maestros;
using Agritracer.Domain.Common;
using Agritracer.Domain.Cosecha.Maestros;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros.Proveedores
{
    public class ProveedorUseCase : IProveedorUseCase
    {
        public readonly IProveedorRepository proveedorRepository;
        public ProveedorUseCase(IProveedorRepository proveedorRepository)
        {
            this.proveedorRepository = proveedorRepository;
        }
        public async Task<OutResultData<BEProveedor>> ExecuteGetById(int id)
        {
            return await this.proveedorRepository.GetById(id);
        }
        public async Task<OutResultData<List<BEProveedor>>> ExecuteGetAll(BEArgs args)
        {
            return await this.proveedorRepository.GetAll(args);
        }
        public async Task<OutResultData<BEProveedor>> ExecuteInsUpdDel(BEProveedor vehiculo, int accion)
        {
            return await this.proveedorRepository.InsUpdDel(vehiculo, accion);
        }
        public async Task<OutResultData<BEProveedor>> ExecuteDeleteAllSelected(BEArgs args)
        {
            return await this.proveedorRepository.DeleteAllSelected(args);
        }
    }
}
