﻿
using Agritracer.Application.Repositories.Cosecha.Procesos.Web;
using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using System.Threading.Tasks;
using System.Data;
using Agritracer.Domain.Cosecha.Procesos;

namespace Agritracer.Application.UseCases.Cosecha.Procesos.CapturaPeso
{
    public class CapturaPesoUseCase : ICapturaPesoUseCase
    {
        private readonly ICapturaPesoRepository _capturaPesoRepository;

        public CapturaPesoUseCase(ICapturaPesoRepository capturaPesoRepository)
        {
            _capturaPesoRepository = capturaPesoRepository;
        }

        //----------------------------------------------

        public async Task<OutResultData<DataTable>> ListadoPalletsExec(BEArgs args)
        {
            return await _capturaPesoRepository.ListadoPallets(args);
        }

        public async Task<OutResultData<BEPalletArgs>> UpdateCapturaPesoPalletExec(BEPalletArgs args)
        {
            var rpta = await _capturaPesoRepository.UpdateCapturaPesoPallet(args);

            if (rpta.statusCode <= 0)
            {
                throw new ApplicationException(rpta.message);
            }
            else
            {
                return rpta;
            }
        }
    }
}
