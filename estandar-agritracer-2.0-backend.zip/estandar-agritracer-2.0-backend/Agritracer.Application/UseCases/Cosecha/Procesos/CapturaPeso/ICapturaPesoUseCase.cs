﻿
using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using System.Threading.Tasks;
using System.Data;
using Agritracer.Domain.Cosecha.Procesos;

namespace Agritracer.Application.UseCases.Cosecha.Procesos.CapturaPeso
{
    public interface ICapturaPesoUseCase
    {
        Task<OutResultData<DataTable>> ListadoPalletsExec(BEArgs args);
        Task<OutResultData<BEPalletArgs>> UpdateCapturaPesoPalletExec(BEPalletArgs args);
    }
}
