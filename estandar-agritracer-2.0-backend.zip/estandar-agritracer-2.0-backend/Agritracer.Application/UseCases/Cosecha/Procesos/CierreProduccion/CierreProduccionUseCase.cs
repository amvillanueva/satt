﻿using Agritracer.Application.Repositories.Cosecha.Procesos.Web;
using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Cosecha.Procesos;
using System.Threading.Tasks;
using System.Data;

namespace Agritracer.Application.UseCases.Cosecha.Procesos.CierreProduccion
{
    public class CierreProduccionUseCase : ICierreProduccionUseCase
    {
        private readonly ICierreProduccionRepository _cierreProduccionRepository;

        public CierreProduccionUseCase(ICierreProduccionRepository cierreProduccionRepository)
        {
            _cierreProduccionRepository = cierreProduccionRepository;
        }

        //-------------------------------------------

        public async Task<OutResultData<DataSet>> ObtenerPendienteExec(BEProduccionArgs args)
        {
            return await _cierreProduccionRepository.GetCierreProduccionPendiente(args);
        }

        public async Task<OutResultData<DataTable>> ObtenerResumenExec(BEProduccionArgs args)
        {
            return await _cierreProduccionRepository.GetCierreProduccionResumen(args);
        }

        public async Task<OutResultData<BEProduccionArgs>> ProcesarCierreExec(BEProduccionArgs transaccion)
        {
            var rpta = await _cierreProduccionRepository.ProcesarCierreProduccion(transaccion);

            if (rpta.statusCode <= 0)
            {
                throw new ApplicationException(rpta.message);
            }
            else
            {
                return rpta;
            }
        }
    }
}
