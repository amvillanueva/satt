﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Cosecha.Procesos;
using System.Threading.Tasks;
using System.Data;

namespace Agritracer.Application.UseCases.Cosecha.Procesos.CierreProduccion
{
    public interface ICierreProduccionUseCase
    {
        Task<OutResultData<DataSet>> ObtenerPendienteExec(BEProduccionArgs args);
        Task<OutResultData<DataTable>> ObtenerResumenExec(BEProduccionArgs args);

        Task<OutResultData<BEProduccionArgs>> ProcesarCierreExec(BEProduccionArgs transaccion);
    }
}
