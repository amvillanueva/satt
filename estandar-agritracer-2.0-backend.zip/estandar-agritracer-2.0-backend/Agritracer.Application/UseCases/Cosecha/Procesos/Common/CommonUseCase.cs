﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.Cosecha.Procesos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Procesos.Common
{
    public class CommonUseCase : ICommonUseCase
    {
        private readonly ICommonRepository _commonRepository;

        public CommonUseCase(ICommonRepository commonRepository)
        {
            _commonRepository = commonRepository;
        }

        public async Task<OutResultData<Dictionary<string, object>>> ObtenerVehiculoByCodeQRExecute(string codigoQR, int grupotrabajoId)
        {
            return await _commonRepository.GetVehiculoByCodeQR(codigoQR, grupotrabajoId);
        }

        public async Task<OutResultData<Dictionary<string, object>>> ObtenerBandejaLecturadaByBandejaQRExecute(string codigoQR, string dniTrabajador, int impresionId, int grupoTrabajoId, int supervisorId)
        {
            return await _commonRepository.GetBandejaLecturadaByBandejaQR(codigoQR, dniTrabajador, impresionId, grupoTrabajoId, supervisorId);
        }
    
    }
}
