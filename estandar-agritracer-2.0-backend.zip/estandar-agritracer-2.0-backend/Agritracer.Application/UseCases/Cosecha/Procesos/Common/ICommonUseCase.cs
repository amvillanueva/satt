﻿using Agritracer.Application.OutputObjets;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Procesos.Common
{
    public interface ICommonUseCase
    {
        Task<OutResultData<Dictionary<string, object>>> ObtenerVehiculoByCodeQRExecute(string codeqr, int grupotrabajoId);
        Task<OutResultData<Dictionary<string, object>>> ObtenerBandejaLecturadaByBandejaQRExecute(string codeqr, string dniTrabajador, int impresionId, int grupoTrabajoId, int supervisorId);
    }

}
