﻿using Agritracer.Application.Repositories.Cosecha.Procesos.Web;
using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using System.Threading.Tasks;
using System.Data;
using Agritracer.Domain.Cosecha.Procesos;
using System.Collections.Generic;

namespace Agritracer.Application.UseCases.Cosecha.Procesos.CosechaDiaria
{
    public class CosechaDiariaUseCase : ICosechaDiariaUseCase
    {
        private readonly ICosechaDiariaRepository _cosechaDiariaRepository;

        public CosechaDiariaUseCase(ICosechaDiariaRepository cosechaDiariaRepository)
        {
            _cosechaDiariaRepository = cosechaDiariaRepository;
        }

        public async Task<OutResultData<DataTable>> ObtenerResumenExec(BEArgs args)
        {
            return await _cosechaDiariaRepository.GetResumenProduccion(args);
        }

        public async Task<OutResultData<DataTable>> ObtenerDetalleExec(BEArgs args)
        {
            return await _cosechaDiariaRepository.GetDetalleProduccion(args);
        }

        public async Task<OutResultData<DataSet>> ObtenerDashboardResumenExec(BEArgs args)
        {
            return await _cosechaDiariaRepository.GetDashboardResumen(args);
        }

        public async Task<OutResultData<DataSet>> ObtenerDashboardTransporteExec(BEArgs args)
        {
            return await _cosechaDiariaRepository.GetDashboardTransporte(args);
        }

        public async Task<List<BEProduccionFirestore>> ObtenerProduccionConsolidadoExec(BEArgs args)
        {
            return await _cosechaDiariaRepository.GetProduccionConsolidado(args);
        }

        public async Task<OutResultData<BEProduccionCampo>> UpdateEstadoProduccionCampoExec(BEProduccionCampo args)
        {
            var rpta = await _cosechaDiariaRepository.UpdateEstadoProduccionCampo(args);

            if (rpta.statusCode <= 0)
            {
                throw new ApplicationException(rpta.message);
            }
            else
            {
                return rpta;
            }
        }

        public async Task<OutResultData<BEProduccionCampo>> UpdateBandejaProduccionCampoExec(BEProduccionCampo args)
        {
            var rpta = await _cosechaDiariaRepository.UpdateBandejaProduccionCampo(args);

            if (rpta.statusCode <= 0)
            {
                throw new ApplicationException(rpta.message);
            }
            else
            {
                return rpta;
            }
        }

        public async Task<OutResultData<BEProduccionCampo>> UpdateLoteProduccionCampoExec(BEProduccionCampo args)
        {
            var rpta = await _cosechaDiariaRepository.UpdateLoteProduccionCampo(args);

            if (rpta.statusCode <= 0)
            {
                throw new ApplicationException(rpta.message);
            }
            else
            {
                return rpta;
            }
        }

        public async Task<OutResultData<DataSet>> ObtenerProduccionCierreHectareaExec(BEArgs args)
        {
            return await _cosechaDiariaRepository.GetDetalleCierreHectarea(args);
        }

        public async Task<OutResultData<DataSet>> ObtenerProduccionTransporteMPExec(BEArgs args)
        {
            return await _cosechaDiariaRepository.GetDetalleTransporteMP(args);
        }
    }
}
