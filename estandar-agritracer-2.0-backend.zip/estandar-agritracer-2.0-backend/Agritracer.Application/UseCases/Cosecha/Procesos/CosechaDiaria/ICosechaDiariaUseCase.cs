﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using System.Threading.Tasks;
using System.Data;
using Agritracer.Domain.Cosecha.Procesos;
using System.Collections.Generic;

namespace Agritracer.Application.UseCases.Cosecha.Procesos.CosechaDiaria
{
    public interface ICosechaDiariaUseCase
    {
        Task<OutResultData<DataTable>> ObtenerResumenExec(BEArgs args);
        Task<OutResultData<DataTable>> ObtenerDetalleExec(BEArgs args);
        Task<List<BEProduccionFirestore>> ObtenerProduccionConsolidadoExec(BEArgs args);
        Task<OutResultData<DataSet>> ObtenerDashboardResumenExec(BEArgs args);
        Task<OutResultData<DataSet>> ObtenerDashboardTransporteExec(BEArgs args);
        Task<OutResultData<BEProduccionCampo>> UpdateEstadoProduccionCampoExec(BEProduccionCampo args);
        Task<OutResultData<BEProduccionCampo>> UpdateLoteProduccionCampoExec(BEProduccionCampo args);
        Task<OutResultData<BEProduccionCampo>> UpdateBandejaProduccionCampoExec(BEProduccionCampo args);
        Task<OutResultData<DataSet>> ObtenerProduccionCierreHectareaExec(BEArgs args);
        Task<OutResultData<DataSet>> ObtenerProduccionTransporteMPExec(BEArgs args);
    }
}
