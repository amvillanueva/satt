﻿using Agritracer.Application.OutputObjets.Cosecha.Procesos;
using Agritracer.Application.Repositories.Cosecha.Procesos;
using Agritracer.Application.UseCases.Cosecha.Procesos;
using Agritracer.Domain.Cosecha.Procesos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public class GuiaRemisionCampoUseCase : IGuiaRemisionCampoUseCase
    {
        private readonly IGuiaRemisionCampoReadWriteRepository _guiaremisioncampoReadWriteRepository;

        public GuiaRemisionCampoUseCase(IGuiaRemisionCampoReadWriteRepository guiaremisioncampoReadWriteRepository)
        {
            _guiaremisioncampoReadWriteRepository = guiaremisioncampoReadWriteRepository;
        }

        public async Task<OutGuiaRemisionCampoUseCase> AnularExec(BEGuiaRemisionCampo guiaremision)
        {
            return await _guiaremisioncampoReadWriteRepository.Delete(guiaremision);
        }
        
        public async Task<BEGuiaRemisionCampo> NuevoActualizarExec(BEGuiaRemisionCampo guiaremision)
        {
            try
            {
                string xml = "";
                var xEle = new XElement("r",
                from detalle in guiaremision.guiaremisioncampoDetalles
                select new XElement("detalles",
                    new XAttribute("guiaremisionDetalleID", detalle.guiaremisionDetalleID),
                    new XAttribute("guiaremisionItem", detalle.guiaremisionItem),
                    new XAttribute("fundoID", detalle.fundoID),
                    new XAttribute("moduloID", detalle.moduloID),
                    new XAttribute("variedadID", detalle.variedadID),
                    new XAttribute("materialVariedadID", detalle.materialVariedadID),
                    new XAttribute("guiaremisionDetallePesoBruto", detalle.guiaremisionDetallePesoBruto),
                    new XAttribute("guiaremisionDetallePesoNeto", detalle.guiaremisionDetallePesoNeto),
                    new XAttribute("guiaremisionDetalleCantidad", detalle.guiaremisionDetalleCantidad),
                    new XAttribute("guiaremisionDetalleStatus", detalle.guiaremisionDetalleStatus),
                    new XAttribute("guiaremisionDetalleUsuario", detalle.guiaremisionDetalleUsuario)));
                xml = Convert.ToString(xEle);
                guiaremision.guiaremisioncampoDetallesStr = xml;

                var xEleP = new XElement("r",
                from detalle in guiaremision.guiaremisioncampoPallets
                select new XElement("detalles",
                    new XAttribute("palletID", detalle.palletID),
                    new XAttribute("barcodePallet", detalle.barcodePallet)));
                xml = Convert.ToString(xEle);
                guiaremision.guiaremisioncampoPalletsStr = xml;

                return await _guiaremisioncampoReadWriteRepository.AddUpdate(guiaremision);
            }catch (Exception ex){
                return new BEGuiaRemisionCampo()
                {
                    guiaremisioncampoID= -1,
                    guiaremisioncampoIDServidor = -1,
                    guiaremisioncampoMsgServidor = ex.Message
                };
            }
        }

        public async Task<IEnumerable<BEGuiaRemisionCampo>> ObtenerExec(string fechaini,string fechafin, int empresaID, int cultivoId,
            bool incluirAnulados,string guiaRemision,int guiaRemisionID)
        {
            if (guiaRemisionID != -1)
            {
                List<BEGuiaRemisionCampo> lst = new List<BEGuiaRemisionCampo>();
                BEGuiaRemisionCampo guiaRpta = await _guiaremisioncampoReadWriteRepository.GetByID(guiaRemisionID);

                if (guiaRpta != null)
                {
                    if (guiaRpta.guiaremisioncampoID != -1)
                        lst.Add(guiaRpta);
                }

                return lst;
            }
            else
            {
                return await _guiaremisioncampoReadWriteRepository.GetAll(fechaini,fechafin, empresaID, cultivoId, guiaRemision, incluirAnulados);
            }
        }
    }
}
