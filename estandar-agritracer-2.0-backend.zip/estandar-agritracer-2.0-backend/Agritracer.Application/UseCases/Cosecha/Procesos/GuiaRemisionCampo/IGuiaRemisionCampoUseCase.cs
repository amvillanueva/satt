﻿using Agritracer.Application.OutputObjets.Cosecha.Procesos;
using Agritracer.Domain.Cosecha;
using Agritracer.Domain.Cosecha.Procesos;
using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Procesos
{
    public interface IGuiaRemisionCampoUseCase
    {
        Task<IEnumerable<BEGuiaRemisionCampo>> ObtenerExec(string fechaIni,string fechafin, int empresaID, int cultivoID, 
            bool incluirAnulados,string numeroGuia, int guiaRemisionID);
        Task<BEGuiaRemisionCampo> NuevoActualizarExec(BEGuiaRemisionCampo guiaRemision);
        Task<OutGuiaRemisionCampoUseCase> AnularExec(BEGuiaRemisionCampo guiaRemision);
    }
}
