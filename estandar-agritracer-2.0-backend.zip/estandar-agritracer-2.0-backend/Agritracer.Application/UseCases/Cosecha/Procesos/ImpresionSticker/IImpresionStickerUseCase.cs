﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.OutputObjets.Cosecha.Procesos;
using Agritracer.Domain.Common;
using Agritracer.Domain.Common.Maestros;
using Agritracer.Domain.Cosecha;
using Agritracer.Domain.Cosecha.Procesos;
using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Procesos
{
    public interface IImpresionStickerUseCase
    {
        Task<OutResultData<BEImpresionSticker>> ExecuteGetById(int id);
        Task<OutResultData<List<BEImpresionSticker>>> ExecuteGetAll(BEArgs args);
        Task<OutResultData<BEImpresionSticker>> ExecuteInsUpdDel(BEImpresionSticker impresionSticker, int accion);
        Task<OutResultData<BEImpresionSticker>> ExecuteDeleteAllSelected(BEArgs args);
        Task<OutResultData<List<BETrabajador>>> ExecuteGetTrabajadoresByImpresionSticker(BEArgs args);
        Task<OutResultData<BEImpresionSticker>> ExecutePrintById(int id);
        Task<OutResultData<string>> ExecuteActualizarEstadoImpreso(int id);
        Task<OutResultData<BEImpresionSticker>> ExecuteObtenerControlAsistencia(int id);
    }
}
