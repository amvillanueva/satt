﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.OutputObjets.Cosecha.Procesos;
using Agritracer.Application.Repositories.Cosecha.Procesos;
using Agritracer.Application.UseCases.Cosecha.Procesos;
using Agritracer.Domain.Common;
using Agritracer.Domain.Common.Maestros;
using Agritracer.Domain.Cosecha;
using Agritracer.Domain.Cosecha.Procesos;
using Agritracer.Domain.ManoObra.Maestros;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Agritracer.Application.UseCases.Cosecha.Procesos
{
    public class ImpresionStickerUseCase : IImpresionStickerUseCase
    {
        private readonly IImpresionStickerRepository impresionStickerRepository;

        public ImpresionStickerUseCase(IImpresionStickerRepository impresionStickerRepository)
        {
            this.impresionStickerRepository = impresionStickerRepository;
        }
        public async Task<OutResultData<BEImpresionSticker>> ExecuteGetById(int id)
        {
            return await this.impresionStickerRepository.GetById(id);
        }
        public async Task<OutResultData<List<BEImpresionSticker>>> ExecuteGetAll(BEArgs args)
        {
            return await this.impresionStickerRepository.GetAll(args);
        }
        public async Task<OutResultData<BEImpresionSticker>> ExecuteInsUpdDel(BEImpresionSticker impresionSticker, int accion)
        {
            return await this.impresionStickerRepository.InsUpdDel(impresionSticker, accion);
        }
        public async Task<OutResultData<BEImpresionSticker>> ExecuteDeleteAllSelected(BEArgs args)
        {
            return await this.impresionStickerRepository.DeleteAllSelected(args);
        }
        public async Task<OutResultData<List<BETrabajador>>> ExecuteGetTrabajadoresByImpresionSticker(BEArgs args)
        {
            return await this.impresionStickerRepository.GetTrabajadoresByImpresionSticker(args);
        }
        public async Task<OutResultData<BEImpresionSticker>> ExecutePrintById(int id)
        {
            return await this.impresionStickerRepository.PrintById(id);
        }
        public async Task<OutResultData<string>> ExecuteActualizarEstadoImpreso(int id)
        {
            return await this.impresionStickerRepository.ActualizarEstadoImpreso(id);
        }
        public async Task<OutResultData<BEImpresionSticker>> ExecuteObtenerControlAsistencia(int id)
        {
            return await this.impresionStickerRepository.ObtenerControlAsistencia(id);
        }
    }
}
