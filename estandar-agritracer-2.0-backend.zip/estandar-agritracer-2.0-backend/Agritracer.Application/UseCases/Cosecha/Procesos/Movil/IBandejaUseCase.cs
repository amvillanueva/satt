﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Cosecha.Maestros.Movil;
using Agritracer.Domain.Cosecha.Procesos.Movil;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Procesos.Movil
{
    public interface IBandejaUseCase
    {
        Task<OutResultData<List<BEProduccionMovil>>> ExecuteRegistrarBandejasCosechadas(List<BEProduccionMovil> produccionMovils);
        Task<OutResultData<String>> ExecuteRegistrarDespachoBandejasCosechadas(BEParamsDespachoBandeja despachoBandejas);
        Task<OutResultData<BEGrupoDashBoardCosecha>> ExecuteObtenerDatosDashboardCosecha(int grupoTrabajoId);
        Task<OutResultData<DataTable>> ExecuteObtenerProduccionLote(int empresaId, int cultivoId, int grupoTrabajoId);
        Task<OutResultData<string>> ExecuteRegistrarDescarteBandejaCosechada(BEDescarteCosecha descarteBandejaCosecha);
        Task<OutResultData<Dictionary<String, Object>>> ExecuteObtenerStockDescarteByParams(int empresaId, int grupoTrabajoId, int fundoId, int moduloId, int cultivoId);
    }

}
