﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using Agritracer.Domain.Cosecha.CierreLote.Movil;
using System.Threading.Tasks;
using Agritracer.Domain.Cosecha.Procesos.Movil;

namespace Agritracer.Application.UseCases.Cosecha.Procesos.Movil
{
    public interface ICierreLoteUseCase
    {
        Task<OutResultData<string>> ExecuteRegistrarLoteCerrado(List<BELoteCerradoMovil> loteCerradoMovil);
        Task<OutResultData<string>> ExecuteRegistrarLoteCerrado2(BEArgs loteCerradoMovil);

        Task<OutResultData<string>> ExecuteRegistrarAprobacion(BEArgs loteCerradoMovil);
        Task<OutResultData<List<BECierreLote>>> ExecuteListadoCierreLote(BEArgs args);
        Task<OutResultData<List<BECierreLote>>> ExecuteListadoMonitoreoCierreLote(BEArgs args);
        Task<OutResultData<List<BEFoto>>> ExecuteListadoFotos(BEArgs args);
    }

}
