﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.Cosecha.Procesos.Movil;
using Agritracer.Domain.Common;
using Agritracer.Domain.Cosecha.Maestros.Movil;
using Agritracer.Domain.Cosecha.Procesos.Movil;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlTypes;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Agritracer.Application.UseCases.Cosecha.Procesos.Movil.Implementacion
{
    public class BandejaUseCase : IBandejaUseCase
    {
        private readonly IBandejaRepository bandejaRepository;
        public BandejaUseCase(IBandejaRepository bandejaRepository)
        {
            this.bandejaRepository = bandejaRepository;
        }

        public async Task<OutResultData<List<BEProduccionMovil>>> ExecuteRegistrarBandejasCosechadas(List<BEProduccionMovil> produccionMovils)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(produccionMovils.GetType());

            StringWriter textWriter = new StringWriter();
            xmlSerializer.Serialize(textWriter, produccionMovils);

            StringReader transactionXml = new StringReader(textWriter.ToString());
            XmlTextReader xmlReader = new XmlTextReader(transactionXml);
            SqlXml produccionXML = new SqlXml(xmlReader);

            return await bandejaRepository.RegistrarBandejasCosechadas(produccionXML);
        }

        public async Task<OutResultData<string>> ExecuteRegistrarDespachoBandejasCosechadas(BEParamsDespachoBandeja despachoBandejas)
        {
            return await bandejaRepository.RegistrarDespachoBandejasCosechadas(despachoBandejas);
        }

        public async Task<OutResultData<BEGrupoDashBoardCosecha>> ExecuteObtenerDatosDashboardCosecha(int grupoTrabajoId)
        {
            return await bandejaRepository.ObtenerDatosDashboardCosecha(grupoTrabajoId);
        }

        public async Task<OutResultData<DataTable>> ExecuteObtenerProduccionLote(int empresaId, int cultivoId, int grupoTrabajoId)
        {
            return await bandejaRepository.ObtenerProduccionLote(empresaId, cultivoId, grupoTrabajoId);
        }

        public async Task<OutResultData<string>> ExecuteRegistrarDescarteBandejaCosechada(BEDescarteCosecha descarteBandejaCosecha)
        {
            return await bandejaRepository.RegistrarDescarteBandejaCosechada(descarteBandejaCosecha);
        }

        public async Task<OutResultData<Dictionary<String, Object>>> ExecuteObtenerStockDescarteByParams(int empresaId, int grupoTrabajoId, int fundoId, int moduloId, int cultivoId)
        {
            return await bandejaRepository.ObtenerStockDescarteByParams(empresaId, grupoTrabajoId, fundoId, moduloId, cultivoId);
        }

    }
}
