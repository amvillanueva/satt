﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.Cosecha.Procesos.Movil;
using Agritracer.Domain.Common;
using Agritracer.Domain.Cosecha.CierreLote.Movil;
using Agritracer.Domain.Cosecha.Procesos.Movil;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.IO;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Agritracer.Application.UseCases.Cosecha.Procesos.Movil.Implementacion
{
    class CierreLoteUseCase : ICierreLoteUseCase
    {
        private readonly ICierreLoteRepository cierreLoteRepository;
        public CierreLoteUseCase(ICierreLoteRepository cierreLoteRepository)
        {
            this.cierreLoteRepository = cierreLoteRepository;
        }

        public async Task<OutResultData<string>> ExecuteRegistrarLoteCerrado(List<BELoteCerradoMovil> loteCerradoMovil)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(loteCerradoMovil.GetType());

            StringWriter textWriter = new StringWriter();
            xmlSerializer.Serialize(textWriter, loteCerradoMovil);

            StringReader transactionXml = new StringReader(textWriter.ToString());
            XmlTextReader xmlReader = new XmlTextReader(transactionXml);
            SqlXml cierreLoteXML = new SqlXml(xmlReader);

            return await cierreLoteRepository.RegistrarLoteCerrado(cierreLoteXML);
        }


        public async Task<OutResultData<string>> ExecuteRegistrarLoteCerrado2(BEArgs args)
        {
            return await cierreLoteRepository.RegistrarLoteCerrado2(args);
        }

        public async Task<OutResultData<string>> ExecuteRegistrarAprobacion(BEArgs args)
        {
            return await cierreLoteRepository.RegistrarAprobacion(args);
        }

        public async Task<OutResultData<List<BECierreLote>>> ExecuteListadoCierreLote(BEArgs args)
        {
            return await this.cierreLoteRepository.ExecuteListadoCierreLote(args);
        }

        public async Task<OutResultData<List<BECierreLote>>> ExecuteListadoMonitoreoCierreLote(BEArgs args)
        {
            return await this.cierreLoteRepository.ExecuteListadoMonitoreoCierreLote(args);
        }

        public async Task<OutResultData<List<BEFoto>>> ExecuteListadoFotos(BEArgs args)
        {
            return await this.cierreLoteRepository.ExecuteListadoFotos(args);
        }
    }
}
