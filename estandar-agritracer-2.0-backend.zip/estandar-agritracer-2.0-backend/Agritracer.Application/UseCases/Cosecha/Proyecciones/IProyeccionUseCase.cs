﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Cosecha.Proyecciones;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Data;

namespace Agritracer.Application.UseCases.Cosecha.Proyecciones
{
    public interface IProyeccionUseCase
    {
        Task<OutResultData<List<BEProyeccion>>> ExecuteGetAll(BEArgs args);
        Task<OutResultData<DataSet>> ExecuteImportarProyecciones(BEArgs args);
        Task<OutResultData<DataSet>> ExecuteGuardarProyecciones(BEArgs args);
        Task<OutResultData<BEProyeccion>> ExecuteCambiarEstadoProyecciones(BEArgs args);
        Task<OutResultData<List<BEProyeccion>>> ExecuteGetAllDetalle(BEArgs args);
        Task<OutResultData<DataSet>> ExecuteImportarProyeccionesDetalle(BEArgs args);
        Task<OutResultData<DataSet>> ExecuteGuardarProyeccionesDetalle(BEArgs args);
        Task<OutResultData<BEProyeccion>> ExecuteCambiarEstadoProyeccionesDetalle(BEArgs args);
        Task<OutResultData<List<BEProyeccion>>> ExecuteGetAllAjuste(BEArgs args);
        Task<OutResultData<BEProyeccion>> ExecuteGuardarProyeccionesAjuste(BEArgs args);
        Task<OutResultData<BEProyeccion>> ExecuteCambiarEstadoProyeccionesAjuste(BEArgs args);
        Task<OutResultData<List<BEProyeccion>>> ExecuteGetAllAjusteMovil(BEArgs args);
    }
}