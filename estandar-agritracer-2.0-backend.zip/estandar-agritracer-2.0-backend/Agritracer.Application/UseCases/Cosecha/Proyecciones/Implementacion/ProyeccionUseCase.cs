﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.Cosecha.Proyecciones;
using Agritracer.Domain.Cosecha.Proyecciones;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Data;

namespace Agritracer.Application.UseCases.Cosecha.Proyecciones.Implementacion
{
    public class ProyeccionUseCase : IProyeccionUseCase
    {
        private readonly IProyeccionRepository proyeccionRepository;
        public ProyeccionUseCase(IProyeccionRepository proyeccionRepository)
        {
            this.proyeccionRepository = proyeccionRepository;
        }

        public async Task<OutResultData<List<BEProyeccion>>> ExecuteGetAll(BEArgs args)
        {
            return await this.proyeccionRepository.GetAll(args);
        }

        public async Task<OutResultData<DataSet>> ExecuteImportarProyecciones(BEArgs args)
        {
            return await this.proyeccionRepository.ImportarProyecciones(args);
        }

        public async Task<OutResultData<DataSet>> ExecuteGuardarProyecciones(BEArgs args)
        {
            return await this.proyeccionRepository.GuardarProyecciones(args);
        }

        public async Task<OutResultData<BEProyeccion>> ExecuteCambiarEstadoProyecciones(BEArgs args)
        {
            return await this.proyeccionRepository.CambiarEstadoProyecciones(args);
        }

        public async Task<OutResultData<List<BEProyeccion>>> ExecuteGetAllDetalle(BEArgs args)
        {
            return await this.proyeccionRepository.GetAllDetalle(args);
        }

        public async Task<OutResultData<DataSet>> ExecuteImportarProyeccionesDetalle(BEArgs args)
        {
            return await this.proyeccionRepository.ImportarProyeccionesDetalle(args);
        }

        public async Task<OutResultData<DataSet>> ExecuteGuardarProyeccionesDetalle(BEArgs args)
        {
            return await this.proyeccionRepository.GuardarProyeccionesDetalle(args);
        }

        public async Task<OutResultData<BEProyeccion>> ExecuteCambiarEstadoProyeccionesDetalle(BEArgs args)
        {
            return await this.proyeccionRepository.CambiarEstadoProyeccionesDetalle(args);
        }

        public async Task<OutResultData<List<BEProyeccion>>> ExecuteGetAllAjuste(BEArgs args)
        {
            return await this.proyeccionRepository.GetAllAjuste(args);
        }

        public async Task<OutResultData<BEProyeccion>> ExecuteGuardarProyeccionesAjuste(BEArgs args)
        {
            return await this.proyeccionRepository.GuardarProyeccionesAjuste(args);
        }

        public async Task<OutResultData<BEProyeccion>> ExecuteCambiarEstadoProyeccionesAjuste(BEArgs args)
        {
            return await this.proyeccionRepository.CambiarEstadoProyeccionesAjuste(args);
        }

        public async Task<OutResultData<List<BEProyeccion>>> ExecuteGetAllAjusteMovil(BEArgs args)
        {
            return await this.proyeccionRepository.GetAllAjusteMovil(args);
        }
    }
}
