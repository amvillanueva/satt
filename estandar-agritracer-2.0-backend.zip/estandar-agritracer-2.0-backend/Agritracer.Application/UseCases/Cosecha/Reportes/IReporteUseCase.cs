﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using System.Data;
using System.Threading.Tasks;
using Agritracer.Domain.Cosecha.CierreLote.Web;

namespace Agritracer.Application.UseCases.Cosecha.Reportes
{
    public interface IReporteUseCase
    {
        Task<OutResultData<DataSet>> ExecuteRptRankingCosecha(BEArgs args);
        Task<OutResultData<DataTable>> ExecuteRptCruceTareoCosecha(BEArgs args);
        Task<OutResultData<DataTable>> ExecuteRptDetalleCosechador(BEArgs args);
        Task<OutResultData<DataTable>> ExecuteRptCae(BEArgs args);
        Task<OutResultData<DataSet>> ExecuteRptCharlaDiaria(BEArgs args);
        Task<OutResultData<DataSet>> ExecuteRptViajesDespachoCosecha(BEArgs args);

        Task<OutResultData<DataTable>> ExecuteReporteGenericoCosechaDT(BEParams args);
        Task<OutResultData<DataSet>> ExecuteReporteGenericoCosechaDS(BEParams args);

        Task<OutResultData<DataSet>> ExecuteRptTrazabilidadAcopio(BEArgs args);
        Task<OutResultData<DataSet>> ExecuteRptViajesDespacho(BEArgs args);
        Task<OutResultData<DataSet>> ExecuteRptBonificacion(BEArgs args);


        Task<OutResultData<BECierreLote>> ExecuteInsUpdDelCierreLote(BECierreLote cierreLote, int accion);

    }
}
