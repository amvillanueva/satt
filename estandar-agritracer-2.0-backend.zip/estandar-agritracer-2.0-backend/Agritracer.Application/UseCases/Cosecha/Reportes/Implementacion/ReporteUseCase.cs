﻿using System.Threading.Tasks;
using Agritracer.Application.UseCases.Cosecha.Reportes;
using Agritracer.Application.Repositories.Cosecha.Reportes;
using Agritracer.Application.OutputObjets;
using System.Data;
using Agritracer.Domain.Common;
using Agritracer.Domain.Cosecha.CierreLote.Web;

namespace Agritracer.Application.UseCases.Cosecha.Reportes.Implementacion
{
    public class ReporteUseCase : IReporteUseCase
    {
        private readonly IReportesRepository _reporteRepository;

        public ReporteUseCase(IReportesRepository reporteRepository)
        {
            _reporteRepository = reporteRepository;
        }
        public async Task<OutResultData<DataSet>> ExecuteRptRankingCosecha(BEArgs args)
        {
            return await _reporteRepository.RptRankingCosecha(args);
        }
        public async Task<OutResultData<DataTable>> ExecuteRptCruceTareoCosecha(BEArgs args)
        {
            return await _reporteRepository.RptCruceTareoCosecha(args);
        }

        public async Task<OutResultData<DataTable>> ExecuteRptDetalleCosechador(BEArgs args)
        {
            return await _reporteRepository.RptDetalleCosechador(args);
        }

        public async Task<OutResultData<DataTable>> ExecuteRptCae(BEArgs args)
        {
            return await _reporteRepository.RptCae(args);
        }
        public async Task<OutResultData<DataSet>> ExecuteRptCharlaDiaria(BEArgs args)
        {
            return await _reporteRepository.RptCharlaDiaria(args);
        }
        public async Task<OutResultData<DataSet>> ExecuteRptViajesDespachoCosecha(BEArgs args)
        {
            return await _reporteRepository.RptViajesDespachoCosecha(args);
        }

        //-------------------------------------------------------------------------------------------------
        public async Task<OutResultData<DataTable>> ExecuteReporteGenericoCosechaDT(BEParams args)
        {
            return await _reporteRepository.GetReporteGenericoCosechaDT(args);
        }

        public async Task<OutResultData<DataSet>> ExecuteReporteGenericoCosechaDS(BEParams args)
        {
            return await _reporteRepository.GetReporteGenericoCosechaDS(args);
        }

        public async Task<OutResultData<DataSet>> ExecuteRptTrazabilidadAcopio(BEArgs args)
        {
            return await _reporteRepository.RptTrazabilidadAcopio(args);
        }

        public async Task<OutResultData<DataSet>> ExecuteRptViajesDespacho(BEArgs args)
        {
            return await _reporteRepository.RptViajesDespacho(args);
        }

        public async Task<OutResultData<DataSet>> ExecuteRptBonificacion(BEArgs args)
        {
            return await _reporteRepository.RptBonificacion(args);
        }

        public async Task<OutResultData<BECierreLote>> ExecuteInsUpdDelCierreLote(BECierreLote cierreLote, int accion)
        {
            return await _reporteRepository.InsUpdDelCierreLote(cierreLote, accion);
        }

    }
}
