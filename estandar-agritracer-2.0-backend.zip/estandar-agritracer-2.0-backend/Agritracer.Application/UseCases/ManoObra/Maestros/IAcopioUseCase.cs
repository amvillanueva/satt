﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Maestros;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace Agritracer.Application.UseCases.ManoObra.Maestros
{
    public interface IAcopioUseCase
    {
        Task<OutResultData<BEAcopio>> ExecuteGetById(int id);
        Task<OutResultData<List<BEAcopio>>> ExecuteGetAll(BEArgs args);
        Task<OutResultData<BEAcopio>> ExecuteInsUpdDel(BEAcopio acopio, int accion);
        Task<OutResultData<BEAcopio>> ExecuteDeleteAllSelected(BEArgs args);
    }
}
