﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Maestros
{
    public interface IComedorUseCase
    {
        Task<OutResultData<BEComedor>> ExecuteGetById(int id);
        Task<OutResultData<List<BEComedor>>> ExecuteGetAll(BEArgs args);
        Task<OutResultData<BEComedor>> ExecuteInsUpdDel(BEComedor comedor, int accion);
        Task<OutResultData<BEComedor>> ExecuteDeleteAllSelected(BEArgs args);
    }
}
