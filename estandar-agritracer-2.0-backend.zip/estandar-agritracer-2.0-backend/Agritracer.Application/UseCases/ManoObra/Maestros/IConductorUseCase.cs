﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Maestros;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Maestros
{
    public interface IConductorUseCase
    {
        Task<OutResultData<BEConductor>> ExecuteGetById(int id);
        Task<OutResultData<List<BEConductor>>> ExecuteGetAll(BEArgs args);
        Task<OutResultData<BEConductor>> ExecuteInsUpdDel(BEConductor conductor, int accion);
        Task<OutResultData<BEConductor>> ExecuteDeleteAllSelected(BEArgs args);
    }
}
