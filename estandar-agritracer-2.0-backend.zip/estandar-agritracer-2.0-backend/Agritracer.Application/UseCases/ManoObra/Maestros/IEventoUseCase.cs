﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Maestros.Trabajador
{
    public interface IEventoUseCase
    {
        Task<OutResultData<BEEvento>> ExecuteGetById(int id);
        Task<OutResultData<List<BEEvento>>> ExecuteGetAll(BEArgs args);
        Task<OutResultData<BEEvento>> ExecuteInsUpdDel(BEEvento evento, int accion);
    }
}
