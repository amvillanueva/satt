﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Maestros
{
    public interface IGrupoCosechaUseCase
    {
        Task<OutResultData<BEGrupoCosecha>> ExecuteGetById(int id);
        Task<OutResultData<List<BEGrupoCosecha>>> ExecuteGetAll(BEArgs args);
        Task<OutResultData<BEGrupoCosecha>> ExecuteInsUpdDel(BEGrupoCosecha grupoCosecha, int accion);
        Task<OutResultData<BEGrupoCosecha>> ExecuteDeleteAllSelected(BEArgs args);
        Task<OutResultData<BEGrupoCosecha>> ExecuteDeleteTrabajador(BEArgs args);
    }
}
