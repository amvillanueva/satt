﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Maestros;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Data;

namespace Agritracer.Application.UseCases.ManoObra.Maestros
{
    public interface IImpresionFotocheckUseCase
    {
        Task<OutResultData<BEImpresionFotocheck>> ExecuteGetById(int id);
        Task<OutResultData<List<BEImpresionFotocheck>>> ExecuteGetAll(BEArgs args);
        Task<OutResultData<BEImpresionFotocheck>> ExecuteInsUpdDel(BEImpresionFotocheck objeto, int accion);
        Task<OutResultData<BEImpresionFotocheck>> ExecuteDeleteAllSelected(BEArgs args);
        Task<OutResultData<DataSet>> ExecuteImportar(BEArgs args);
        Task<OutResultData<BEImpresionFotocheck>> ExecuteProcesar(BEArgs args);
    }
}
