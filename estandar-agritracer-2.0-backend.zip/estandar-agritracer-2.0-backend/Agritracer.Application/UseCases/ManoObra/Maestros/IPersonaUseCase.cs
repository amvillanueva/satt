﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Maestros.Trabajador
{
    public interface IPersonaUseCase
    {
        Task<OutResultData<BEPersona>> ExecuteGetById(int id);
        Task<OutResultData<List<BEPersona>>> ExecuteGetAll(BEArgs args);
        Task<OutResultData<BEPersona>> ExecuteInsUpdDel(BEPersona persona, int accion);
    }
}
