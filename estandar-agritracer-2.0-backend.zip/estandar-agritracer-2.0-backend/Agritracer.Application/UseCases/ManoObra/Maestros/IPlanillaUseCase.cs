﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Maestros.Trabajador
{
    public interface IPlanillaUseCase
    {
        Task<OutResultData<BEPlanilla>> ExecuteGetById(int id);
        Task<OutResultData<List<BEPlanilla>>> ExecuteGetAll(BEArgs args);
        Task<OutResultData<BEPlanilla>> ExecuteInsUpdDel(BEPlanilla planilla, int accion);
    }
}
