﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Maestros;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Maestros
{
    public interface IVehiculoUseCase
    {
        Task<OutResultData<BEVehiculo>> ExecuteGetById(int id);
        Task<OutResultData<List<BEVehiculo>>> ExecuteGetAll(BEArgs args);
        Task<OutResultData<BEVehiculo>> ExecuteInsUpdDel(BEVehiculo vehiculo, int accion);
        Task<OutResultData<BEVehiculo>> ExecuteDeleteAllSelected(BEArgs args);
    }
}
