﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ManoObra.Maestros;
using Agritracer.Domain.ManoObra.Maestros;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Maestros.Implementacion
{
    public class AcopioUseCase : IAcopioUseCase
    {
        private readonly IAcopioRepository acopioRepository;
        public AcopioUseCase(IAcopioRepository acopioRepository)
        {
            this.acopioRepository = acopioRepository;
        }
        public async Task<OutResultData<BEAcopio>> ExecuteGetById(int id)
        {
            return await this.acopioRepository.GetById(id);
        }
        public async Task<OutResultData<List<BEAcopio>>> ExecuteGetAll(BEArgs args)
        {
            return await this.acopioRepository.GetAll(args);
        }
        public async Task<OutResultData<BEAcopio>> ExecuteInsUpdDel(BEAcopio acopio, int accion)
        {
            return await this.acopioRepository.InsUpdDel(acopio, accion);
        }
        public async Task<OutResultData<BEAcopio>> ExecuteDeleteAllSelected(BEArgs args)
        {
            return await this.acopioRepository.DeleteAllSelected(args);
        }
    }
}
