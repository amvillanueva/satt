﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ManoObra.Maestros;
using Agritracer.Domain.Common;
using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Maestros.Implementacion
{
    public class ComedorUseCase : IComedorUseCase
    {
        private readonly IComedorRepository comedorRepository;
        public ComedorUseCase(IComedorRepository comedorRepository)
        {
            this.comedorRepository = comedorRepository;
        }
        public async Task<OutResultData<BEComedor>> ExecuteGetById(int id)
        {
            return await this.comedorRepository.GetById(id);
        }
        public async Task<OutResultData<List<BEComedor>>> ExecuteGetAll(BEArgs args)
        {
            return await this.comedorRepository.GetAll(args);
        }
        public async Task<OutResultData<BEComedor>> ExecuteInsUpdDel(BEComedor comedor, int accion)
        {
            return await this.comedorRepository.InsUpdDel(comedor, accion);
        }
        public async Task<OutResultData<BEComedor>> ExecuteDeleteAllSelected(BEArgs args)
        {
            return await this.comedorRepository.DeleteAllSelected(args);
        }
    }
}
