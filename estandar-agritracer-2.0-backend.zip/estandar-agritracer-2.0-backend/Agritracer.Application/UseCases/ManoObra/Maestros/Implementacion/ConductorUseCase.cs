﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ManoObra.Maestros;
using Agritracer.Domain.ManoObra.Maestros;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Maestros
{
    public class ConductorUseCase : IConductorUseCase
    {
        private readonly IConductorRepository conductorRepository;
        public ConductorUseCase(IConductorRepository conductorRepository)
        {
            this.conductorRepository = conductorRepository;
        }
        public async Task<OutResultData<BEConductor>> ExecuteGetById(int id)
        {
            return await this.conductorRepository.GetById(id);
        }
        public async Task<OutResultData<List<BEConductor>>> ExecuteGetAll(BEArgs args)
        {
            return await this.conductorRepository.GetAll(args);
        }
        public async Task<OutResultData<BEConductor>> ExecuteInsUpdDel(BEConductor conductor, int accion)
        {
            return await this.conductorRepository.InsUpdDel(conductor, accion);
        }
        public async Task<OutResultData<BEConductor>> ExecuteDeleteAllSelected(BEArgs args)
        {
            return await this.conductorRepository.DeleteAllSelected(args);
        }
    }
}
