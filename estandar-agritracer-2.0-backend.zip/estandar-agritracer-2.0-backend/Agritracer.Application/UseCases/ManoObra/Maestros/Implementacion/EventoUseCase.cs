﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ManoObra.Maestros;
using Agritracer.Application.UseCases.ManoObra.Maestros.Trabajador;
using Agritracer.Domain.Common;
using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Maestros.evento
{
    public class EventoUseCase : IEventoUseCase
    {
        private readonly IEventoRepository eventoRepository;
        public EventoUseCase(IEventoRepository eventoRepository)
        {
            this.eventoRepository = eventoRepository;
        }
        public async Task<OutResultData<BEEvento>> ExecuteGetById(int id)
        {
            return await eventoRepository.GetById(id);
        }
        public async Task<OutResultData<List<BEEvento>>> ExecuteGetAll(BEArgs args)
        {
            return await eventoRepository.GetAll(args);
        }
        public async Task<OutResultData<BEEvento>> ExecuteInsUpdDel(BEEvento evento, int accion)
        {
            return await eventoRepository.InsUpdDel(evento, accion);
        }
    }
}
