﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ManoObra.Maestros;
using Agritracer.Domain.Common;
using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Maestros.Implementacion
{
    public class GrupoCosechaUseCase : IGrupoCosechaUseCase
    {
        private readonly IGrupoCosechaRepository gruopoCosechaRepository;
        public GrupoCosechaUseCase(IGrupoCosechaRepository gruopoCosechaRepository)
        {
            this.gruopoCosechaRepository = gruopoCosechaRepository;
        }
        public async Task<OutResultData<BEGrupoCosecha>> ExecuteGetById(int id)
        {
            return await this.gruopoCosechaRepository.GetById(id);
        }
        public async Task<OutResultData<List<BEGrupoCosecha>>> ExecuteGetAll(BEArgs args)
        {
            return await this.gruopoCosechaRepository.GetAll(args);
        }
        public async Task<OutResultData<BEGrupoCosecha>> ExecuteInsUpdDel(BEGrupoCosecha grupoCosecha, int accion)
        {
            return await this.gruopoCosechaRepository.InsUpdDel(grupoCosecha, accion);
        }
        public async Task<OutResultData<BEGrupoCosecha>> ExecuteDeleteAllSelected(BEArgs args)
        {
            return await this.gruopoCosechaRepository.DeleteAllSelected(args);
        }
        public async Task<OutResultData<BEGrupoCosecha>> ExecuteDeleteTrabajador(BEArgs args)
        {
            return await this.gruopoCosechaRepository.DeleteTrabajador(args);
        }
    }
}
