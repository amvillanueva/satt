﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Maestros;
using Agritracer.Application.Repositories.ManoObra.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;
using Agritracer.Domain.Common;
using System.Data;

namespace Agritracer.Application.UseCases.ManoObra.Maestros.Implementacion
{
    public class ImpresionFotocheckUseCase : IImpresionFotocheckUseCase
    {
        private readonly IImpresionFotocheckRepository impresionFotocheckRepository;

        public ImpresionFotocheckUseCase(IImpresionFotocheckRepository impresionFotocheckRepository)
        {
            this.impresionFotocheckRepository = impresionFotocheckRepository;
        }

        public async Task<OutResultData<BEImpresionFotocheck>> ExecuteGetById(int id)
        {
            return await this.impresionFotocheckRepository.GetById(id);
        }

        public async Task<OutResultData<List<BEImpresionFotocheck>>> ExecuteGetAll(BEArgs args)
        {
            return await this.impresionFotocheckRepository.GetAll(args);
        }

        public async Task<OutResultData<BEImpresionFotocheck>> ExecuteInsUpdDel(BEImpresionFotocheck objeto, int accion)
        {
            return await this.impresionFotocheckRepository.InsUpdDel(objeto, accion);
        }

        public async Task<OutResultData<BEImpresionFotocheck>> ExecuteDeleteAllSelected(BEArgs args)
        {
            return await this.impresionFotocheckRepository.DeleteAllSelected(args);
        }

        public async Task<OutResultData<DataSet>> ExecuteImportar(BEArgs args)
        {
            return await this.impresionFotocheckRepository.Importar(args);
        }

        public async Task<OutResultData<BEImpresionFotocheck>> ExecuteProcesar(BEArgs args)
        {
            return await this.impresionFotocheckRepository.Procesar(args);
        }
    }
}
