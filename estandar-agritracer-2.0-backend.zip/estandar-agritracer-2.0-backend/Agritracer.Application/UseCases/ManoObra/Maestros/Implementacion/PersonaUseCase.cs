﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ManoObra.Maestros;
using Agritracer.Application.UseCases.ManoObra.Maestros.Trabajador;
using Agritracer.Domain.Common;
using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Maestros.evento
{
    public class PersonaUseCase : IPersonaUseCase
    {
        private readonly IPersonaRepository personaRepository;
        public PersonaUseCase(IPersonaRepository personaRepository)
        {
            this.personaRepository = personaRepository;
        }
        public async Task<OutResultData<BEPersona>> ExecuteGetById(int id)
        {
            return await personaRepository.GetById(id);
        }
        public async Task<OutResultData<List<BEPersona>>> ExecuteGetAll(BEArgs args)
        {
            return await personaRepository.GetAll(args);
        }
        public async Task<OutResultData<BEPersona>> ExecuteInsUpdDel(BEPersona persona, int accion)
        {
            return await personaRepository.InsUpdDel(persona, accion);
        }
    }
}
