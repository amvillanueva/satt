﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ManoObra.Maestros;
using Agritracer.Application.UseCases.ManoObra.Maestros.Trabajador;
using Agritracer.Domain.Common;
using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Maestros.evento
{
    public class PlanillaUseCase : IPlanillaUseCase
    {
        private readonly IPlanillaRepository planillaRepository;
        public PlanillaUseCase(IPlanillaRepository planillaRepository)
        {
            this.planillaRepository = planillaRepository;
        }
        public async Task<OutResultData<BEPlanilla>> ExecuteGetById(int id)
        {
            return await planillaRepository.GetById(id);
        }
        public async Task<OutResultData<List<BEPlanilla>>> ExecuteGetAll(BEArgs args)
        {
            return await planillaRepository.GetAll(args);
        }
        public async Task<OutResultData<BEPlanilla>> ExecuteInsUpdDel(BEPlanilla planilla, int accion)
        {
            return await planillaRepository.InsUpdDel(planilla, accion);
        }
    }
}
