﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ManoObra.Maestros;
using Agritracer.Application.UseCases.ManoObra.Maestros;
using Agritracer.Domain.ManoObra.Maestros;
using Agritracer.Domain.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Cosecha.Maestros
{
    public class VehiculoUseCase : IVehiculoUseCase
    {
        private readonly IVehiculoRepository vehiculRepository;
        public VehiculoUseCase(IVehiculoRepository vehiculRepository)
        {
            this.vehiculRepository = vehiculRepository;
        }
        public async Task<OutResultData<BEVehiculo>> ExecuteGetById(int id)
        {
            return await this.vehiculRepository.GetById(id);
        }
        public async Task<OutResultData<List<BEVehiculo>>> ExecuteGetAll(BEArgs args)
        {
            return await this.vehiculRepository.GetAll(args);
        }
        public async Task<OutResultData<BEVehiculo>> ExecuteInsUpdDel(BEVehiculo vehiculo, int accion)
        {
            return await this.vehiculRepository.InsUpdDel(vehiculo, accion);
        }
        public async Task<OutResultData<BEVehiculo>> ExecuteDeleteAllSelected(BEArgs args)
        {
            return await this.vehiculRepository.DeleteAllSelected(args);
        }

    }
}
