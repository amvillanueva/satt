﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Maestros.Movil;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Maestros.Movil
{
    public interface IObtenerDataMestraUseCase
    {
        Task<OutResultData<BEDataMaestra>> Execute(int empresaID, int usuarioId, int supervisorId);
        Task<OutResultData<BEDataMaestraTPacking>> TareoPackingExecute(int empresaID, int usuarioId, int supervisorId);
        Task<OutResultData<BEDataMaestraComedor>> ComedorExecute(int empresaId, int usuarioId, int acopioId);
    }

}
