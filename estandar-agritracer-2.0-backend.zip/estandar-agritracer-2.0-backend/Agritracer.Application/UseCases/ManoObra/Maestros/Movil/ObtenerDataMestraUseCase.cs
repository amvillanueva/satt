﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ManoObra.Maestros.Movil;
using Agritracer.Domain.ManoObra.Maestros.Movil;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Maestros.Movil
{
    class ObtenerDataMestraUseCase : IObtenerDataMestraUseCase
    {
        private readonly IDataMaestraReadWriteRepository _dataMaestraReadWriteRepository;

        public ObtenerDataMestraUseCase(IDataMaestraReadWriteRepository dataMaestraReadWriteRepository)
        {
            _dataMaestraReadWriteRepository = dataMaestraReadWriteRepository;
        }

        public async Task<OutResultData<BEDataMaestra>> Execute(int empresaID, int usuarioID, int supervisorId)
        {
            return await _dataMaestraReadWriteRepository.GetBy(empresaID, usuarioID, supervisorId);
        }

        public async Task<OutResultData<BEDataMaestraTPacking>> TareoPackingExecute(int empresaID, int usuarioId, int supervisorId)
        {
            return await _dataMaestraReadWriteRepository.TareoPackingGetBy(empresaID, usuarioId, supervisorId);
        }

        public async Task<OutResultData<BEDataMaestraComedor>> ComedorExecute(int empresaID, int usuarioId, int acopioId)
        {
            return await _dataMaestraReadWriteRepository.ComedorGetBy(empresaID, usuarioId, acopioId);
        }
    }

}
