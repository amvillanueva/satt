﻿
using System.Data;
using System.Threading.Tasks;

using Agritracer.Domain.Common;
using Agritracer.Domain.ManoObra.Maestros;
using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ManoObra.Maestros;

namespace Agritracer.Application.UseCases.ManoObra.Maestros.Web.ConfigBono
{
    public class ConfigBonoUseCase : IConfigBonoUseCase
    {
        private readonly IConfigBonoRepository configBonoRepository;

        public ConfigBonoUseCase(IConfigBonoRepository _configBonoRepository)
        {
            configBonoRepository = _configBonoRepository;
        }

        public async Task<OutResultData<DataTable>> ExecuteGetAll(BEParams args)
        {
            return await configBonoRepository.GetAll(args);
        }

        public async Task<OutResultData<BEConfigBono>> ExecuteInsUpd(BEConfigBono entity)
        {
            return await configBonoRepository.InsUpd(entity);
        }
    }
}
