﻿using System.Data;
using System.Threading.Tasks;

using Agritracer.Domain.Common;
using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Maestros;

namespace Agritracer.Application.UseCases.ManoObra.Maestros.Web.ConfigBono
{
    public interface IConfigBonoUseCase
    {
        Task<OutResultData<DataTable>> ExecuteGetAll(BEParams args);
        Task<OutResultData<BEConfigBono>> ExecuteInsUpd(BEConfigBono entity);
    }
}
