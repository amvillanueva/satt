﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using System.Threading.Tasks;
using System.Data;
using Agritracer.Domain.ManoObra.Maestros;

namespace Agritracer.Application.UseCases.ManoObra.Maestros.Web.RestriccionTrabajador
{
    public interface IRestriccionTrabajadorUsecase
    {
        Task<OutResultData<DataTable>> ObtenerListadoRestriccionesExec(BEArgs args);
        Task<OutResultData<BERestriccionTrabajador>> ExecuteInsUpdDel(BERestriccionTrabajador restriccion, int accion);
        Task<OutResultData<BEArgs>> ExecuteActionAllSelected(BEArgs args, int action);
    }
}
