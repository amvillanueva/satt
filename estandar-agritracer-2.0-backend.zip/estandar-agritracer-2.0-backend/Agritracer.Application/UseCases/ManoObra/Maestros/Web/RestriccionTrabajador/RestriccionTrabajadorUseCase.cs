﻿using System.Data;
using System.Threading.Tasks;
using Agritracer.Domain.Common;
using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ManoObra.Maestros;
using Agritracer.Domain.ManoObra.Maestros;

namespace Agritracer.Application.UseCases.ManoObra.Maestros.Web.RestriccionTrabajador
{
    public class RestriccionTrabajadorUseCase : IRestriccionTrabajadorUsecase
    {
        private readonly IRestriccionTrabajadorRepository _restriccionTrabajadorRepository;

        public RestriccionTrabajadorUseCase(IRestriccionTrabajadorRepository restriccionTrabajadorRepository)
        {
            _restriccionTrabajadorRepository = restriccionTrabajadorRepository;
        }

        //---------------------------------------

        public async Task<OutResultData<DataTable>> ObtenerListadoRestriccionesExec(BEArgs args)
        {
            return await _restriccionTrabajadorRepository.GetListadoRestricciones(args);
        }

        public async Task<OutResultData<BERestriccionTrabajador>> ExecuteInsUpdDel(BERestriccionTrabajador restriccion, int accion)
        {
            return await this._restriccionTrabajadorRepository.InsUpdDel(restriccion, accion);
        }
        public async Task<OutResultData<BEArgs>> ExecuteActionAllSelected(BEArgs args, int action)
        {
            return await this._restriccionTrabajadorRepository.ActionAllSelected(args, action);
        }
    }
}
