﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ManoObra.Procesos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Procesos.Common
{
    public class CommonUseCase : ICommonUseCase
    {
        private readonly ICommonRepository _commonRepository;

        public CommonUseCase(ICommonRepository commonRepository)
        {
            _commonRepository = commonRepository;
        }

        public async Task<OutResultData<Dictionary<string, object>>> ObtenerGrupoByCodigoExecute(string codigo)
        {
            return await _commonRepository.GetGrupoByCodigo(codigo);
        }

        public async Task<OutResultData<Dictionary<string, object>>> ObtenerGrupoByLegajoExecute(string legajo)
        {
            return await _commonRepository.GetGrupoByLegajo(legajo);
        }

        public async Task<OutResultData<Dictionary<string, object>>> ObtenerSupervisorByLegajoExecute(string legajo)
        {
            return await _commonRepository.GetSupervisorByLegajo(legajo);
        }
    }
}
