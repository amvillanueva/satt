﻿using Agritracer.Application.OutputObjets;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Procesos.Common
{
    public interface ICommonUseCase
    {
        Task<OutResultData<Dictionary<string, object>>> ObtenerGrupoByLegajoExecute(string legajo);
        Task<OutResultData<Dictionary<string, object>>> ObtenerGrupoByCodigoExecute(string codigo);
        Task<OutResultData<Dictionary<string, object>>> ObtenerSupervisorByLegajoExecute(string legajo);
    }

}
