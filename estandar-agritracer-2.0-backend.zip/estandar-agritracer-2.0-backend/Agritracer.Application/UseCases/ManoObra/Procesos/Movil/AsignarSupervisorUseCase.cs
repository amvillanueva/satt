﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ManoObra.Procesos.Movil;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Procesos.Movil
{
    public class AsignarSupervisorUseCase : IAsignarSupervisorUseCase
    {
        private readonly IAsignarSupervisorRepository _AsignacionSupervisorRepository;

        public AsignarSupervisorUseCase(IAsignarSupervisorRepository oAsignarSupervisorRepository)
        {
            _AsignacionSupervisorRepository = oAsignarSupervisorRepository;
        }

        public async Task<OutResultData<string>> EliminarAsignacionExecute(int grupoTrabajoId, int supervisorId, string supervisorCodigo, int userId, string imei)
        {
            return await _AsignacionSupervisorRepository.EliminarAsignacion(grupoTrabajoId, supervisorId, supervisorCodigo, userId, imei);
        }

        public async Task<OutResultData<string>> RegistrarAsignacionExecute(int supervisorId, string supervisorCodigo, int grupoTrabajoId, string equipos, int userId, string imei)
        {
            return await _AsignacionSupervisorRepository.RegistrarAsignacion(supervisorId, supervisorCodigo, grupoTrabajoId, equipos, userId, imei);
        }

    }

}
