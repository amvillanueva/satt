﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ManoObra.Procesos.Movil;
using Agritracer.Domain.ManoObra.Procesos.Movil;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Agritracer.Application.UseCases.ManoObra.Procesos.Movil
{
    public class CierreLoteUseCase: ICierreLoteUseCase
    {
        private readonly ICierreLoteRespository _CierreLoteRepository;

        public CierreLoteUseCase(ICierreLoteRespository oCierreLoteRepository)
        {
            _CierreLoteRepository = oCierreLoteRepository;
        }

        public async Task<OutResultData<string>> RegistroProductividadSurcosExecute(List<BEProductividadLotePlanilla> listaProductivdad)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(listaProductivdad.GetType());

            StringWriter textWriter = new StringWriter();
            xmlSerializer.Serialize(textWriter, listaProductivdad);

            StringReader transactionXml = new StringReader(textWriter.ToString());
            XmlTextReader xmlReader = new XmlTextReader(transactionXml);
            SqlXml productividadXML = new SqlXml(xmlReader);

            return await _CierreLoteRepository.RegistroProductividadSurcos(productividadXML);
        }

    }
}
