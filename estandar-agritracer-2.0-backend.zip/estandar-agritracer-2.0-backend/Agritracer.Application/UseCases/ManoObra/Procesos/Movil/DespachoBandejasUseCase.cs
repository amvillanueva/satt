﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ManoObra.Procesos.Movil;
using Agritracer.Domain.ManoObra.Procesos.Movil;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.IO;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Agritracer.Application.UseCases.ManoObra.Procesos.Movil
{
    public class DespachoBandejasUseCase : IDespachoBandejasUseCase
    {
        private readonly IDespachoBandejasRepository _despachoBandejasRepository;

        public DespachoBandejasUseCase(IDespachoBandejasRepository despachoBandejasRepository)
        {
            _despachoBandejasRepository = despachoBandejasRepository;
        }

        public async Task<OutResultData<BEDespachoBandejasDetalle>> obtenerBandejaDespachoExecute(string codBandeja, int acopioID)
        {
            var rpta = await _despachoBandejasRepository.obtenerBandejaDespacho(codBandeja,acopioID);

            if (rpta.statusCode <= 0)
                throw new ApplicationException(rpta.message);
            else
                return rpta;
        }
        
        public async Task<OutResultData<string>> registrarDespachoBandejasExecute(List<BEDespachoBandejas> listaDespachos)
        {
            try
            {
                foreach (BEDespachoBandejas item in listaDespachos) {
                    foreach (BEDespachoBandejasDetalle detalle in item.despachoBandejas) {
                        detalle.despachoID = item.despachoID;
                    }
                }

                XmlSerializer xmlSerializer = new XmlSerializer(listaDespachos.GetType());

                StringWriter textWriter = new StringWriter();
                xmlSerializer.Serialize(textWriter, listaDespachos);

                StringReader transactionXml = new StringReader(textWriter.ToString());
                XmlTextReader xmlReader = new XmlTextReader(transactionXml);
                SqlXml despachosXML = new SqlXml(xmlReader);

                var rpta = await _despachoBandejasRepository.registrarDespachoBandejas(despachosXML);

                if (rpta.statusCode <= 0)
                    throw new ApplicationException(rpta.message);
                else
                    return rpta;

            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

    }
}
