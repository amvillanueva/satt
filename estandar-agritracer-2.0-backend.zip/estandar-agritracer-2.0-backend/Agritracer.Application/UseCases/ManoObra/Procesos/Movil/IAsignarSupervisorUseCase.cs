﻿using Agritracer.Application.OutputObjets;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Procesos.Movil
{
    public interface IAsignarSupervisorUseCase
    {
        Task<OutResultData<string>> RegistrarAsignacionExecute(int supervisorId, string supervisorCodigo, int grupoTrabajoId, string equipos, int userId, string imei);
        Task<OutResultData<string>> EliminarAsignacionExecute(int grupoTrabajoId, int supervisorId, string supervisorCodigo, int userId, string imei);
    }

}
