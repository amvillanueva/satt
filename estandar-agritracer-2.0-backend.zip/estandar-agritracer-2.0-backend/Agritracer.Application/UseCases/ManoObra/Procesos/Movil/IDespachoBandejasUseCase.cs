﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Procesos.Movil;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Procesos.Movil
{
    public interface IDespachoBandejasUseCase
    {
        Task<OutResultData<BEDespachoBandejasDetalle>> obtenerBandejaDespachoExecute(string codBandeja, int acopioID);
        Task<OutResultData<string>> registrarDespachoBandejasExecute(List<BEDespachoBandejas> listaDespachos);
    }
}