﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Procesos.Movil;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Procesos.Movil
{
    public interface IProductividadUseCase
    {
        Task<OutResultData<string>> RegistrarProductividadTrabajadoresExecute(List<BEProductividadTrabajador> productividades);
    }
}
