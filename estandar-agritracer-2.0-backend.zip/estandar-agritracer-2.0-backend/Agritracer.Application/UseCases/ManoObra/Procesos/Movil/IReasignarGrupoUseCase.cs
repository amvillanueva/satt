﻿using Agritracer.Application.OutputObjets;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Procesos.Movil
{
    public interface IReasignarGrupoUseCase
    {
        Task<OutResultData<string>> RegistrarReAsignacionExecute(int grupoTrabajoAntiguoId, int grupoTrabajoActualId, int trabajadorId, int tipoCambio, string username, string imei);
        Task<OutResultData<string>> EliminarReAsignacionExecute(int grupoTrabajoId, int trabajadorId, string username, string imei);
    }

}
