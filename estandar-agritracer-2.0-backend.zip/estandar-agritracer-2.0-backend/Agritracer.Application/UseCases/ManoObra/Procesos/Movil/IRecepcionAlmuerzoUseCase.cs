﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Procesos.Movil;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Procesos.Movil
{
    public interface IRecepcionAlmuerzoUseCase
    {
        Task<OutResultData<List<BERecepcionAlmuerzo>>> obtenerSolicitudAlmuerzoDNIExecute(string dni, int acopioID, int empresaId);
        Task<OutResultData<DataTable>> obtenerResumenRecepcionExecute(int usuarioId, int acopioID);
        Task<OutResultData<DataTable>> obtenerDetalleRecepcionExecute(int usuarioId, int acopioID);
        Task<OutResultData<string>> registrarCierreRecepcionExecute(int usuarioId, int acopioID, int empresaId);
        Task<OutResultData<string>> registrarRecepcionAlmuerzoExecute(List<BERecepcionAlmuerzo> listaRecepciones);
        Task<OutResultData<string>> registrarRechazoAlmuerzoExecute(List<BERechazoAlmuerzo> listaRechazos);
        Task<OutResultData<string>> registrarEmpaqueRecepcionExecute(List<BERecepcionAlmuerzo> listaRecepciones);
    }
}