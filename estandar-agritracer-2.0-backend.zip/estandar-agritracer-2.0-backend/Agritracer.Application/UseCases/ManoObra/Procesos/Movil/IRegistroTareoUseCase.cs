﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Procesos.Movil;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Procesos.Movil
{
    public interface IRegistroTareoUseCase
    {
        Task<OutResultData<string>> RegistrarTareoCampoExecute(List<BEPlanillaTareoMovil> planillas);
        Task<OutResultData<string>> RegistrarTareoCampo2Execute(List<BEPlanillaTareoMovil> planillas);
        Task<OutResultData<string>> RegistrarTareoPackingExecute(List<BEPlanillaPackingMovil> planillas);
    }

}
