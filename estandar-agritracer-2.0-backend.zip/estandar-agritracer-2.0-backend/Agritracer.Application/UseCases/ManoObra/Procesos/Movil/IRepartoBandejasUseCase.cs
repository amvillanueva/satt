﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Procesos.Movil;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Procesos.Movil
{
    public interface IRepartoBandejasUseCase
    {
        Task<OutResultData<BERepartoAsignado>> obtenerDespachoExecute(int usuarioID);
        Task<OutResultData<Dictionary<string, object>>> consultarLegajoExecute(string legajo);
        Task<OutResultData<string>> registrarRepartoExecute(List<BERegistroEntrega> listaRepartos);
        Task<OutResultData<Dictionary<string, object>>> consultarResumenExecute(int usuarioID);
        Task<OutResultData<string>> cierreRepartoExecute(int usuarioID);
    }
}