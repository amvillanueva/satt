﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Maestros.Movil;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Procesos.Movil
{
    public interface IRestriccionesUseCase
    {
        Task<OutResultData<List<BEAsistenciaPlanilla>>> validarRestricionesTrabajadoresPlanillaExecute(List<BEAsistenciaPlanilla> asistenciaPlanillas, int tipoTareo);
    }

}
