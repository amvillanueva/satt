﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Maestros;
using Agritracer.Domain.ManoObra.Procesos.Movil;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Procesos.Movil
{
    public interface ISepararComedorUseCase
    {
        Task<OutResultData<List<BETrabajadorGrupo>>> obtenerDetalleTrabajadoresExecute(int grupoID, int supervisorID);
        Task<OutResultData<List<BETrabajadorGrupo>>> obtenerDetalleTrabajadoresExecute(BESolicitudComedorLab padronGrupo);
        Task<OutResultData<List<BEComedor>>> obtenerComedoresDisponiblesExecute(int zonaID, int moduloID, int grupoID, int supervisorID);
        Task<OutResultData<string>> registrarPadronComedorExecute(List<BEPadronComedor> padronComedor);
    }
}