﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Maestros;
using Agritracer.Domain.ManoObra.Procesos.Movil;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Procesos.Movil
{
    public interface ITrackingComedorUseCase
    {
        Task<OutResultData<List<BEPadronComedor>>> obtenerPadronGrupoExecute(int grupoID);
        Task<OutResultData<string>> solicitarAlmuerzoEmergenciaExecute(List<BEPadronComedor> padronComedor);
        Task<OutResultData<string>> registrarRecepcionAlmuerzoExecute(List<BERecepcionComedor> padronComedor);
    }
}