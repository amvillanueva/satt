﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ManoObra.Procesos.Movil;
using Agritracer.Domain.ManoObra.Procesos.Movil;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Agritracer.Application.UseCases.ManoObra.Procesos.Movil
{
    public class ProductividadUseCase : IProductividadUseCase
    {
        private readonly IProductividadRespository _ProductividadRespository;

        public ProductividadUseCase(IProductividadRespository oProductividadRespository)
        {
            _ProductividadRespository = oProductividadRespository;
        }

        public async Task<OutResultData<string>> RegistrarProductividadTrabajadoresExecute(List<BEProductividadTrabajador> productividades)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(productividades.GetType());

            StringWriter textWriter = new StringWriter();
            xmlSerializer.Serialize(textWriter, productividades);

            StringReader transactionXml = new StringReader(textWriter.ToString());
            XmlTextReader xmlReader = new XmlTextReader(transactionXml);
            SqlXml productividadesXML = new SqlXml(xmlReader);

            return await _ProductividadRespository.RegistrarProductividadTrabajadores(productividadesXML);
        }
    }
}
