﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ManoObra.Procesos.Movil;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Procesos.Movil
{
    public class ReasignarGrupoUseCase : IReasignarGrupoUseCase
    {
        private readonly IReasignarGrupoRepository _ReasignarGrupoRepository;

        public ReasignarGrupoUseCase(IReasignarGrupoRepository oReasignarGrupoRepository)
        {
            _ReasignarGrupoRepository = oReasignarGrupoRepository;
        }

        public async Task<OutResultData<string>> EliminarReAsignacionExecute(int grupoTrabajoId, int trabajadorId, string username, string imei)
        {
            return await _ReasignarGrupoRepository.EliminarReAsignacion(grupoTrabajoId, trabajadorId, username, imei);
        }

        public async Task<OutResultData<string>> RegistrarReAsignacionExecute(int grupoTrabajoAntiguoId, int grupoTrabajoActualId, int trabajadorId, int tipoCambio, string username, string imei)
        {
            return await _ReasignarGrupoRepository.RegistrarReAsignacion(grupoTrabajoAntiguoId, grupoTrabajoActualId, trabajadorId, tipoCambio, username, imei);
        }
    }

}
