﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ManoObra.Procesos.Movil;
using Agritracer.Domain.ManoObra.Procesos.Movil;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Agritracer.Application.UseCases.ManoObra.Procesos.Movil
{
    public class RecepcionAlmuerzoUseCase : IRecepcionAlmuerzoUseCase
    {
        private readonly IRecepcionAlmuerzoRepository _recepcionAlmuerzoRepository;

        public RecepcionAlmuerzoUseCase(IRecepcionAlmuerzoRepository recepcionAlmuerzoRepository)
        {
            _recepcionAlmuerzoRepository = recepcionAlmuerzoRepository;
        }

        public async Task<OutResultData<List<BERecepcionAlmuerzo>>> obtenerSolicitudAlmuerzoDNIExecute(string dni, int acopioID, int empresaId)
        {
            var rpta = await _recepcionAlmuerzoRepository.obtenerSolicitudAlmuerzoDNI(dni, acopioID, empresaId);

            if (rpta.statusCode <= 0)
                throw new ApplicationException(rpta.message);
            else
                return rpta;
        }

        public async Task<OutResultData<DataTable>> obtenerResumenRecepcionExecute(int usuarioId, int acopioID)
        {
            var rpta = await _recepcionAlmuerzoRepository.obtenerResumenRecepcion(usuarioId, acopioID);

            if (rpta.statusCode <= 0)
                throw new ApplicationException(rpta.message);
            else
                return rpta;
        }

        public async Task<OutResultData<DataTable>> obtenerDetalleRecepcionExecute(int usuarioId, int acopioID)
        {
            var rpta = await _recepcionAlmuerzoRepository.obtenerDetalleRecepcion(usuarioId, acopioID);

            if (rpta.statusCode <= 0)
                throw new ApplicationException(rpta.message);
            else
                return rpta;
        }

        public async Task<OutResultData<string>> registrarRecepcionAlmuerzoExecute(List<BERecepcionAlmuerzo> listaRecepciones)
        {
            try
            {
                string xml = "";
                var xEle = new XElement("r", from itemRecepcion in listaRecepciones
                                             select new XElement("detalles",
                                                 new XAttribute("recepcionID", itemRecepcion.recepcionID),
                                                 new XAttribute("padronComedorID", itemRecepcion.padronComedorID),
                                                 new XAttribute("padronComedorFecha", itemRecepcion.padronComedorFecha),
                                                 new XAttribute("padronComedorTrabajadorID", itemRecepcion.padronComedorTrabajadorID),
                                                 new XAttribute("padronComedorTrabajadorCod", itemRecepcion.padronComedorTrabajadorCod),
                                                 new XAttribute("padronComedorTrabajadorDNI", itemRecepcion.padronComedorTrabajadorDNI),
                                                 new XAttribute("padronComedorTrabajadorNombre", itemRecepcion.padronComedorTrabajadorNombre),
                                                 new XAttribute("padronComedorGrupoID", itemRecepcion.padronComedorGrupoID),
                                                 new XAttribute("padronComedorGrupoCod", itemRecepcion.padronComedorGrupoCod),
                                                 new XAttribute("padronComedorComedorID", itemRecepcion.padronComedorComedorID),
                                                 new XAttribute("padronComedorComedorNombre", itemRecepcion.padronComedorComedorNombre),
                                                 new XAttribute("padronComedorModuloNombre", itemRecepcion.padronComedorModuloNombre),
                                                 new XAttribute("padronComedorEmpresaID", itemRecepcion.padronComedorEmpresaID),
                                                 new XAttribute("padronComedorEmpresaNombre", itemRecepcion.padronComedorEmpresaNombre),
                                                 new XAttribute("padronComedorSupervisorID", itemRecepcion.padronComedorSupervisorID),
                                                 new XAttribute("recepcionFecha", itemRecepcion.recepcionFecha),
                                                 new XAttribute("recepcionManual", itemRecepcion.recepcionManual),
                                                 new XAttribute("recepcionAcopioID", itemRecepcion.recepcionAcopioID),
                                                 new XAttribute("recepcionUsuarioID", itemRecepcion.recepcionUsuarioID),
                                                 new XAttribute("recepcionUsuarioIMEI", itemRecepcion.recepcionUsuarioIMEI),
                                                 new XAttribute("recepcionEnviada", itemRecepcion.recepcionEnviada),
                                                 new XAttribute("recepcionEmpacada", itemRecepcion.recepcionEmpacada),
                                                 new XAttribute("recepcionEmpaqueCodigo", itemRecepcion.recepcionEmpaqueCodigo),
                                                 new XAttribute("recepcionEmpaqueEnviado", itemRecepcion.recepcionEmpaqueEnviado)));

                xml = Convert.ToString(xEle);

                var rpta = await _recepcionAlmuerzoRepository.registrarRecepcionAlmuerzo(xml);

                if (rpta.statusCode <= 0)
                    throw new ApplicationException(rpta.message);
                else
                    return rpta;

            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public async Task<OutResultData<string>> registrarCierreRecepcionExecute(int usuarioId, int acopioID, int empresaId)
        {
            var rpta = await _recepcionAlmuerzoRepository.registrarCierreRecepcion(usuarioId, acopioID, empresaId);

            if (rpta.statusCode <= 0)
                throw new ApplicationException(rpta.message);
            else
                return rpta;
        }

        public async Task<OutResultData<string>> registrarRechazoAlmuerzoExecute(List<BERechazoAlmuerzo> listaRechazos)
        {
            try
            {
                string xml = "";
                var xEle = new XElement("r", from itemRechazo in listaRechazos
                                             select new XElement("detalles",
                                                 new XAttribute("rechazoID", itemRechazo.rechazoID),
                                                 new XAttribute("rechazoTrabajadorID", itemRechazo.rechazoTrabajadorID),
                                                 new XAttribute("rechazoTrabajadorCod", itemRechazo.rechazoTrabajadorCod),
                                                 new XAttribute("rechazoTrabajadorDNI", itemRechazo.rechazoTrabajadorDNI),
                                                 new XAttribute("rechazoTrabajadorNombre", itemRechazo.rechazoTrabajadorNombre),
                                                 new XAttribute("rechazoMotivo", itemRechazo.rechazoMotivo),
                                                 new XAttribute("rechazoFecha", itemRechazo.rechazoFecha),
                                                 new XAttribute("rechazoAcopioID", itemRechazo.rechazoAcopioID),
                                                 new XAttribute("rechazoUsuarioID", itemRechazo.rechazoUsuarioID),
                                                 new XAttribute("rechazoEmpresaID", itemRechazo.rechazoEmpresaID),
                                                 new XAttribute("rechazoIMEI", itemRechazo.rechazoIMEI),
                                                 new XAttribute("rechazoEnviado", itemRechazo.rechazoEnviado)));

                xml = Convert.ToString(xEle);

                var rpta = await _recepcionAlmuerzoRepository.registrarRechazoAlmuerzo(xml);

                if (rpta.statusCode <= 0)
                    throw new ApplicationException(rpta.message);
                else
                    return rpta;

            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public async Task<OutResultData<string>> registrarEmpaqueRecepcionExecute(List<BERecepcionAlmuerzo> listaRecepciones)
        {
            try
            {
                string xml = "";
                var xEle = new XElement("r", from itemRecepcion in listaRecepciones
                                             select new XElement("detalles",
                                                 new XAttribute("recepcionID", itemRecepcion.recepcionID),
                                                 new XAttribute("padronComedorID", itemRecepcion.padronComedorID),
                                                 new XAttribute("padronComedorFecha", itemRecepcion.padronComedorFecha),
                                                 new XAttribute("padronComedorTrabajadorID", itemRecepcion.padronComedorTrabajadorID),
                                                 new XAttribute("padronComedorTrabajadorCod", itemRecepcion.padronComedorTrabajadorCod),
                                                 new XAttribute("padronComedorTrabajadorDNI", itemRecepcion.padronComedorTrabajadorDNI),
                                                 new XAttribute("padronComedorTrabajadorNombre", itemRecepcion.padronComedorTrabajadorNombre),
                                                 new XAttribute("padronComedorGrupoID", itemRecepcion.padronComedorGrupoID),
                                                 new XAttribute("padronComedorGrupoCod", itemRecepcion.padronComedorGrupoCod),
                                                 new XAttribute("padronComedorComedorID", itemRecepcion.padronComedorComedorID),
                                                 new XAttribute("padronComedorComedorNombre", itemRecepcion.padronComedorComedorNombre),
                                                 new XAttribute("padronComedorModuloNombre", itemRecepcion.padronComedorModuloNombre),
                                                 new XAttribute("padronComedorEmpresaID", itemRecepcion.padronComedorEmpresaID),
                                                 new XAttribute("padronComedorEmpresaNombre", itemRecepcion.padronComedorEmpresaNombre),
                                                 new XAttribute("padronComedorSupervisorID", itemRecepcion.padronComedorSupervisorID),
                                                 new XAttribute("recepcionFecha", itemRecepcion.recepcionFecha),
                                                 new XAttribute("recepcionManual", itemRecepcion.recepcionManual),
                                                 new XAttribute("recepcionAcopioID", itemRecepcion.recepcionAcopioID),
                                                 new XAttribute("recepcionUsuarioID", itemRecepcion.recepcionUsuarioID),
                                                 new XAttribute("recepcionUsuarioIMEI", itemRecepcion.recepcionUsuarioIMEI),
                                                 new XAttribute("recepcionEnviada", itemRecepcion.recepcionEnviada),
                                                 new XAttribute("recepcionEmpacada", itemRecepcion.recepcionEmpacada),
                                                 new XAttribute("recepcionEmpaqueCodigo", itemRecepcion.recepcionEmpaqueCodigo),
                                                 new XAttribute("recepcionEmpaqueEnviado", itemRecepcion.recepcionEmpaqueEnviado)));

                xml = Convert.ToString(xEle);

                var rpta = await _recepcionAlmuerzoRepository.registrarEmpaqueRecepcion(xml);

                if (rpta.statusCode <= 0)
                    throw new ApplicationException(rpta.message);
                else
                    return rpta;

            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }
    }
}
