﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ManoObra.Procesos.Movil;
using Agritracer.Domain.ManoObra.Procesos.Movil;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Agritracer.Application.UseCases.ManoObra.Procesos.Movil
{
    public class RegistroComensalUseCase : IRegistroComensalUseCase
    {
        private readonly IRegistroComensalRepository _RegistroComensalRepository;

        public RegistroComensalUseCase(IRegistroComensalRepository oRegistroComensalRepository)
        {
            _RegistroComensalRepository = oRegistroComensalRepository;
        }

        public async Task<OutResultData<String>> RegistrarSeparacionExecute(List<BEComensal> comensales)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(comensales.GetType());

            StringWriter textWriter = new StringWriter();
            xmlSerializer.Serialize(textWriter, comensales);

            StringReader transactionXml = new StringReader(textWriter.ToString());
            XmlTextReader xmlReader = new XmlTextReader(transactionXml);
            SqlXml comensalesXML = new SqlXml(xmlReader);

            return await _RegistroComensalRepository.RegistrarSeparacion(comensalesXML);
        }

    }

}