﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ManoObra.Procesos.Movil;
using Agritracer.Domain.ManoObra.Procesos.Movil;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.IO;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Agritracer.Application.UseCases.ManoObra.Procesos.Movil
{
    public class RegistroTareoUseCase: IRegistroTareoUseCase
    {
        private readonly IRegistroTareoRespository _RegistroTareoRespository;

        public RegistroTareoUseCase(IRegistroTareoRespository oRegistroTareoRespository)
        {
            _RegistroTareoRespository = oRegistroTareoRespository;
        }

        public async Task<OutResultData<string>> RegistrarTareoCampoExecute(List<BEPlanillaTareoMovil> planillas)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(planillas.GetType());

            StringWriter textWriter = new StringWriter();
            xmlSerializer.Serialize(textWriter, planillas);

            StringReader transactionXml = new StringReader(textWriter.ToString());
            XmlTextReader xmlReader = new XmlTextReader(transactionXml);
            SqlXml planillasXML = new SqlXml(xmlReader);

            return await _RegistroTareoRespository.RegistrarTareo(planillasXML, 1);
        }

        public async Task<OutResultData<string>> RegistrarTareoCampo2Execute(List<BEPlanillaTareoMovil> planillas)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(planillas.GetType());

            StringWriter textWriter = new StringWriter();
            xmlSerializer.Serialize(textWriter, planillas);

            StringReader transactionXml = new StringReader(textWriter.ToString());
            XmlTextReader xmlReader = new XmlTextReader(transactionXml);
            SqlXml planillasXML = new SqlXml(xmlReader);

            return await _RegistroTareoRespository.RegistrarTareo2(planillasXML, 1);
        }

        public async Task<OutResultData<string>> RegistrarTareoPackingExecute(List<BEPlanillaPackingMovil> planillas)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(planillas.GetType());

            StringWriter textWriter = new StringWriter();
            xmlSerializer.Serialize(textWriter, planillas);

            StringReader transactionXml = new StringReader(textWriter.ToString());
            XmlTextReader xmlReader = new XmlTextReader(transactionXml);
            SqlXml planillasXML = new SqlXml(xmlReader);

            return await _RegistroTareoRespository.RegistrarTareo(planillasXML, 2);
        }

    }

}