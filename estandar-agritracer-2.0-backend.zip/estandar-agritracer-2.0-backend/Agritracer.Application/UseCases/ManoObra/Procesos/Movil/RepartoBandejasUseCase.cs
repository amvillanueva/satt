﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ManoObra.Procesos.Movil;
using Agritracer.Domain.ManoObra.Procesos.Movil;
using System;
using System.IO;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Agritracer.Application.UseCases.ManoObra.Procesos.Movil
{
    public class RepartoBandejasUseCase : IRepartoBandejasUseCase
    {
        private readonly IRepartoBandejasRepository _repartoBandejasRepository;

        public RepartoBandejasUseCase(IRepartoBandejasRepository repartoBandejasRepository)
        {
            _repartoBandejasRepository = repartoBandejasRepository;
        }

        public async Task<OutResultData<BERepartoAsignado>> obtenerDespachoExecute(int usuarioID)
        {
            var rpta = await _repartoBandejasRepository.obtenerDespacho(usuarioID);

            if (rpta.statusCode <= 0)
                throw new ApplicationException(rpta.message);
            else
                return rpta;
        }

        public async Task<OutResultData<Dictionary<string, object>>> consultarLegajoExecute(string legajo)
        {
            var rpta = await _repartoBandejasRepository.consultarLegajo(legajo);

            if (rpta.statusCode <= 0)
                throw new ApplicationException(rpta.message);
            else
                return rpta;
        }

        public async Task<OutResultData<Dictionary<string, object>>> consultarResumenExecute(int usuarioID)
        {
            var rpta = await _repartoBandejasRepository.consultarResumen(usuarioID);

            if (rpta.statusCode <= 0)
                throw new ApplicationException(rpta.message);
            else
                return rpta;
        }

        public async Task<OutResultData<string>> registrarRepartoExecute(List<BERegistroEntrega> listaRepartos)
        {
            try
            {
                foreach (BERegistroEntrega item in listaRepartos) {
                    foreach (BERepartoBandeja detalle in item.registroBandejas) {
                        detalle.bandejaEntregaId = item.registroEntregaID;
                    }
                }

                XmlSerializer xmlSerializer = new XmlSerializer(listaRepartos.GetType());

                StringWriter textWriter = new StringWriter();
                xmlSerializer.Serialize(textWriter, listaRepartos);

                StringReader transactionXml = new StringReader(textWriter.ToString());
                XmlTextReader xmlReader = new XmlTextReader(transactionXml);
                SqlXml repartosXML = new SqlXml(xmlReader);

                var rpta = await _repartoBandejasRepository.registrarReparto(repartosXML);

                if (rpta.statusCode <= 0)
                    throw new ApplicationException(rpta.message);
                else
                    return rpta;

            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public async Task<OutResultData<string>> cierreRepartoExecute(int usuarioID)
        {
            try
            {
                var rpta = await _repartoBandejasRepository.cierreReparto(usuarioID);

                if (rpta.statusCode <= 0)
                    throw new ApplicationException(rpta.message);
                else
                    return rpta;

            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

    }
}
