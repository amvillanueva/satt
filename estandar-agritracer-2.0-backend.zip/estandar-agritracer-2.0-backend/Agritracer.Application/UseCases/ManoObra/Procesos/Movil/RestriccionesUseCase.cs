﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ManoObra.Procesos.Movil;
using Agritracer.Domain.ManoObra.Maestros.Movil;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Agritracer.Application.UseCases.ManoObra.Procesos.Movil
{
    public class RestriccionesUseCase: IRestriccionesUseCase
    {
        private readonly IRestriccionesRepository _RestriccionesRepository;

        public RestriccionesUseCase(IRestriccionesRepository oRestriccionesRepository)
        {
            _RestriccionesRepository = oRestriccionesRepository;
        }

        public async Task<OutResultData<List<BEAsistenciaPlanilla>>> validarRestricionesTrabajadoresPlanillaExecute(List<BEAsistenciaPlanilla> asistenciaPlanillas, int tipoTareo)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(asistenciaPlanillas.GetType());

            StringWriter textWriter = new StringWriter();
            xmlSerializer.Serialize(textWriter, asistenciaPlanillas);

            StringReader transactionXml = new StringReader(textWriter.ToString());
            XmlTextReader xmlReader = new XmlTextReader(transactionXml);
            SqlXml asistenteXML = new SqlXml(xmlReader);

            return await _RestriccionesRepository.validarRestricionesTrabajadoresPlanilla(asistenteXML, tipoTareo);
        }
    }

}
