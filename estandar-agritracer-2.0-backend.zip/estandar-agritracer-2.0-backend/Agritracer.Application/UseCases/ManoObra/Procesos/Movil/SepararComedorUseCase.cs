﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ManoObra.Procesos.Movil;
using Agritracer.Domain.ManoObra.Maestros;
using Agritracer.Domain.ManoObra.Procesos.Movil;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Agritracer.Application.UseCases.ManoObra.Procesos.Movil
{
    public class SepararComedorUseCase : ISepararComedorUseCase
    {
        private readonly ISepararComedorRepository _SepararComedorRepository;

        public SepararComedorUseCase(ISepararComedorRepository oSepararComedorRepository)
        {
            _SepararComedorRepository = oSepararComedorRepository;
        }

        public async Task<OutResultData<List<BETrabajadorGrupo>>> obtenerDetalleTrabajadoresExecute(int grupoId, int supervisorId)
        {
            var rpta = await _SepararComedorRepository.obtenerDetalleTrabajadores(grupoId,supervisorId);

            if (rpta.statusCode <= 0)
                throw new ApplicationException(rpta.message);
            else
                return rpta;
        }

        public async Task<OutResultData<List<BETrabajadorGrupo>>> obtenerDetalleTrabajadoresExecute(BESolicitudComedorLab padronGrupo)
        {
            var rpta = await _SepararComedorRepository.obtenerDetalleTrabajadores(padronGrupo);

            if (rpta.statusCode <= 0)
                throw new ApplicationException(rpta.message);
            else
                return rpta;
        }

        public async Task<OutResultData<List<BEComedor>>> obtenerComedoresDisponiblesExecute(int zonaID, int moduloID, int grupoID, int supervisorID)
        {
            var rpta = await _SepararComedorRepository.obtenerComedoresDisponibles(zonaID, moduloID, grupoID, supervisorID);

            if (rpta.statusCode <= 0)
                throw new ApplicationException(rpta.message);
            else
                return rpta;
        }

        public async Task<OutResultData<string>> registrarPadronComedorExecute(List<BEPadronComedor> padronComedor)
        {
            try
            {
                string xml = "";
                var xEle = new XElement("r", from itemPadron in padronComedor
                                             select new XElement("detalles",
                                                 new XAttribute("padronComedorID", itemPadron.padronComedorID),
                                                 new XAttribute("padronComedorCapacidad", itemPadron.padronComedorCapacidad),
                                                 new XAttribute("padronEmpresaID", itemPadron.padronEmpresaID),
                                                 new XAttribute("padronModuloID", itemPadron.padronModuloID),
                                                 new XAttribute("padronGrupoID", itemPadron.padronGrupoID),
                                                 new XAttribute("padronGrupoCod", itemPadron.padronGrupoCod),
                                                 new XAttribute("padronSupervisorID", itemPadron.padronSupervisorID),
                                                 new XAttribute("padronTrabajadorID", itemPadron.padronTrabajadorID),
                                                 new XAttribute("padronTrabajadorCod", itemPadron.padronTrabajadorCod),
                                                 new XAttribute("padronTipoAlmuerzoID", itemPadron.padronTipoAlmuerzoID),
                                                 new XAttribute("planillaTareoID", itemPadron.planillaTareoID),
                                                 new XAttribute("padronFecha", itemPadron.padronFecha),
                                                 new XAttribute("padronUsuarioID", itemPadron.padronUsuarioID),
                                                 new XAttribute("padronIMEI", itemPadron.padronIMEI)));

                xml = Convert.ToString(xEle);

                var rpta = await _SepararComedorRepository.registrarPadronComedor(xml);

                if (rpta.statusCode <= 0)
                    throw new ApplicationException(rpta.message);
                else
                    return rpta;

            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }
    }
}
