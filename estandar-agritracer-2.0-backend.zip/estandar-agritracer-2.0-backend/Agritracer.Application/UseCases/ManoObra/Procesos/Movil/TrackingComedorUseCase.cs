﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.ManoObra.Procesos.Movil;
using Agritracer.Domain.ManoObra.Procesos.Movil;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Agritracer.Application.UseCases.ManoObra.Procesos.Movil
{
    public class TrackingComedorUseCase : ITrackingComedorUseCase
    {
        private readonly ITrackingComedorRepository _TrackingComedorRepository;

        public TrackingComedorUseCase(ITrackingComedorRepository trackingComedorRepository)
        {
            _TrackingComedorRepository = trackingComedorRepository;
        }

        public async Task<OutResultData<List<BEPadronComedor>>> obtenerPadronGrupoExecute(int grupoId)
        {
            var rpta = await _TrackingComedorRepository.obtenerPadronGrupo(grupoId);

            if (rpta.statusCode <= 0)
                throw new ApplicationException(rpta.message);
            else
                return rpta;
        }

        public async Task<OutResultData<string>> solicitarAlmuerzoEmergenciaExecute(List<BEPadronComedor> padronComedor)
        {
            try
            {
                string xml = "";
                var xEle = new XElement("r", from itemPadron in padronComedor
                    select new XElement("detalles",
                        new XAttribute("padronID", itemPadron.padronID),
                        new XAttribute("padronFecha", itemPadron.padronFecha),
                        new XAttribute("padronTrabajadorID", itemPadron.padronTrabajadorID),
                        new XAttribute("padronEmpresaID", itemPadron.padronEmpresaID),
                        new XAttribute("padronModuloID", itemPadron.padronModuloID),
                        new XAttribute("padronGrupoID", itemPadron.padronGrupoID),
                        new XAttribute("padronSupervisorID", itemPadron.padronSupervisorID),
                        new XAttribute("padronComedorID", itemPadron.padronComedorID),
                        new XAttribute("padronTipoAlmuerzoID", itemPadron.padronTipoAlmuerzoID),
                        new XAttribute("almuerzoEmergencia", itemPadron.almuerzoEmergencia),
                        new XAttribute("padronUsuarioID", itemPadron.padronUsuarioID),
                        new XAttribute("padronIMEI", itemPadron.padronIMEI)));

                xml = Convert.ToString(xEle);

                var rpta = await _TrackingComedorRepository.solicitarAlmuerzoEmergencia(xml);

                if (rpta.statusCode <= 0)
                    throw new ApplicationException(rpta.message);
                else
                    return rpta;

            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public async Task<OutResultData<string>> registrarRecepcionAlmuerzoExecute(List<BERecepcionComedor> entregaComedor)
        {
            try
            {
                string xml = "";
                var xEle = new XElement("r", from itemPadron in entregaComedor
                    select new XElement("detalles",
                        new XAttribute("padronID", itemPadron.padronID),
                        new XAttribute("recepcionFecha", itemPadron.recepcionFecha),
                        new XAttribute("recepcionTrabajadorID", itemPadron.recepcionTrabajadorID),
                        new XAttribute("recepcionTrabajadorCod", itemPadron.recepcionTrabajadorCod),
                        new XAttribute("recepcionComedorID", itemPadron.recepcionComedorID),
                        new XAttribute("recepcionTipoAlmuerzoID", itemPadron.recepcionTipoAlmuerzoID),
                        new XAttribute("recepcionUsuarioID", itemPadron.recepcionUsuarioID),
                        new XAttribute("recepcionIMEI", itemPadron.recepcionIMEI)));

                xml = Convert.ToString(xEle);

                var rpta = await _TrackingComedorRepository.registrarEntregaAlmuerzo(xml);

                if (rpta.statusCode <= 0)
                    throw new ApplicationException(rpta.message);
                else
                    return rpta;

            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }
    }
}
