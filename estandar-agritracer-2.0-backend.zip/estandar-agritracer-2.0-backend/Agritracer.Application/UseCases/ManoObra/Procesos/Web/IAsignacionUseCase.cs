﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Procesos
{
    public interface IAsignacionUseCase
    {
        Task<OutResultData<DataTable>> ObtenerReporteAsignacionExec(BEArgs args);
        Task<OutResultData<string>> EliminarAsignacionSupervisorExec(BETransaccion transaccion);
    }
}
