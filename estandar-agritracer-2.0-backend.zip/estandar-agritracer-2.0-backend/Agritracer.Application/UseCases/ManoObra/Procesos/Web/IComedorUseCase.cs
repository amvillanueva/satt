﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Procesos
{
    public interface IComedorUseCase
    {
        Task<OutResultData<DataSet>> ObtenerReporteTrabajadoresComedorExec(BEArgs args);
        Task<OutResultData<DataTable>> ObtenerReporteTrackingAlmuerzosExec(BEArgs args);
        Task<OutResultData<DataTable>> ObtenerReporteIncidenciaAcopioExec(BEArgs args);
        Task<OutResultData<DataTable>> ObtenerReporteAvanceRepartosExec(BEArgs args);
        Task<OutResultData<DataTable>> ObtenerReporteAlmuerzosEmergenciaExec(BEArgs args);
    }
}
