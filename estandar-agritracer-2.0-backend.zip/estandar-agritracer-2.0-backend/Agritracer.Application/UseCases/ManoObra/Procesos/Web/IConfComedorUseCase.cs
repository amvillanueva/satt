﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ManoObra.Procesos;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Procesos
{
    public interface IConfComedorUseCase
    {
        Task<OutResultData<DataTable>> ObtenerConfiguracionDiariaExec(BEArgs args);
        Task<OutResultData<string>> ActualizarDisponibilidadExec(List<BEConfComedor> comedores);
        Task<OutResultData<string>> ActualizarSegundoTurnoExec(List<BEConfComedor> comedores);
    }
}
