﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.ManoObra.Procesos;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Procesos
{
    public interface IPlanillaTareoUseCase
    {
        Task<OutResultData<DataTable>> ObtenerFundosExec(int empresa);
        Task<OutResultData<DataTable>> ObtenerModulosExec(int fundo);
        Task<OutResultData<DataTable>> ObtenerTurnoDiaExec(int empresa);
        Task<OutResultData<DataTable>> ObtenerOrdenInvExec(int empresa);
        Task<OutResultData<DataTable>> ObtenerCentroCostoExec(int empresaID, int tipoActividadID, int flagPacking);

        Task<OutResultData<DataTable>> ObtenerLineaPackingExec(int empresa);

        Task<OutResultData<DataTable>> ObtenerActividadesExec(int empresaID, int tipoActividadID, int flagPacking);
        Task<OutResultData<DataTable>> ObtenerActividadesSupervisorExec(BEArgs args);
        Task<OutResultData<DataTable>> ObtenerCeCoActividadModuloExec(int empresa, int actividad, int modulo);
        Task<OutResultData<DataTable>> ObtenerResumenExec(BEArgs args);
        Task<OutResultData<DataTable>> ObtenerPlanillasDetalleExec(BEArgs args);
        Task<OutResultData<DataTable>> ObtenerPlanillasActividadCboExec(BEArgs args);
        Task<List<BEPlanillaActividad>> ObtenerPlanillasActividadExec(BEArgs args);
        Task<OutResultData<DataTable>> ObtenerPlanillasCodigoExec(string codigos);
        Task<OutResultData<DataTable>> ObtenerPadronDetalleExec(BEArgs args);
        Task<OutResultData<DataSet>> ObtenerPadronResumenExec(BEArgs args);
        Task<OutResultData<DataTable>> ObtenerTrabajadorLegajoExec(BEArgs args);
        Task<OutResultData<DataTable>> ObtenerErroresPlanillaExec(string codigos);
        Task<OutResultData<BEPlanillaTareo>> InsertUpdatePlanillaExec(BEPlanillaTareo planilla);
        Task<OutResultData<string>> InsertarTrabajadorPlanillaExec(BETrabajadorPlanilla trabajador);
        Task<OutResultData<BEPlanillaTransaccion>> ActualizarHorasPlanillaExec(BEPlanillaTransaccion transaccion);
        Task<OutResultData<BEPlanillaTransaccion>> ActualizarHorasPagoPlanillaExec(BEPlanillaTransaccion transaccion);
        Task<OutResultData<BEPlanillaTransaccion>> CopiarPlanillaTrabajadorExec(BEPlanillaTransaccion transaccion);
        Task<OutResultData<BEPlanillaTransaccion>> MoverPlanillaTrabajadorExec(BEPlanillaTransaccion transaccion);
        Task<OutResultData<BEPlanillaTransaccion>> ActualizarBonoPlanillaExec(BEPlanillaTransaccion transaccion);
        Task<OutResultData<BEPlanillaTransaccion>> ActualizarEstadoPlanillaExec(BEPlanillaTransaccion transaccion);
        Task<OutResultData<BEPlanillaTransaccion>> EliminarPlanillaExec(BEPlanillaTransaccion transaccion);
        Task<OutResultData<BEPlanillaTransaccion>> EliminarDetallePlanillaExec(BEPlanillaTransaccion transaccion);
        Task<OutResultData<bool>> ExecAprobarPlanillasSupervisor(BEArgs args);

        Task<OutResultData<BEPlanillaTransaccion>> DistribuirHorasPagoSupervisorExec(BEPlanillaTransaccion transaccion);

        //-----------------------------

        #region TareoPacking

        Task<OutResultData<DataTable>> ObtenerResumenPackingExec(BEArgs args); //Listado Planillas
        Task<OutResultData<DataSet>> ObtenerPadronResumenPackingExec(BEArgs args); //Padron Resumen
        Task<OutResultData<DataTable>> ObtenerPadronDetallePackingExec(BEArgs args); //Padron Detalle

        Task<OutResultData<DataTable>> ObtenerPlanillasDetallePackingExec(BEArgs args); // Planillas Detalle

        Task<OutResultData<BEPlanillaTareo>> InsertUpdatePlanillaPackingExec(BEPlanillaTareo planilla); // Insert Update Planilla

        #endregion

    }
}
