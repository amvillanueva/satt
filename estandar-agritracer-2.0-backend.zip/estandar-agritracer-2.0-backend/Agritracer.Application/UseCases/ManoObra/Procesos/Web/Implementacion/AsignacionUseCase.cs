﻿using System.Threading.Tasks;
using Agritracer.Application.Repositories.ManoObra.Procesos;
using Agritracer.Application.OutputObjets;
using System.Data;
using Agritracer.Domain.Common;

namespace Agritracer.Application.UseCases.ManoObra.Procesos
{
    public class AsignacionUseCase : IAsignacionUseCase
    {
        private readonly IAsignacionRepository _asignacionRepository;

        public AsignacionUseCase(IAsignacionRepository asignacionRepository)
        {
            _asignacionRepository = asignacionRepository;
        }
        
        public async Task<OutResultData<DataTable>> ObtenerReporteAsignacionExec(BEArgs args)
        {
            return await _asignacionRepository.ObtenerReporteAsignacion(args.fechaIni,args.fechaFin,args.empresaID,args.usuarioID);
        }
        
        public async Task<OutResultData<string>> EliminarAsignacionSupervisorExec(BETransaccion transaccion)
        {
            var rpta = await _asignacionRepository.EliminarAsignacionSupervisor(transaccion);

            if (rpta.statusCode <= 0)
                throw new ApplicationException(rpta.message);
            else
                return rpta;
        }
    }
}
