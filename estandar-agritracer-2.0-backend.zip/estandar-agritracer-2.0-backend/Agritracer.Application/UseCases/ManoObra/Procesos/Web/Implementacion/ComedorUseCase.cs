﻿using System.Data;
using System.Threading.Tasks;
using Agritracer.Application.Repositories.ManoObra.Procesos;
using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;

namespace Agritracer.Application.UseCases.ManoObra.Procesos
{
    public class ComedorUseCase : IComedorUseCase
    {
        private readonly IComedorRepository _comedorRepository;

        public ComedorUseCase(IComedorRepository comedorRepository)
        {
            _comedorRepository = comedorRepository;
        }

        public async Task<OutResultData<DataSet>> ObtenerReporteTrabajadoresComedorExec(BEArgs args)
        {
            return await _comedorRepository.ObtenerReporteTrabajadoresComedor(args.fechaIni,args.fechaFin,args.empresaID,args.usuarioID);
        }

        public async Task<OutResultData<DataTable>> ObtenerReporteTrackingAlmuerzosExec(BEArgs args)
        {
            return await _comedorRepository.ObtenerReporteTrackingAlmuerzos(args.fechaIni, args.fechaFin, args.empresaID,
                args.usuarioID, args.supervisorID, args.tipoAlmuerzo);
        }

        public async Task<OutResultData<DataTable>> ObtenerReporteIncidenciaAcopioExec(BEArgs args)
        {
            return await _comedorRepository.ObtenerReporteIncidenciaAcopio(args.fechaIni, args.fechaFin, args.empresaID, args.usuarioID);
        }

        public async Task<OutResultData<DataTable>> ObtenerReporteAvanceRepartosExec(BEArgs args)
        {
            return await _comedorRepository.ObtenerReporteAvanceRepartos(args.fechaIni, args.fechaFin, args.vehiculoID);
        }

        public async Task<OutResultData<DataTable>> ObtenerReporteAlmuerzosEmergenciaExec(BEArgs args)
        {
            return await _comedorRepository.ObtenerReporteAlmuerzosEmergencia(args.fechaIni, args.fechaFin, args.empresaID,
                args.usuarioID, args.supervisorID, args.tipoAlmuerzo);
        }
    }
}
