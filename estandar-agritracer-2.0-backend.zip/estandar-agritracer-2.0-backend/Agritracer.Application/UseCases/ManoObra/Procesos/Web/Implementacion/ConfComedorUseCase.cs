﻿using System.Data;
using System.Threading.Tasks;
using System.Collections.Generic;
using Agritracer.Application.Repositories.ManoObra.Procesos;
using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Procesos;
using Agritracer.Domain.Common;
using System.Xml.Linq;
using System.Linq;
using System;

namespace Agritracer.Application.UseCases.ManoObra.Procesos
{
    public class ConfComedorUseCase : IConfComedorUseCase
    {
        private readonly IConfComedorRepository _confComedorRepository;

        public ConfComedorUseCase(IConfComedorRepository confComedorRepository)
        {
            _confComedorRepository = confComedorRepository;
        }

        public async Task<OutResultData<DataTable>> ObtenerConfiguracionDiariaExec(BEArgs args)
        {
            return await _confComedorRepository.GetConfiguracionDia(args.zonaID,args.comedorID,
                args.empresaID,args.usuarioID,args.fecha.Value);
        }
        
        public async Task<OutResultData<string>> ActualizarDisponibilidadExec(List<BEConfComedor> comedores)
        {
            try
            {
                string xml = "";
                var xEle = new XElement("r", from comedor in comedores
                select new XElement("detalles",
                    new XAttribute("configuracionID", comedor.configuracionID),
                    new XAttribute("fecha", comedor.fecha),
                    new XAttribute("comedorID", comedor.comedorID),
                    new XAttribute("comedor", comedor.comedor),
                    new XAttribute("modulo", comedor.modulo),
                    new XAttribute("zonaID", comedor.zonaID),
                    new XAttribute("capacidad", comedor.capacidad),
                    new XAttribute("usabilidad", comedor.usabilidad),
                    new XAttribute("turno1", comedor.turno1),
                    new XAttribute("turno2", comedor.turno2),
                    new XAttribute("usuario", comedor.userName),
                    new XAttribute("hostName", comedor.hostName)));

                xml = Convert.ToString(xEle);

                var rpta = await _confComedorRepository.UpdateDisponibilidad(xml);

                if (rpta.statusCode <= 0)
                    throw new ApplicationException(rpta.message);
                else
                    return rpta;

            }catch (Exception ex){
                throw new ApplicationException(ex.Message);
            }
        }

        public async Task<OutResultData<string>> ActualizarSegundoTurnoExec(List<BEConfComedor> comedores)
        {
            try
            {
                String xml = "";
                var xEle = new XElement("r", from comedor in comedores
                    select new XElement("detalles",
                        new XAttribute("configuracionID", comedor.configuracionID),
                        new XAttribute("fecha", comedor.fecha),
                        new XAttribute("comedorID", comedor.comedorID),
                        new XAttribute("comedor", comedor.comedor),
                        new XAttribute("modulo", comedor.modulo),
                        new XAttribute("zonaID", comedor.zonaID),
                        new XAttribute("capacidad", comedor.capacidad),
                        new XAttribute("usabilidad", comedor.usabilidad),
                        new XAttribute("turno1", comedor.turno1),
                        new XAttribute("turno2", comedor.turno2),
                        new XAttribute("usuario", comedor.userName),
                        new XAttribute("hostName", comedor.hostName)));

                xml = Convert.ToString(xEle);

                var rpta = await _confComedorRepository.UpdateSegundoTurno(xml);

                if (rpta.statusCode <= 0)
                    throw new ApplicationException(rpta.message);
                else
                    return rpta;
            }catch (Exception ex){
                throw new ApplicationException(ex.Message);
            }
        }
    }
}
