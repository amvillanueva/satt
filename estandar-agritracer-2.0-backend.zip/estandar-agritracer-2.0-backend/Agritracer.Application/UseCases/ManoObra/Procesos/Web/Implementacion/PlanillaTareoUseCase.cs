﻿using System.Threading.Tasks;
using System.Collections.Generic;
using Agritracer.Application.Repositories.ManoObra.Procesos;
using Agritracer.Application.OutputObjets;
using Agritracer.Domain.ManoObra.Procesos;
using System.Data;
using Agritracer.Domain.Common;

namespace Agritracer.Application.UseCases.ManoObra.Procesos
{
    public class PlanillaTareoUseCase : IPlanillaTareoUseCase
    {
        private readonly IPlanillaTareoRepository _controlPlanillaRepository;

        public PlanillaTareoUseCase(IPlanillaTareoRepository controlPlanillaRepository)
        {
            _controlPlanillaRepository = controlPlanillaRepository;
        }

        public async Task<OutResultData<DataTable>> ObtenerActividadesExec(int empresaID, int tipoActividadID, int flagPacking)
        {
            return await _controlPlanillaRepository.GetActividades(empresaID, tipoActividadID, flagPacking);
        }

        public async Task<OutResultData<DataTable>> ObtenerCentroCostoExec(int empresaID, int tipoActividadID, int flagPacking)
        {
            return await _controlPlanillaRepository.GetCentroCosto(empresaID, tipoActividadID, flagPacking);
        }

        public async Task<OutResultData<DataTable>> ObtenerLineaPackingExec(int empresa)
        {
            return await _controlPlanillaRepository.GetLineaPacking(empresa);
        }

        public async Task<OutResultData<DataTable>> ObtenerCeCoActividadModuloExec(int empresa, int actividad, int modulo)
        {
            return await _controlPlanillaRepository.GetCeCoXActividadModulo(empresa, actividad, modulo);
        }

        public async Task<OutResultData<DataTable>> ObtenerFundosExec(int empresa)
        {
            return await _controlPlanillaRepository.GetFundos(empresa);
        }

        public async Task<OutResultData<DataTable>> ObtenerModulosExec(int fundo)
        {
            return await _controlPlanillaRepository.GetModulos(fundo);
        }

        public async Task<OutResultData<DataTable>> ObtenerOrdenInvExec(int empresa)
        {
            return await _controlPlanillaRepository.GetOrdenInv(empresa);
        }

        public async Task<OutResultData<DataTable>> ObtenerTurnoDiaExec(int empresa)
        {
            return await _controlPlanillaRepository.GetTurnoDia(empresa);
        }

        public async Task<OutResultData<DataTable>> ObtenerResumenExec(BEArgs args)
        {
            return await _controlPlanillaRepository.GetResumenPLanillas(args.fechaIni, args.fechaFin, args.empresaID, args.supervisorID, args.usuarioID);
        }

        public async Task<OutResultData<DataTable>> ObtenerActividadesSupervisorExec(BEArgs args)
        {
            return await _controlPlanillaRepository.GetActividadesSupervisor(args.supervisorID, args.fecha);
        }

        public async Task<List<BEPlanillaActividad>> ObtenerPlanillasActividadExec(BEArgs args)
        {
            return await _controlPlanillaRepository.GetPlanillasActividad(args.empresaID, args.supervisorID, args.fechaIni);
        }

        public async Task<OutResultData<DataTable>> ObtenerPlanillasCodigoExec(string codigos)
        {
            return await _controlPlanillaRepository.GetPlanillasCodigo(codigos);
        }

        public async Task<OutResultData<DataTable>> ObtenerPlanillasDetalleExec(BEArgs args)
        {
            return await _controlPlanillaRepository.GetPlanillasDetalle(args.empresaID, args.actividadID, args.supervisorID,args.fecha);
        }

        public async Task<OutResultData<DataTable>> ObtenerPadronDetalleExec(BEArgs args)
        {
            return await _controlPlanillaRepository.GetPadronDetalle(args.planillaID,args.empresaID, args.actividadID);
        }

        public async Task<OutResultData<DataSet>> ObtenerPadronResumenExec(BEArgs args)
        {
            return await _controlPlanillaRepository.GetPadronResumen(args.fecha, args.empresaID, args.supervisorID, args.actividadID);
        }

        public async Task<OutResultData<DataTable>> ObtenerTrabajadorLegajoExec(BEArgs args)
        {
            return await _controlPlanillaRepository.GetTrabajadorXLegajo(args.legajo, args.fechaStr);
        }

        public async Task<OutResultData<string>> InsertarTrabajadorPlanillaExec(BETrabajadorPlanilla trabajador)
        {
            var rpta= await _controlPlanillaRepository.AddTrabajadorPlanilla(trabajador);

            if (rpta.statusCode <= 0){
                throw new ApplicationException(rpta.message);
            }
            else {
                return rpta;
            }
        }

        public async Task<OutResultData<BEPlanillaTareo>> InsertUpdatePlanillaExec(BEPlanillaTareo planilla)
        {
            if (planilla.planillaID > 0)
            {
                var rpta = await _controlPlanillaRepository.UpdatePlanillaTareo(planilla);
                if (rpta.statusCode <= 0)
                {
                    throw new ApplicationException(rpta.message);
                }
                else
                {
                    return rpta;
                }
            }
            else
            {
                var rpta = await _controlPlanillaRepository.InsertPlanillaTareo(planilla);
                if (rpta.statusCode <= 0)
                {
                    throw new ApplicationException(rpta.message);
                }
                else
                {
                    return rpta;
                }
            }
        }

        public async Task<OutResultData<DataTable>> ObtenerPlanillasActividadCboExec(BEArgs args)
        {
            return await _controlPlanillaRepository.GetPlanillasActividadCbo(args.actividadID, args.supervisorID, args.fecha);
        }

        public async Task<OutResultData<DataTable>> ObtenerErroresPlanillaExec(string codigos)
        {
            return await _controlPlanillaRepository.GetListaErroresPlanilla(codigos);
        }

        public async Task<OutResultData<BEPlanillaTransaccion>> ActualizarHorasPlanillaExec(BEPlanillaTransaccion transaccion)
        {
            var rpta = await _controlPlanillaRepository.UpdateHorasPlanilla(transaccion);

            if (rpta.statusCode <= 0){
                throw new ApplicationException(rpta.message);
            }else{
                return rpta;
            }
        }

        public async Task<OutResultData<BEPlanillaTransaccion>> ActualizarHorasPagoPlanillaExec(BEPlanillaTransaccion transaccion)
        {
            var rpta = await _controlPlanillaRepository.UpdateHorasPagoPlanilla(transaccion);

            if (rpta.statusCode <= 0)
            {
                throw new ApplicationException(rpta.message);
            }
            else
            {
                return rpta;
            }
        }

        public async Task<OutResultData<BEPlanillaTransaccion>> CopiarPlanillaTrabajadorExec(BEPlanillaTransaccion transaccion)
        {
            var rpta = await _controlPlanillaRepository.CopyPlanillaTrabajador(transaccion);

            if (rpta.statusCode <= 0)
            {
                throw new ApplicationException(rpta.message);
            }
            else
            {
                return rpta;
            }
        }

        public async Task<OutResultData<BEPlanillaTransaccion>> MoverPlanillaTrabajadorExec(BEPlanillaTransaccion transaccion)
        {
            var rpta = await _controlPlanillaRepository.MovePlanillaTrabajador(transaccion);

            if (rpta.statusCode <= 0)
            {
                throw new ApplicationException(rpta.message);
            }
            else
            {
                return rpta;
            }
        }

        public async Task<OutResultData<BEPlanillaTransaccion>> ActualizarBonoPlanillaExec(BEPlanillaTransaccion transaccion)
        {
            var rpta = await _controlPlanillaRepository.UpdateBonoPlanilla(transaccion);

            if (rpta.statusCode <= 0)
            {
                throw new ApplicationException(rpta.message);
            }
            else
            {
                return rpta;
            }
        }
        
        public async Task<OutResultData<BEPlanillaTransaccion>> ActualizarEstadoPlanillaExec(BEPlanillaTransaccion transaccion)
        {
            var rpta = await _controlPlanillaRepository.UpdateEstadoPlanilla(transaccion);

            if (rpta.statusCode <= 0)
            {
                throw new ApplicationException(rpta.message);
            }
            else
            {
                return rpta;
            }
        }

        public async Task<OutResultData<BEPlanillaTransaccion>> EliminarPlanillaExec(BEPlanillaTransaccion transaccion)
        {
            var rpta = await _controlPlanillaRepository.DeletePlanilla(transaccion);

            if (rpta.statusCode <= 0)
            {
                throw new ApplicationException(rpta.message);
            }
            else
            {
                return rpta;
            }
        }

        public async Task<OutResultData<BEPlanillaTransaccion>> EliminarDetallePlanillaExec(BEPlanillaTransaccion transaccion)
        {
            var rpta = await _controlPlanillaRepository.DeletePlanillaDetalle(transaccion);

            if (rpta.statusCode <= 0)
            {
                throw new ApplicationException(rpta.message);
            }
            else
            {
                return rpta;
            }
        }

        //---------------------------------------------

        #region TareoPacking

        public async Task<OutResultData<DataTable>> ObtenerResumenPackingExec(BEArgs args) //Listado Planillas
        {
            return await _controlPlanillaRepository.GetResumenPLanillasPacking(args.fechaIni, args.fechaFin, args.empresaID, args.supervisorID, args.usuarioID);
        }

        public async Task<OutResultData<DataTable>> ObtenerPadronDetallePackingExec(BEArgs args)
        {
            return await _controlPlanillaRepository.GetPadronDetalle(args.planillaID, args.empresaID, args.actividadID);
        }

        public async Task<OutResultData<DataSet>> ObtenerPadronResumenPackingExec(BEArgs args)
        {
            return await _controlPlanillaRepository.GetPadronResumen(args.fecha, args.empresaID, args.supervisorID, args.actividadID);
        }

        public async Task<OutResultData<DataTable>> ObtenerPlanillasDetallePackingExec(BEArgs args)
        {
            return await _controlPlanillaRepository.GetPlanillasDetallePacking(args.empresaID, args.actividadID, args.supervisorID, args.fecha);
        }

        public async Task<OutResultData<BEPlanillaTareo>> InsertUpdatePlanillaPackingExec(BEPlanillaTareo planilla)
        {
            if (planilla.planillaID > 0)
            {
                var rpta = await _controlPlanillaRepository.UpdatePlanillaTareoPacking(planilla);

                if (rpta.statusCode <= 0)
                    throw new ApplicationException(rpta.message);
                else
                    return rpta;
            }
            else
            {
                var rpta = await _controlPlanillaRepository.InsertPlanillaTareoPacking(planilla);

                if (rpta.statusCode <= 0)
                    throw new ApplicationException(rpta.message);
                else
                    return rpta;
            }
        }

        #endregion

        public async Task<OutResultData<bool>> ExecAprobarPlanillasSupervisor(BEArgs args)
        {
            return await _controlPlanillaRepository.AprobarPlanillasSupervisor(args);
        }

        public async Task<OutResultData<BEPlanillaTransaccion>> DistribuirHorasPagoSupervisorExec(BEPlanillaTransaccion transaccion)
        {
            var rpta = await _controlPlanillaRepository.UpdateDistribucionHorasPagoSupervisor(transaccion);

            if (rpta.statusCode <= 0)
            {
                throw new ApplicationException(rpta.message);
            }
            else
            {
                return rpta;
            }
        }

    }
}
