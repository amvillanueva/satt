﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.ManoObra.Reportes
{
    public interface IReporteUseCase
    {
        Task<OutResultData<DataTable>> ObtenerReporteAsistenciaTareoExec(BEArgs args);
        Task<OutResultData<DataTable>> ObtenerReporteSemanalTareoExec(BEArgs args);
        Task<OutResultData<DataTable>> ObtenerReporteHorasTareoExec(BEArgs args);
        Task<OutResultData<DataTable>> ObtenerReporteProductividadExec(BEArgs args);
        Task<OutResultData<DataTable>> ObtenerReporteProductividadVariedadExec(BEArgs args);
        Task<OutResultData<DataTable>> ObtenerReporteComedorPackingExec(BEArgs args);
        Task<OutResultData<DataSet>> ObtenerReporteTrabajadoresPlanillaExec(BEArgs args);
        Task<OutResultData<DataSet>> ObtenerReporteExportacionNisiraExec(BEArgs args);
        Task<OutResultData<DataTable>> ObtenerReporteHistorialContratosExec(BEArgs args);
        Task<OutResultData<DataTable>> ExecuteReporteGenericoManoObraDT(BEParams args);
        Task<OutResultData<DataTable>> ObtenerReporteGruposTrabajoExec(BEArgs args);
    }
}
