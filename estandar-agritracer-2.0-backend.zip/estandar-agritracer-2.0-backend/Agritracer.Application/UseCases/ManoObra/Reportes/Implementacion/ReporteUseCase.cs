﻿using System.Threading.Tasks;
using Agritracer.Application.UseCases.ManoObra.Reportes;
using Agritracer.Application.Repositories.ManoObra.Reportes;
using Agritracer.Application.OutputObjets;
using System.Data;
using Agritracer.Domain.Common;

namespace Agritracer.Application.UseCases.ManoObra.Procesos
{
    public class ReporteUseCase : IReporteUseCase
    {
        private readonly IReportesRepository _reporteRepository;

        public ReporteUseCase(IReportesRepository reporteRepository)
        {
            _reporteRepository = reporteRepository;
        }
        
        public async Task<OutResultData<DataTable>> ObtenerReporteAsistenciaTareoExec(BEArgs args)
        {
            if (args.flagPacking == 1)
            {
                return await _reporteRepository.GetReporteAsistenciaTareoPacking(args.fechaIni, args.fechaFin, args.empresaID, args.supervisorID, args.usuarioID);
            }
            else
            {
                return await _reporteRepository.GetReporteAsistenciaTareo(args.fechaIni, args.fechaFin, args.empresaID, args.supervisorID, args.grupoTrabajo, args.usuarioID);
            }
        }

        public async Task<OutResultData<DataTable>> ObtenerReporteSemanalTareoExec(BEArgs args)
        {
            if (args.flagPacking == 1)
            {
                return await _reporteRepository.GetReporteSemanalTareoPacking(args.usuarioID, args.empresaID, args.supervisorID, args.semanaID);
            }
            else
            {
                return await _reporteRepository.GetReporteSemanalTareo(args.usuarioID, args.empresaID, args.supervisorID, args.semanaID);
            }
        }
        
        public async Task<OutResultData<DataTable>> ObtenerReporteHorasTareoExec(BEArgs args)
        {
            if (args.flagPacking == 1)
            {
                return await _reporteRepository.GetReporteHorasTareoPacking(args.fechaIni, args.fechaFin, args.empresaID, args.supervisorID, args.perfilID, args.actividadID, args.legajo, args.tipoReporte, args.usuarioID);
            }
            else
            {
                return await _reporteRepository.GetReporteHorasTareo(args.fechaIni, args.fechaFin, args.empresaID, args.supervisorID, args.perfilID, args.actividadID, args.grupoTrabajo, args.legajo, args.tipoReporte, args.usuarioID);
            }
        }

        public async Task<OutResultData<DataTable>> ObtenerReporteProductividadExec(BEArgs args)
        {
            return await _reporteRepository.GetReporteProductividad(args.fechaIni, args.fechaFin, args.empresaID, args.supervisorID, args.actividadID, args.fundoID, args.variedadID, args.tipoReporte, args.usuarioID);
        }

        public async Task<OutResultData<DataTable>> ObtenerReporteProductividadVariedadExec(BEArgs args)
        {
            return await _reporteRepository.GetReporteProductividadVariedad(args.fechaIni, args.fechaFin, args.empresaID, args.supervisorID, args.actividadID, args.fundoID, args.variedadID,args.usuarioID);
        }

        public async Task<OutResultData<DataTable>> ObtenerReporteComedorPackingExec(BEArgs args)
        {
            return await _reporteRepository.GetReporteComedorPacking(args.fechaIni, args.fechaFin, args.empresaID, args.almuerzo, args.cena);
        }

        public async Task<OutResultData<DataSet>> ObtenerReporteTrabajadoresPlanillaExec(BEArgs args)
        {
            return await _reporteRepository.GetReporteTrabajadoresPlanilla(args.valorID, args.empresaID);
        }

        public async Task<OutResultData<DataSet>> ObtenerReporteExportacionNisiraExec(BEArgs args)
        {
            return await _reporteRepository.GetReporteExportacionNisira(args.fechaStr);
        }

        public async Task<OutResultData<DataTable>> ObtenerReporteHistorialContratosExec(BEArgs args)
        {
            return await _reporteRepository.GetReporteHistorialContratos(args);
        }

        public async Task<OutResultData<DataTable>> ExecuteReporteGenericoManoObraDT(BEParams args)
        {
            return await _reporteRepository.GetReporteGenericoManoObraDT(args);
        }

        public async Task<OutResultData<DataTable>> ObtenerReporteGruposTrabajoExec(BEArgs args)
        {
            return await _reporteRepository.GetReporteGruposTrabajo(args.empresaID, args.grupoTrabajoID, args.legajo, args.descripcion);
        }
    }
}
