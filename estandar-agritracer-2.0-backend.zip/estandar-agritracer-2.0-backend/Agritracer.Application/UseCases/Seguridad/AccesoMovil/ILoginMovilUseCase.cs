﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Seguridad;
using System;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Login
{
    public interface ILoginMovilUseCase
    {
        Task<BEUsuarioMovil> GetUserMovilByID(int userID);
        Task<OutResultData<BEUsuarioMovil>> GetUserByLoginPass(String login, String password, int empresaId);
    }
}
