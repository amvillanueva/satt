﻿using System.Threading.Tasks;
using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories;
using Agritracer.Application.Services;
using Agritracer.Domain.Seguridad;

namespace Agritracer.Application.UseCases.Login
{
    public sealed class LoginMovilUseCase : ILoginMovilUseCase
    {
        private readonly IAuthMovilReadWriteRepository _authMovilReadWriteRepository;
        private readonly IJwtFactory _jwtFactory;

        public LoginMovilUseCase(IAuthMovilReadWriteRepository authMovilReadWriteRepository, IJwtFactory jwtFactory)
        {
            _authMovilReadWriteRepository = authMovilReadWriteRepository;
            _jwtFactory = jwtFactory;
        }

        public async Task<BEUsuarioMovil> GetUserMovilByID(int usuarioId)
        {
            BEUsuarioMovil usuarioLogin = await _authMovilReadWriteRepository.GetUsuarioMovilByID(usuarioId);

            if (usuarioLogin == null)
            {
                throw new ApplicationException("El usuario no es válido");
            }
            else if (!usuarioLogin.usuarioStatusMovil.Equals(""))
            {
                throw new ApplicationException(usuarioLogin.usuarioStatusMovil);
            }
            
            return usuarioLogin;
        }

        public async Task<OutResultData<BEUsuarioMovil>> GetUserByLoginPass(string login, string password, int empresaId)
        {
            OutResultData<BEUsuarioMovil> usuarioMovilOut = await _authMovilReadWriteRepository.GetUsuarioMovilByLoginPass(login, password, empresaId);
            
            if (usuarioMovilOut.data != null) {
                var token = await _jwtFactory.GenerateEncodedToken(usuarioMovilOut.data);
                usuarioMovilOut.data.usuarioToken = token.authToken;
            }else if (!usuarioMovilOut.message.Equals(""))
            {
                throw new ApplicationException(usuarioMovilOut.message);
            }

            return usuarioMovilOut;
        }

    }
}
