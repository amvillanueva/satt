﻿using Agritracer.Domain.Seguridad;
using System;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Seguridad
{
    public interface ILoginWebUseCase
    {
        Task<BEToken> GetTokenByLoginPass(String login, String password);
        Task<BEUsuarioWeb> GetUserWebByID(int id);
    }
}
