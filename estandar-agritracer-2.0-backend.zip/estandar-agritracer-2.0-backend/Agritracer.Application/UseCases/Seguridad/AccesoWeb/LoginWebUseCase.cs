﻿using System.Threading.Tasks;
using Agritracer.Application.Repositories;
using Agritracer.Application.Services;
using Agritracer.Application.UseCases.Seguridad;
using Agritracer.Domain.Seguridad;

namespace Agritracer.Application.UseCases.Login
{
    public sealed class LoginWebUseCase : ILoginWebUseCase
    {
        private readonly IAuthWebReadWriteRepository _authWebReadWriteRepository;
        private readonly IJwtFactory _jwtFactory;

        public LoginWebUseCase(IAuthWebReadWriteRepository authWebReadWriteRepository, IJwtFactory jwtFactory)
        {
            _authWebReadWriteRepository = authWebReadWriteRepository;
            _jwtFactory = jwtFactory;
        }

        public async Task<BEToken> GetTokenByLoginPass(string login, string password)
        {
            var usuarioWeb = await _authWebReadWriteRepository.GetOutUsuarioWebExec(login, password);

            if (usuarioWeb == null)
            {
                throw new ApplicationException("El usuario no es válido");
            }
            else if (!usuarioWeb.messageOutputUsuario.Equals("")){
                throw new ApplicationException(usuarioWeb.messageOutputUsuario);
            }
            else{
                return await _jwtFactory.GenerateEncodedToken(usuarioWeb);
            }
        }

        public async Task<BEUsuarioWeb> GetUserWebByID(int id)
        {
            var usuarioWeb = await _authWebReadWriteRepository.GetUsuarioWebByIDExec(id);

            if (!usuarioWeb.mensajeRpta.Equals(""))
                throw new ApplicationException(usuarioWeb.mensajeRpta);
            else
                return usuarioWeb;
        }
    }
}
