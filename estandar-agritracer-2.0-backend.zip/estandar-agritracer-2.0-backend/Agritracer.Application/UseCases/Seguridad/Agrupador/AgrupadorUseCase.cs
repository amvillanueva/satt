﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.Seguridad;
using Agritracer.Domain.Common;
using Agritracer.Domain.Seguridad;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Seguridad
{
    public class AgrupadorUseCase : IAgrupadorUseCase
    {
        private readonly IAgrupadorRepository agrupadorRepository;

        public AgrupadorUseCase(IAgrupadorRepository agrupadorRepository)
        {
            this.agrupadorRepository = agrupadorRepository;
        }
        public async Task<OutResultData<DataTable>> ExecuteGetByCultivo(int id)
        {
            return await agrupadorRepository.GetByCultivo(id);
        }
        public async Task<OutResultData<DataTable>> ExecuteGetTipoConfig(BEArgs args)
        {
            return await agrupadorRepository.GetTipoConfig(args);
        }
        public async Task<OutResultData<string>> ExecuteInsUpdDel(BEAgrupador agrupador, int accion)
        {
            return await agrupadorRepository.InsUpdDel(agrupador, accion);
        }
        public async Task<OutResultData<string>> ExecuteDeleteAllSelected(BEArgs args)
        {
            return await agrupadorRepository.DeleteAllSelected(args);
        }
    }
}
