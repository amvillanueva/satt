﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Seguridad;
using System.Data;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Seguridad
{
    public interface IAgrupadorUseCase
    {
        Task<OutResultData<DataTable>> ExecuteGetByCultivo(int id);
        Task<OutResultData<DataTable>> ExecuteGetTipoConfig(BEArgs args);
        Task<OutResultData<string>> ExecuteInsUpdDel(BEAgrupador agrupador, int accion);
        Task<OutResultData<string>> ExecuteDeleteAllSelected(BEArgs args);
    }
}
