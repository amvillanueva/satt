﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Seguridad;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Seguridad
{
    public interface IPerfilUseCase
    {
        Task<OutResultData<BEPerfil>> ExecuteGetById(int id);
        Task<OutResultData<List<BEPerfil>>> ExecuteGetAll(BEArgs args);
        Task<OutResultData<BEPerfil>> ExecuteInsUpdDel(BEPerfil perfil, int accion);
        Task<OutResultData<BEPerfil>> ExecuteDeleteAllSelected(BEArgs args);
    }
}
