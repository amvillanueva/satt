﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.Seguridad;
using Agritracer.Domain.Common;
using Agritracer.Domain.Seguridad;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Seguridad.Implementacion
{
    public class PerfilUseCase : IPerfilUseCase
    {
        private readonly IPerfilRepository perfilRepository;

        public PerfilUseCase(IPerfilRepository perfilRepository)
        {
            this.perfilRepository = perfilRepository;
        }
        public async Task<OutResultData<BEPerfil>> ExecuteGetById(int id)
        {
            return await this.perfilRepository.GetById(id);
        }
        public async Task<OutResultData<List<BEPerfil>>> ExecuteGetAll(BEArgs args)
        {
            return await this.perfilRepository.GetAll(args);
        }
        public async Task<OutResultData<BEPerfil>> ExecuteInsUpdDel(BEPerfil perfil, int accion)
        {
            return await this.perfilRepository.InsUpdDel(perfil, accion);
        }
        public async Task<OutResultData<BEPerfil>> ExecuteDeleteAllSelected(BEArgs args)
        {
            return await this.perfilRepository.DeleteAllSelected(args);
        }
    }
}
