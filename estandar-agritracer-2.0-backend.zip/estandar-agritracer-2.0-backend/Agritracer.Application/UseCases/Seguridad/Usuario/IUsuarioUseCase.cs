﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using Agritracer.Domain.Seguridad;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Seguridad
{
    public interface IUsuarioUseCase
    {
        Task<OutResultData<BEUsuario>> ExecuteGetById(int id);
        Task<OutResultData<List<BEUsuario>>> ExecuteGetAll(BEArgs args);
        Task<OutResultData<BEUsuario>> ExecuteInsUpdDel(BEUsuario perfil, int accion);
        Task<OutResultData<BEUsuario>> ExecuteDeleteAllSelected(BEArgs args);
    }
}
