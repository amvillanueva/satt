﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.Seguridad;
using Agritracer.Domain.Common;
using Agritracer.Domain.Seguridad;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.Seguridad.Implementacion
{
    public class UsuarioUseCase : IUsuarioUseCase
    {
        private readonly IUsuarioRepository usuarioRepository;

        public UsuarioUseCase(IUsuarioRepository usuarioRepository)
        {
            this.usuarioRepository = usuarioRepository;
        }
        public async Task<OutResultData<BEUsuario>> ExecuteGetById(int id)
        {
            return await this.usuarioRepository.GetById(id);
        }
        public async Task<OutResultData<List<BEUsuario>>> ExecuteGetAll(BEArgs args)
        {
            return await this.usuarioRepository.GetAll(args);
        }
        public async Task<OutResultData<BEUsuario>> ExecuteInsUpdDel(BEUsuario usuario, int accion)
        {
            return await this.usuarioRepository.InsUpdDel(usuario, accion);
        }
        public async Task<OutResultData<BEUsuario>> ExecuteDeleteAllSelected(BEArgs args)
        {
            return await this.usuarioRepository.DeleteAllSelected(args);
        }
    }
}
