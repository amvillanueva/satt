﻿using Agritracer.Application.OutputObjets;
using Agritracer.Application.Repositories.SmartData.Control;
using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.SmartData.Control
{
    public class GisUseCase : IGisUseCase
    {
        private readonly IGisRepository gisRepository;

        public GisUseCase(IGisRepository gisRepository)
        {
            this.gisRepository = gisRepository;
        }

        public async Task<OutResultData<DataSet>> ExecuteGetIndicador(BEArgs args)
        {
            return await this.gisRepository.GetIndicador(args);
        }
        public async Task<OutResultData<DataTable>> ExecuteGetDetalleLote(BEArgs args)
        {
            return await this.gisRepository.GetDetalleLote(args);
        }
    }
}
