﻿using Agritracer.Application.OutputObjets;
using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace Agritracer.Application.UseCases.SmartData.Control
{
    public interface IGisUseCase
    {
        Task<OutResultData<DataSet>> ExecuteGetIndicador(BEArgs args);
        Task<OutResultData<DataTable>> ExecuteGetDetalleLote(BEArgs args);
    }
}
