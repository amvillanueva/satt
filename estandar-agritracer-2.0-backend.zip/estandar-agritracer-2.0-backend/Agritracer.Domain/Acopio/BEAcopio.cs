﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.Acopio
{
    public class BEAcopio : BEMaster
    {
        public int acopioID { get; set; }
        public int empresaID { get; set; }
        public string empresaNombre { get; set; }
        public string acopioNombre { get; set; }
        public double acopioLongitud { get; set; }
        public double acopioLatitud { get; set; }
        public int tipoAcopioID { get; set; }
    }
}
