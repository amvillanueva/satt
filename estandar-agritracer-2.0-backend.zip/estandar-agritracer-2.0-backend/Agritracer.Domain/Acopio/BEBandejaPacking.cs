﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.Acopio
{
    public class BEBandejaPacking : BEMaster
    {
        public int bandejaPackingID { get; set; }
        public string bandejaPackingCodigo { get; set; }
        public string bandejaPackingNombre { get; set; }
        public string bandejaPackingAbreviatura { get; set; }
        public decimal bandejaPackingPeso { get; set; }
        public int cultivoID { get; set; }
    }
}
