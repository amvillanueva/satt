﻿using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;

namespace Agritracer.Domain.Acopio
{
    public class BEDespachoAcopio : BEMaster
    {
        public int despachoAcopioID { get; set; }
        public int empresaID { get; set; }
        public string empresaNombre { get; set; }
        public int acopioID { get; set; }
        public string acopioNombre { get; set; }
        public DateTime despachoAcopioFecha { get; set; }
        public string despachoAcopioFechaStr { get; set; }
        public int vehiculoID { get; set; }
        public string vehiculoPlaca { get; set; }
        public int conductorID { get; set; }
        public string conductorDocumento { get; set; }
        public string conductorNombre { get; set; }
        public string conductorLicencia { get; set; }
        public int despachoAcopioNroViaje { get; set; }
        public int despachoAcopioCantidad { get; set; }
        public decimal despachoAcopioPeso { get; set; }
        public decimal despachoAcopioKilosIndustrial { get; set; }
        public int despachoAcopioEstadoID { get; set; }
        public string despachoAcopioEstadoNombre { get; set; }
        public int tablaDetalleID { get; set; }
        public string nombreTablaD { get; set; }
        public string clienteNombre { get; set; }
        public string guiaRemision { get; set; }

        public List<BEDespachoAcopioDetalle> despachoAcopioDetalle { get; set; }

        public BEDespachoAcopio()
        {
            despachoAcopioDetalle = new List<BEDespachoAcopioDetalle>();
        }
    }
}
