﻿using Agritracer.Domain.Common;
using System;

namespace Agritracer.Domain.Acopio
{
    public class BEDespachoAcopioDetalle : BEMaster
    {
        public int despachoAcopioDetalleID { get; set; }
        public int despachoAcopioID { get; set; }
        public int palletID { get; set; }
        public string palletCodigo { get; set; }
        public int moduloID { get; set; }
        public string moduloNombre { get; set; }
        public int variedadID { get; set; }
        public string variedadNombre { get; set; }
        public int bandejaPackingID { get; set; }
        public string bandejaPackingNombre { get; set; }
        public int bandejaAcopioDetalleCantidad { get; set; }
        public decimal bandejaAcopioDetallePeso { get; set; }
        public int bandejaAcopioDetalleEstadoID { get; set; }
        public string bandejaAcopioDetalleEstadoNombre { get; set; }
    }
}
