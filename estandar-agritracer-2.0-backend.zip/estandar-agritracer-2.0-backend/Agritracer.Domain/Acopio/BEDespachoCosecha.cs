﻿using Agritracer.Domain.Common;
using System;

namespace Agritracer.Domain.Acopio
{
    public class BEDespachoCosecha : BEMaster
    {
        public int despachoCosechaID { get; set; }
        public int empresaID { get; set; }
        public string empresaNombre { get; set; }
        public DateTime despachoCosechaFecha { get; set; }
        public string despachoCosechaFechaStr { get; set; }
        public int moduloID { get; set; }
        public string moduloNombre { get; set; }
        public int variedadID { get; set; }
        public string variedadNombre { get; set; }
        public int turnoID { get; set; }
        public string turnoNombre { get; set; }
        public int bandejaCosechaID { get; set; }
        public string bandejaCosechaNombre { get; set; }
        public int vehiculoID { get; set; }
        public string vehiculoPlaca { get; set; }
        public int conductorID { get; set; }
        public string conductorDocumento { get; set; }
        public string conductorNombre { get; set; }
        public string conductorLicencia { get; set; }
        public int despachoCosechaCantEnviada { get; set; }
        public decimal despachoCosechaPesoEnviado { get; set; }
        public int despachoCosechaCantRecibida { get; set; }
        public decimal despachoCosechaPesoRecibido { get; set; }
        public int despachoCosechaNroJarraIndustrial { get; set; }
        public int tipoAcopioID { get; set; }
        public string tipoAcopioNombre { get; set; }
        public int destinoID { get; set; }
        public string destinoNombre { get; set; }
        public int despachoCosechaEstadoID { get; set; }
        public string despachoCosechaEstadoNombre { get; set; }

        public int jarrasIndustrialEstadoID { get; set; }
        public string jarrasIndustrialEstadoNombre { get; set; }
        public int grupoTrabajoID { get; set; }
        
    }
}
