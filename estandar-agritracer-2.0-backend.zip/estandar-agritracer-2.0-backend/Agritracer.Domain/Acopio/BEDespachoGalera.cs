﻿using Agritracer.Domain.Common;
using System;

namespace Agritracer.Domain.Acopio
{
    public class BEDespachoGalera : BEMaster
    {
        public int despachoGaleraID { get; set; }
        public int empresaID { get; set; }
        public string empresaNombre { get; set; }
        public DateTime despachoGaleraFecha { get; set; }
        public string despachoGaleraFechaStr { get; set; }
        public int moduloID { get; set; }
        public string moduloNombre { get; set; }
        public int variedadID { get; set; }
        public string variedadNombre { get; set; }
        public int bandejaPackingID { get; set; }
        public string bandejaPackingNombre { get; set; }
        public int vehiculoID { get; set; }
        public string vehiculoPlaca { get; set; }
        public int conductorID { get; set; }
        public string conductorDocumento { get; set; }
        public string conductorNombre { get; set; }
        public string conductorLicencia { get; set; }
        public int despachoGaleraCantEnviada { get; set; }
        public decimal despachoGaleraPesoEnviado { get; set; }
        public int despachoGaleraCantRecibida { get; set; }
        public decimal despachoGaleraPesoRecibido { get; set; }
        public int origenID { get; set; }
        public string origenNombre { get; set; }
        public int destinoID { get; set; }
        public string destinoNombre { get; set; }
        public decimal despachoGaleraKilosIndustrial { get; set; }
        public int despachoGaleraEstadoID { get; set; }
        public string despachoGaleraEstadoNombre { get; set; }
    }
}
