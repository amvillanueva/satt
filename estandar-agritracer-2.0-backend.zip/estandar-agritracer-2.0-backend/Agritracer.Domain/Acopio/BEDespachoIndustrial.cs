﻿using Agritracer.Domain.Common;
using System;

namespace Agritracer.Domain.Acopio
{
    public class BEDespachoIndustrial : BEMaster
    {
        public int despachoIndustrialID { get; set; }
        public int empresaID { get; set; }
        public string empresaNombre { get; set; }
        public DateTime despachoIndustrialFecha { get; set; }
        //public string despachoCosechaFechaStr { get; set; }
        public int moduloID { get; set; }
        public string moduloNombre { get; set; }
        public int variedadID { get; set; }
        public string variedadNombre { get; set; }
        public int despachoIndustrialCantJabas { get; set; }
        public decimal despachoIndustrialPeso { get; set; }
        public string procedenciaNombre { get; set; }
        public int despachoIndustrialEstadoID { get; set; }
        public string despachoIndustrialEstadoNombre { get; set; }
        public string procedencia { get; set; }
    }
}
