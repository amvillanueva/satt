﻿using Agritracer.Domain.Common;
using System;

namespace Agritracer.Domain.Acopio
{
    public class BEDespachoIndustrialAcopio : BEMaster
    {
        public int despachoIndustrialAcopioID { get; set; }
        public int empresaID { get; set; }
        public string empresaNombre { get; set; }
        public DateTime despachoIndustrialAcopioFecha { get; set; }
        public int vehiculoID { get; set; }
        public int conductorID { get; set; }
        public int moduloID { get; set; }
        public string moduloNombre { get; set; }
        public int variedadID { get; set; }
        public string variedadNombre { get; set; }
        public int totalJabasIndustrialesAcopio { get; set; }
        public int despachoIndustrialANroJarraIndustrial { get; set; }
        public int despachoIndustrialAcopioEstadoID { get; set; }
        public string login { get; set; }
        public string host { get; set; }
        public string version { get; set; }
        public int nro { get; set; }
    }
}
