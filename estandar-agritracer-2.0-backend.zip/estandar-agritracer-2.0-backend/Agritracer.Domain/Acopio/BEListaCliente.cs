﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Acopio
{
    public class BEListaCliente
    {
        public string nombre { get; set; }
    }
}
