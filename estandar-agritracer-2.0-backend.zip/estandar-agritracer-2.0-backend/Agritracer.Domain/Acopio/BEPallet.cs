﻿using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;

namespace Agritracer.Domain.Acopio
{
    public class BEPallet : BEMaster
    {
        public int palletID { get; set; }
        public int empresaID { get; set; }
        public string empresaNombre { get; set; }
        public int acopioID { get; set; }
        public string acopioNombre { get; set; }
        public DateTime palletFecha { get; set; }
        public string palletFechaStr { get; set; }
        public string palletCodigo { get; set; }
        public int bandejaPackingID { get; set; }
        public string bandejaPackingNombre { get; set; }
        public decimal palletPeso { get; set; }
        public int palletEstadoID { get; set; }
        public int palletEstadoNombre { get; set; }
        public List<BEPalletDetalle> palletDetalle { get; set; }

        public BEPallet()
        {
            palletDetalle = new List<BEPalletDetalle>();
        }
    }
}
