﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.Acopio
{
    public class BEPalletDetalle : BEMaster
    {
        public int palletDetalleID { get; set; }
        public int palletID { get; set; }
        public string tipo { get; set; }
        public int moduloID { get; set; }
        public string moduloNombre { get; set; }
        public int turnoID { get; set; }
        public string turnoNombre { get; set; }
        public int variedadID { get; set; }
        public string variedadNombre { get; set; }
        public int palletCantidad { get; set; }
    }
}
