﻿using Agritracer.Domain.Common;
using System;

namespace Agritracer.Domain.Acopio
{
    public class BERecepcionAcopio : BEMaster
    {
        public int despachoCosechaID { get; set; }
        public int empresaID { get; set; }
        public string empresaNombre { get; set; }
        public DateTime recepcionAcopioFecha { get; set; }
        public string recepcionAcopioFechaStr { get; set; }
        public int moduloID { get; set; }
        public string moduloNombre { get; set; }
        public int turnoID { get; set; }
        public string turnoNombre { get; set; }
        public int variedadID { get; set; }
        public string variedadNombre { get; set; }
        public int formatoID { get; set; }
        public string formatoNombre { get; set; }
        public int vehiculoID { get; set; }
        public string vehiculoPlaca { get; set; }
        public int conductorID { get; set; }
        public string conductorDocumento { get; set; }
        public string conductorNombre { get; set; }
        public string conductorLicencia { get; set; }
        public int recepcionAcopioCantEnviada { get; set; }
        public decimal recepcionAcopioPesoEnviado { get; set; }
        public int recepcionAcopioCantRecibida { get; set; }
        public decimal recepcionAcopioPesoRecibido { get; set; }
        public int origenID { get; set; }
        public string origenNombre { get; set; }
        public int destinoID { get; set; }
        public string destinoNombre { get; set; }
        public int origenTipoAcopioID { get; set; }
        public int recepcionAcopioEstadoID { get; set; }
        public string recepcionAcopioEstadoNombre { get; set; }

        public int grupoTrabajoID { get; set; }
        public string descripcionGrupoTrabajo { get; set; }
    }
}
