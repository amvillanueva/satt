﻿using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;

namespace Agritracer.Domain.Acopio
{
    public class BERecepcionAcopioCabecera : BEMaster
    {
        public int despachoCosechaID { get; set; }
        public int recepcionAcopioID { get; set; }
        public DateTime recepcionAcopioFecha { get; set; }
        public string vehiculoQR { get; set; }
        public int vehiculoID { get; set; }
        public int conformidadJabas { get; set; }
        public string observacion { get; set; }
        public List<BERecepcionAcopio> recepcionAcopioDetalle { get; set; }

    }
}
