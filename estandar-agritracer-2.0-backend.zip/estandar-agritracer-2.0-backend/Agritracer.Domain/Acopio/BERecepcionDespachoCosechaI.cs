﻿using Agritracer.Domain.Common;
using System;

namespace Agritracer.Domain.Acopio
{
    public class BERecepcionDespachoCosechaI : BEMaster
    {
        public int despachoCosechaID { get; set; }
        public int empresaID { get; set; }
        public string empresaNombre { get; set; }
        public DateTime recepciondespachoCosechaFechaStr { get; set; }
        public string recepcionAcopioFechaStr { get; set; }
        public string recepciondespachoCosechaFecha { get; set; }
        public int moduloID { get; set; }
        public string moduloNombre { get; set; }
        public int turnoID { get; set; }
        public string turnoNombre { get; set; }
        public int variedadID { get; set; }
        public string variedadNombre { get; set; }
        public int bandejaCosechaID { get; set; }
        public string bandejaCosechaNombre { get; set; }
        public int vehiculoID { get; set; }
        public string vehiculoPlaca { get; set; }
        public int conductorID { get; set; }
        public string conductorDocumento { get; set; }
        public string conductorNombre { get; set; }
        public string conductorLicencia { get; set; }
        public int recepcionDespachoCosechaCantEnviada { get; set; }
        public decimal recepcionDespachoCosechaPesoEnviado { get; set; }
        public int recepcionDespachoCosechaCantRecibida { get; set; }
        public decimal recepcionDespachoCosechaPesoRecibido { get; set; }
        public int recepcionDespachoCosechaNroJabasIndustriales { get; set; }
        public int tipoAcopioID { get; set; }
        public string tipoAcopioNombre { get; set; }
        public int destinoID { get; set; }
        public string destinoNombre { get; set; }
        public int recepcionIndustrialDCEstadoID { get; set; }
        public string recepcionIndustrialDCEstadoNombre { get; set; }
    
        public int grupoTrabajoID { get; set; }
        public string grupoTrabajoNombre { get; set; }

        public int recepcionJarraIndustrialEstadoID { get; set; }
        public string recepcionJarraIndustrialEstadoNombre { get; set; }

        public int origenID { get; set; }
        public int origenTipoAcopioID { get; set; }
        public string origenNombre { get; set; }
        public int formatoID { get; set; }
        public string formatoNombre { get; set; }


    }
}
