﻿using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;

namespace Agritracer.Domain.Acopio
{
    public class BERecepcionIndustrial : BEMaster
    {
        public int despachoCosechaID { get; set; }
        public int recepcionIndustrialID { get; set; }
        public DateTime recepcionIndustrialFecha { get; set; }
        public string vehiculoQR { get; set; }
        public int vehiculoID { get; set; }
        public int conformidadJabas { get; set; }
        public string observacion { get; set; }
        public List<BERecepcionDespachoCosechaI> recepcionIndustrialDetalle { get; set; }

    }
}
