﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.Acopio
{
    public class BETipoAcopio : BEMaster
    {
        public int tipoAcopioID { get; set; }
        public string tipoAcopioNombre { get; set; }
    }
}
