﻿using System;

namespace Agritracer.Domain.Acopio.Movil
{
    public class BEDashboardAcopio
    {
        public int codigo { get; set; }
        public string item { get; set; }
        public int cantidad { get; set; }
        public decimal peso { get; set; }
    }
}
