﻿using Agritracer.Domain.Cosecha;
using Agritracer.Domain.Cosecha.Maestros;
using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;

namespace Agritracer.Domain.Acopio.Movil
{
    public class BEDataMaestraAcopio
    {
        public List<BEAcopio> acopios { get; set; }
        public List<BETipoAcopio> tipoAcopios { get; set; }
        public List<BEBandejaCosecha> bandejasCosecha { get; set; }
        public List<BEBandejaPacking> bandejasPacking { get; set; }
        public List<BEVariedad> variedades { get; set; }
        public List<BETurno> turnos { get; set; }
        public List<BEModulo> modulos { get; set; }
        public List<BEVehiculo> vehiculos { get; set; }
        public List<BEConductor> conductores { get; set; }
        public List<BEDespachoCosecha> despachosCosecha { get; set; }
        public List<BEDespachoGalera> despachosGalera { get; set; }
        public List<BEPallet> pallets { get; set; }
        public List<BEPalletDetalle> palletsDetalle { get; set; }
        public List<BEDespachoAcopio> despachosAcopio { get; set; }
        public List<BEDespachoAcopioDetalle> despachosAcopioDetalle { get; set; }
        public List<BEListaPacking> listaPacking { get; set; }
        public List<BEListaCliente> listaClientes { get; set; }

        public BEDataMaestraAcopio()
        {
            acopios = new List<BEAcopio>();
            tipoAcopios = new List<BETipoAcopio>();
            bandejasCosecha = new List<BEBandejaCosecha>();
            bandejasPacking = new List<BEBandejaPacking>();
            variedades = new List<BEVariedad>();
            turnos = new List<BETurno>();
            modulos = new List<BEModulo>();
            vehiculos = new List<BEVehiculo>();
            conductores = new List<BEConductor>();
            despachosCosecha = new List<BEDespachoCosecha>();
            despachosGalera = new List<BEDespachoGalera>();
            pallets = new List<BEPallet>();
            palletsDetalle = new List<BEPalletDetalle>();
            despachosAcopio = new List<BEDespachoAcopio>();
            despachosAcopioDetalle = new List<BEDespachoAcopioDetalle>();
            listaPacking = new List<BEListaPacking>();
            listaClientes = new List<BEListaCliente>();
        }
    }
}
