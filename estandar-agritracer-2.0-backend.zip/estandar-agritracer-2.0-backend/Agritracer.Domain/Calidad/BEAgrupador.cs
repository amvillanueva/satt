﻿using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Calidad
{
    public class BEAgrupador : BEMaster
    {
        public int configuracionID { get; set; }
        public string configuracionNombre { get; set; }
        public int tipoConfiguracionID { get; set; }
        public string tipoConfiguracionNombre { get; set; }
        public int cultivoID { get; set; }
        public int cantidadCodigos { get; set; }
        public string configuracionIdentificadores { get; set; }
        public bool status { get; set; }
    }
}
