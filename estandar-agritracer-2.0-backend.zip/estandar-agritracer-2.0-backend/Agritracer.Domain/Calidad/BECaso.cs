﻿using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Calidad
{
    public class BECaso : BEMaster
    {
        public int casoID { get; set; }
        public int subclienteID { get; set; }
        public int variedadID { get; set; }
        public string casoNombre { get; set; }
        public string casoDescripcion { get; set; }
        public List<BECasoDetalle> casoListaDetalle { get; set; }
    }
}
