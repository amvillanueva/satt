﻿
namespace Agritracer.Domain.Calidad
{
    public class BECasoDetalle
    {
        public int casodetalleID { get; set; }
        public string cadeNombre { get; set; }
        public int cadeNumero { get; set; }
        public string cadeArrayCondicion { get; set; }
        public string cadeMensaje { get; set; }
        public string cadeColor { get; set; }
        public int cadeAccionID { get; set; }
        public string cadeAccionNombre { get; set; }
        public int variedadID { get; set; }
        public int subclienteID { get; set; }
        public string cadeLoteIDs { get; set; }
        public int cadeLotesCount { get; set; }

    }
}
