﻿using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Calidad
{
    public class BEClienteCalidad : BEMaster
    {
        public int clienteID { get; set; }
        public int clienteIDTemp { get; set; }
        public string clienteNombre { get; set; }
    }

    public class BESubClienteCalidad : BEMaster
    {
        public int clienteID { get; set; }
        public int subclienteID { get; set; }
        public int subclienteIDTemp { get; set; }
        public string subclienteNombre { get; set; }
    }

    public class BESubClienteVariedad : BEMaster
    {
        public int subclienteID { get; set; }
        public int variedadID { get; set; }
    }

    public class BEClienteSubclientePOST : BEMaster
    {
        public List<BEClienteCalidad> clientes { get; set; }
        public List<BESubClienteCalidad> subclientes { get; set; }
        public List<BESubClienteVariedad> variedades { get; set; }
    }
}
