﻿using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Calidad
{
    public class BEEvaluacion : BEMaster
    {
        public int evaluacionID { get; set; }
        public int empresaID { get; set; }
        public string evaluacionNombre { get; set; }
        public string evaluacionDescripcion { get; set; }
        public int evaluacionCantidadMuestreos { get; set; }
        public int cultivoID { get; set; }
        public string cultivoNombre { get; set; }
        public int tipoGrupoID { get; set; }
        public string tipoGrupoNombre { get; set; }
        public bool evaluacionLecturaQR { get; set; }
        public bool evaluacionLecturaNFC { get; set; }
        public bool evaluacionLecturaManual { get; set; }
        public bool evaluacionMostrarSupervisor { get; set; }
        public bool evaluacionMostrarCliente { get; set; }
        public bool evaluacionMostrarNPlanta { get; set; }
        public List<BEEvento> listaEventos { get; set; }
        public List<BEFormula> listaFormulas { get; set; }
        public bool evaluacionEdicionMovil { get; set; }
        public bool chkLoteVariedad { get; set; }
        public string evaluacionTipoGrupo { get; set; }
        public bool mostrarSupervisor { get; set; }
        public bool mostrarPlantas { get; set; }
        public bool mostrarCliente { get; set; }

        public bool lecturarQrFlag { get; set; }

        public bool obtenerInfoCosecha { get; set; }
    }
}
