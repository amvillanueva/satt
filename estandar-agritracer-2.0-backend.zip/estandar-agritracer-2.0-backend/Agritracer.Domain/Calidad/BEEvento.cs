﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Calidad
{
    public class BEEvento
    {
        public int eventoID { get; set; }
        public int evaluacionID { get; set; }
        public string eventoNombre { get; set; }
        public string eventoDescripcion { get; set; }
        public int eventoTotalItems { get; set; }
        public int eventoNroItemsPagina { get; set; }
        public bool eventoEdicionWeb { get; set; }
        public bool eventoEdicionMovil { get; set; }
        public bool eventoMuestreo { get; set; }
        public int tipoMuestreoID { get; set; }
        public string tipoMuestreoNombre { get; set; }
        public List<BEItem> eventoListaItems { get; set; }
    }
}
