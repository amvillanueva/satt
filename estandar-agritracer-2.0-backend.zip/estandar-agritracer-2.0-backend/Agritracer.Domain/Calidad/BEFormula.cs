﻿using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Calidad
{
    public class BEFormula : BEMaster
    {
        public int formulaID { get; set; }
        public int evaluacionID { get; set; }
        public string evaluacionNombre { get; set; }
        public string formulaNombre { get; set; }
        public string formulaArrayElementos { get; set; }
        public int casoID { get; set; }
        public string casoNombre { get; set; }
        public List<BECasoDetalle> casoListaDetalle { get; set; }
        public int tipoNotificacionID { get; set; }
        public string tipoNotificacionNombre { get; set; }
        public int itemID { get; set; }
        public string itemNombre { get; set; }
    }
}
