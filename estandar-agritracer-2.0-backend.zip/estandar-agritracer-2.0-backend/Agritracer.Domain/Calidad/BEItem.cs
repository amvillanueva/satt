﻿using System.Collections.Generic;

namespace Agritracer.Domain.Calidad
{
    public class BEItem
    {
        public int itemID { get; set; }
        public int eventoID { get; set; }
        public string itemNombre { get; set; }
        public string itemDescripcion { get; set; }
        public int itemOrden { get; set; }
        public int tipoItemID { get; set; }
        public string tipoItemNombre { get; set; }
        public string itemFileName { get; set; }
        public string itemFileNameAux { get; set; }
        public string itemFileUrl { get; set; }
        public bool itemImageMovil { get; set; }
        public bool chkFijo { get; set; }
        public bool chkJustificado { get; set; }
        public bool chkRequerido { get; set; }
        public bool chkAcumulativo { get; set; }
        public bool chkRptResumen { get; set; }
        public bool chkImagenMovil { get; set; }
        public bool chkBloqueado { get; set; }
        public List<string> itemListaValores { get; set; }
    }

}
