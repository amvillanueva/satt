﻿using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Agritracer.Domain.Calidad
{
    public class BEResponseLoginADR
    {
        public int usuarioID { get; set; }
        public string mensajeRpta { get; set; }
        public string usuarioPassword { get; set; }
        public string usuarioLogin { get; set; }
        public bool estado { get; set; }
        public string usuarioToken { get; set; }
    }

    public class BEResponsePallets
    {
        public string empresa { get; set; }
        public string fechaPaleta { get; set; }
        public string numPaleta { get; set; }
        public string numNisira { get; set; }
        public string codCampana { get; set; }
        public string cajas { get; set; }
        public string contenedor { get; set; }
        public string ie { get; set; }
        public string consignatario { get; set; }
    }

    public class BEEvaluacionPackingMin
    {
        public int registroEvaluacionID { get; set; }
        public string codigoLecturado { get; set; }
        public string pallet { get; set; }
        public string contenedor { get; set; }
    }

    public class BEPackingReporteResponse
    {
        public List<BEEvaluacionPackingMin> palletsCodigos { get; set; }
        public DataSet resultTables { get; set; }
    }
}
