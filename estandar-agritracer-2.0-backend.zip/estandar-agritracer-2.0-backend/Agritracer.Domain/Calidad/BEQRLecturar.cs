﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Calidad
{
    public class BEQRLecturar
    {
        public string codTrabajador { get; set; }
        public string trabajador { get; set; }
        public string cuadrilla { get; set; }
        public int supervisorId { get; set; }
        public string supervisor { get; set; }
        public int moduloId { get; set; }
        public string modulo { get; set; }
        public int turnoId { get; set; } 
        public string turno { get; set; }
        public string variedadDescripcion { get; set; }
        public int variedadId { get; set; }
    }
}
