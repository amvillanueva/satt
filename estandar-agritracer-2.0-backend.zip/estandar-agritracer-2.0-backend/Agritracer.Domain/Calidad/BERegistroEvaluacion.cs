﻿using Agritracer.Domain.Calidad.Maestros;
using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Calidad
{
    public class BERegistroEvaluacion : BEMaster
    {
        public int registroEvaluacionID { get; set; }
        public int evaluacionID { get; set; }
        public string evaluacionNombre { get; set; }
        public int evaluacionCantidadMuestreos { get; set; }
        public string reevFecha { get; set; }
        public int cultivoID { get; set; }
        public string cultivoNombre { get; set; }
        public int usuarioID { get; set; }
        public int loteID { get; set; }
        public string loteNombre { get; set; }
        public int variedadID { get; set; }
        public string variedadNombre { get; set; }
        public int supervisorID { get; set; }
        public string supervisorNombre { get; set; }
        public double reevLongitud { get; set; }
        public double reevLatitud { get; set; }
        public List<BERegistroEvaluacionDetalle> detalle { get; set; }
        public Dictionary<Int32, List<BEFotoEvaluacion>> images { set; get; }
        public string codigo_lecturado { get; set; }
        public int nroPlantas { get; set; }
        public int clienteID { get; set; }
        public int subclienteID { get; set; }

        //ELIAS
        public int moduloID { get; set; }
        public string moduloNombre { get; set; }
    }
}
