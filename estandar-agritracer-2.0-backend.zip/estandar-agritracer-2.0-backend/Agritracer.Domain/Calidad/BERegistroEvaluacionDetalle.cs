﻿using Agritracer.Domain.Calidad.Maestros;
using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Calidad
{
    public class BERegistroEvaluacionDetalle
    {
        public int registroEvaluacionDetalleID { get; set; }
        public int registroEvaluacionID { get; set; }
        public int evaluacionCantidadMuestreos { get; set; }
        public int reedNroMuestra { get; set; }
        public int tipoItemID { get; set; }
        public string tipoItemNombre { get; set; }
        public int eventoID { get; set; }
        public string eventoNombre { get; set; }
        public int itemID { get; set; }
        public string itemNombre { get; set; }
        //public string reedItemCodigo { get; set; }
        public string reedItemValor { get; set; }
        public List<string> itemListaValores { get; set; }
        public Dictionary<Int32, List<BEFotoEvaluacion>> images { set; get; }
    }
}
