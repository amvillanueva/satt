﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Calidad.Maestros
{
    public class BEFotoEvaluacion
    {
        public string imagen { get; set; }
        public string comentario { get; set; }
    }
}
