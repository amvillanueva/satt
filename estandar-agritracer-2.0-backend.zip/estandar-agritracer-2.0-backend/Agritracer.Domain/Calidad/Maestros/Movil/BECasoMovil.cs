﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Calidad.Maestros.Movil
{
    public class BECasoMovil 
    {
        public int casoID { get; set; }
        public string casoNombre { get; set; }
        public int casoDetalleID { get; set; }
        public string casoCondicion { get; set; }
        public string casoMensaje { get; set; }
        public string casoColor { get; set; }
        public int casoAccionID { get; set; }
        public string casoAccionNombre { get; set; }
        public string loteId { get; set; }
        public int casoSubclienteID { get; set; }
        public int casoVariedadID { get; set; }
    }
}
