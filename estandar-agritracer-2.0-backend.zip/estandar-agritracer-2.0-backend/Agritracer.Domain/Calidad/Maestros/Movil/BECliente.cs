﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Calidad.Maestros.Movil
{
    public class BECliente
    {
        public int clienteId { get; set; }
        public string clienteNombre { get; set; }
    }
}
