﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Calidad.Maestros.Movil
{
    public class BECultivoMovil
    {
        public int cultivoID { get; set; }
        public string cultivoNombre { get; set; }
    }
}
