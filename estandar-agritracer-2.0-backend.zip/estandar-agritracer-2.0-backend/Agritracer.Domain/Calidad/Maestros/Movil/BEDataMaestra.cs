﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Calidad.Maestros.Movil
{
    public class BEDataMaestra
    {
        public List<BECultivoMovil> cultivos { get; set; }
        public List<BEEvaluacion> evaluacion { get; set; }
        public List<BEEvento> evento { get; set; }
        public List<BEItem> items { get; set; }
        public List<BEFormula> formulas { get; set; }
        public List<BECasoMovil> casos { get; set; }
        public List<BELoteMovil> lotes { get; set; }
        public List<BESupervisorMovil> supervisores { get; set; }
        public List<BECliente> clientes { get; set; }
        public List<BESubcliente> subclientes { get; set; }
    }
}
