﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Calidad.Maestros.Movil
{
    public class BESubcliente
    {
        public int subclienteId { get; set; }
        public int clienteId { get; set; }
        public string variedadId { get; set; }
        public string subclienteNombre { get; set; }
    }
}
