﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Calidad.Maestros.Movil
{
    public class BESupervisorMovil
    {
        public int trabajadorId { get; set; }
        public String trabajadorCodigo { get; set; }
        public String trabajadorNombre { get; set; }
    }
}
