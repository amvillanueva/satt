﻿using Agritracer.Domain.Common.Maestros;
using Agritracer.Domain.Cosecha.Procesos.Movil;
using Agritracer.Domain.Cosecha.Proyecciones;
using Agritracer.Domain.ManoObra.Maestros;
using Agritracer.Domain.ManoObra.Procesos;
using System;
using System.Collections.Generic;
using BEPersona = Agritracer.Domain.Configuracion.Maestros.BEPersona;

namespace Agritracer.Domain.Common
{
    public class BEArgs : BEMaster
    {
        public string vehiculoIndustrialID { get; set; }
       
        public int empresaID { get; set; }
        public int fundoID { get; set; }
        public int moduloID { get; set; }
        public int turnoID { get; set; }
        public int loteID { get; set; }
        public int option { get; set; }
        public int valorID { get; set; }
        public List<int> codigos { get; set; }
        public string descripcion { get; set; }
        public int cultivoID { get; set; }
        public int acopioID { get; set; }
        public int actividadID { get; set; }
        public int supervisorID { get; set; }
        public int planillaID { get; set; }
        public DateTime? fecha { get; set; }
        public int eventoID { get; set; }
        public DateTime fechaIni { get; set; }
        public DateTime fechaFin { get; set; }
        public int trabajadorID { get; set; }
        public string legajo { get; set; }
        public string fechaStr { get; set; }
        public string grupoTrabajo { get; set; }
        public int usuarioID { get; set; }
        public int perfilID { get; set; }
        public int semanaID { get; set; }
        public int comedorID { get; set; }
        public int zonaID { get; set; }
        public int status { get; set; }
        public int tipoReporte { get; set; }
        public int zonaProcedenciaID { get; set; }
        public string codigo { get; set; }
        public int tipo { get; set; }
        public int tipoAlmuerzo { get; set; }
        public int vehiculoID { get; set; }
        public int flagPacking { get; set; }
        public int flag { get; set; }
        public int trcoID { get; set; }
        public List<BEProyeccion> listadoProyecciones { get; set; }
        public int accion { get; set; }
        public bool labores { get; set; }
        public bool almuerzo { get; set; }
        public bool cena { get; set; }
        public List<BEProcesoPallet> listadoProcesosPallet { get; set; }
        public string param01 { get; set; }
        public string param02 { get; set; }
        public string param03 { get; set; }
        public int personaVacuna { get; set; }
        public string[] headersExport { get; set; }
        public int[] columnSizeExport { get; set; }
        public string[] dataTypeExport { get; set; }
        public string[][] dataExport { get; set; }
        public string grupo { get; set; }
        public List<BETransporteCosechaDetalle> detalleTransporteCosecha { get; set; }
        public int grupoActividadID { get; set; }
        public int tipoActividadID { get; set; }
        public int centroCostoID { get; set; }
        public List<BEImpresionFotocheck> listadoImpresionFotocheck { get; set; }
        public string zona { get; set; }
        public List<BETrabajador> listadoTrabajadores { get; set; }
        public string[] legajos { get; set; }

        public int tipoRegistro { get; set; }
        public string fechapersonal { get; set; }
        public string tarifanormal { get; set; }
        public string tarifa1 { get; set; }
        public string tarifa2 { get; set; }
        public string fechaviaje { get; set; }
        public string tarifakiacam { get; set; }
        public string tarifacamioneta { get; set; }
        public string tarifathermoking { get; set; }

        public string fechathermoking { get; set; }
        public string nrothermoking { get; set; }
        public string nroviajes { get; set; }

        public int estadoID { get; set; }
        public int grupoTrabajoID { get; set; }
        public int paraderoID { get; set; }
        public string usuarioToken { get; set; }
        public string usuarioName { get; set; }
        public string imei { get; set; }
        public string mensaje { get; set; }
        public double cantidad { get; set; }
        public string ciclo { get; set; }
        public string fotos { get; set; }
        public int formatoID { get; set; }
        public int variedadID { get; set; }
        public string variedadDescripcion { get; set; }
        public List<BEPlanillaTareo> planillas { get; set; }

        public int grupotrabajoID { get; set; }
        public string cargo { get; set; }
        public string dni { get; set; }
        public int orden { get; set; }

        public List<BEPersona> listadoPersonas { get; set; }
        public List<string> nroDocumentos { get; set; }
        public string actividadDescripcion { get; set; }
        public DateTime? fechaFiltro { get; set; }
        public int usuarioWebID { get; set; }
       
        public string tipoproyectoID { get; set; }
        public int puntoControlID { get; set; }
        public string jsonData { get; set; }
    }
}
