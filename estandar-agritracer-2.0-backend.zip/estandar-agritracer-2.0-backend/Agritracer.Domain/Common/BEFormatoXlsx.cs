﻿using System.Data;
using System.Collections.Generic;

namespace Agritracer.Domain.Common
{
    public class BEFormatoXlsx
    {
        public int formato_id { get; set; }
        public string nro_registro { get; set; }
        public int procesar { get; set; }

        //public List<Dictionary<string, object>> lista_items { get; set; }   //lista valores Excel
        public List<IEnumerable<string>> lista_items { get; set; }
        public DataTable lista_records { get; set; } //lista registros validados en sp
    }
}
