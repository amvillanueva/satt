﻿using System;

namespace Agritracer.Domain.Common
{
    public class BEMaster
    {
        public int id { get; set; }
        public int nro { get; set; }
        public string login { get; set; }
        public string host { get; set; }
        public string version { get; set; }
    }
}
