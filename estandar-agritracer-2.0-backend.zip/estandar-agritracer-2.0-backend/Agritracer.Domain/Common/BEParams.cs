﻿using System.Collections.Generic;

namespace Agritracer.Domain.Common
{
    public class BEParams
    {
        public int actionID { get; set; }
        public string actionName { get; set; }

        public Dictionary<string, object> valuePairs { get; set; }
    }
}
