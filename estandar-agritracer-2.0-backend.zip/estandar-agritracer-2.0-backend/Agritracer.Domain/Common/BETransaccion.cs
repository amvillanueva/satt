﻿using System.Collections.Generic;

namespace Agritracer.Domain.Common
{
    public class BETransaccion
    {
        public List<int> codigos { get; set; }
        public int usuarioID { get; set; }
        public string hostName { get; set; }
    }
}
