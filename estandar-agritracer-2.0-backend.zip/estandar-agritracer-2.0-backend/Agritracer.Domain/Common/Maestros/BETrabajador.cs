﻿namespace Agritracer.Domain.Common.Maestros
{
    public class BETrabajador : BEMaster
    {
        public int trabajadorID { get; set; }
        public string trabajadorLegajo { get; set; }
        public string trabajadorNroDocumento { get; set; }
        public string trabajadorApellidoPaterno { get; set; }
        public string trabajadorApellidoMaterno { get; set; }
        public string trabajadorNombres { get; set; }
        public string trabajadorNombreCompleto{ get; set; }
        public string trabajadorFechaIngreso { get; set; }
        public string trabajadorFechaSalida { get; set; }
        public string planillaNombre { get; set; }
        public int empresaID { get; set; }
        public string empresaNombre { get; set; }
        public bool trabajadorAgrupado { get; set; }
        public bool status { get; set; }
        public string trabajadorUsuario { get; set; }
        public int trabajadorIdServidor { get; set; }
        public string trabajadorMsgServidor { get; set; }
        public bool trabajadorEsOperador { get; set; }
        public bool trabajadorEsLavamano { get; set; }
        public int trabajadorCantidad { get; set; }
        public bool trabajadorImpreso { get; set; }
        public bool trabajadorImprimir { get; set; }
        public int zonaProcedenciaID { get; set; }
        public string zonaProcedenciaNombre { get; set; }
        public string fechaIngresoGrupo { get; set; }
        public string tipoAlmuerzo { get; set; }
        public int trabajadorSexoID { get; set; }
        public string trabajadorSexo { get; set; }
        public string trabajadorTipoEmpleado { get; set; }
        public string errores { get; set; }
        public string trabajadorPlaca { get; set; }
        public string trabajadorFechaCese { get; set; }
    }
}
