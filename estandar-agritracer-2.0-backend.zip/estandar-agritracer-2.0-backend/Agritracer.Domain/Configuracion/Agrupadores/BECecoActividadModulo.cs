﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.Configuracion.Agrupadores
{
    public class BECecoActividadModulo : BEMaster
    {
        public int cecoActividadModuloID { get; set; }
        public int centroCostoID { get; set; }
        public string centroCostoCodigo { get; set; }
        public string centroCostoNombre { get; set; }
        public int grupoActividadID { get; set; }
        public string grupoActividadCodigo { get; set; }
        public string grupoActividadNombre { get; set; }
        public int moduloID { get; set; }
        public string moduloCodigo { get; set; }
        public string moduloNombre { get; set; }
        public int empresaID { get; set; }
        public string empresaNombre { get; set; }
        public bool status { get; set; }
    }
}