﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.Configuracion.Maestros
{
    public class BEActividad : BEMaster
    {
        public int actividadID { get; set; }
        public int empresaID { get; set; }
        public string empresaNombre { get; set; }
        public int grupoActividadID { get; set; }
        public string grupoActividadNombre { get; set; }
        public string codigo { get; set; }
        public string nombre { get; set; }
        public string codigoSAP { get; set; }
        public int tipoActividadID { get; set; }
        public string tipoActividadNombre { get; set; }
        public int cuantitativa { get; set; }
        public int riesgo { get; set; }
        public int cualitativa { get; set; }
        public int cosecha { get; set; }
        public int poda { get; set; }
        public int centroCostoID { get; set; }
        public string centroCostoNombre { get; set; }
        public bool status { get; set; }


        public string actividadCodigo { get; set; }
        public string actividadNombre { get; set; }
        public bool actividadBono { get; set; }
        public int acttividadTipoBono { get; set; }
        public bool actividadRiesgo { get; set; }
        public bool actividadVisualizaLinea { get; set; }
        public bool actividadCualitativa { get; set; }
        public string centroCostoDescripcion { get; set; }
        public bool esPoda { get; set; }
        public string actividadUsuario { get; set; }
        public int actividadIDRptaServidor { get; set; }
        public string actividadMsgServidor { get; set; }
    }
}
