﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.Configuracion.Maestros
{
    public class BECentroCosto : BEMaster
    {
        public int centroCostoID { get; set; }
        public int empresaID { get; set; }
        public string empresaNombre { get; set; }
        public string codigo { get; set; }
        public string nombre { get; set; }
        public string codigoSAP { get; set; }
        public string fechaIni { get; set; }
        public string fechaFin { get; set; }
        public int directa { get; set; }
        public int visible { get; set; }
        public bool status { get; set; }

        public string centroCostoCodigo { get; set; }
        public string centroCostoDescripcion { get; set; }
        public bool centroCostoDirecta { get; set; }
        public bool centroCostoVisible { get; set; }
        public string centroCostoEstado { get; set; }
        public string centroCostoUsuario { get; set; }
        public int centroCostoIDRptaServidor { get; set; }
        public string centroCostoMsgServidor { get; set; }
    }
}
