﻿using Agritracer.Domain.Cosecha.Maestros;
using System.Collections.Generic;

namespace Agritracer.Domain.Configuracion.Maestros
{
    public class BEEmpresa
    {
        public int empresaID { get; set; }
        public string empresaCodigoERP { get; set; }
        public string empresaNombreCorto { get; set; }
        public string empresaRazonSocial { get; set; }
        public string empresaRUC { get; set; }
        public string empresaDireccion { get; set; }
        public string empresaImagen { get; set; }
        public string empresaColorFondo { get; set; }
        public string empresaLetraSticker { get; set; }
        public bool empresaSelect { get; set; }
        public List<BEEmpresaCultivo> empresaCultivos { get; set; }
        public string empresaCultivosStr { get; set; }
        public bool empresaStatus { get; set; }
        public string empresaUsuario { get; set; }
        public int empresaIDServidor { get; set; }
        public string empresaMsgServidor { get; set; }

        public BEEmpresa()
        {
            empresaCultivos = new List<BEEmpresaCultivo>();
        }
    }
}
