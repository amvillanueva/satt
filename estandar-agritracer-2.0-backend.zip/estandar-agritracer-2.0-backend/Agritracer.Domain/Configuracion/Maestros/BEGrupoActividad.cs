﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.Configuracion.Maestros
{
    public class BEGrupoActividad : BEMaster
    {
        public int grupoActividadID { get; set; }
        public string codigo { get; set; }
        public string nombre { get; set; }
        public string codigoSAP { get; set; }
        public bool status { get; set; }
    }
}
