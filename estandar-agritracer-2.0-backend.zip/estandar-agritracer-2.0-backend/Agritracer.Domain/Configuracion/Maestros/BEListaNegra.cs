﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.Configuracion.Maestros
{
    public class BEListaNegra : BEMaster
    {
        public int empresaID { get; set; }
        public int listaNegraID { get; set; }
        public int trabajadorID { get; set; }
        public string trabajadorDNI { get; set; }
        public string trabajadorNombre { get; set; }
        public string motivoListaNegra { get; set; }
        public string fechaRegistro { get; set; }
        public string fechaActualizacion { get; set; }
        public bool status { get; set; }
    }
}
