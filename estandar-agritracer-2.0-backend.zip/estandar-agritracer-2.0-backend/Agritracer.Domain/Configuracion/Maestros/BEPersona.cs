﻿using Agritracer.Domain.Common;
using System.Collections.Generic;

namespace Agritracer.Domain.Configuracion.Maestros
{
    public class BEPersona : BEMaster
    {
        public int personaID { get; set; }
        public int trabajadorID { get; set; }
        public int tipoDocumentoID { get; set; }
        public string tipoDocumentoNombre { get; set; }
        public string nroDocumento { get; set; }
        public int sexoID { get; set; }
        public string sexoNombre { get; set; }
        public string apellidoPaterno { get; set; }
        public string apellidoMaterno { get; set; }
        public string nombres { get; set; }
        public string direccion { get; set; }
        public string telefono { get; set; }
       

        public string fechaIngreso { get; set; }
        public string fechaCese { get; set; }
        public string motivoCese { get; set; }
        public string observaciones { get; set; }
        public string estado { get; set; }

        public string urlImagen { get; set; }
        public int zonaProcedenciaID { get; set; }
        public string zonaProcedenciaNombre { get; set; }
        public string placa { get; set; }
        public bool status { get; set; }
        public bool vacunaCovid { get; set; }
        public List<BETrabajadorPersona> listadoTrabajadores { get; set; }
    }
}
