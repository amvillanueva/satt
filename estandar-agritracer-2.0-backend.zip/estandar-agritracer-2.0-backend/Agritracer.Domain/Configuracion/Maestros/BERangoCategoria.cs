﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.Configuracion.Maestros
{
    public class BERangoCategoria : BEMaster
    {
        public int categoriaID { get; set; }
        public int tipoCategoriaID { get; set; }
        public string tipoCategoriaNombre { get; set; }
        public string nombre { get; set; }
        public decimal minimo { get; set; }
        public decimal maximo { get; set; }
        public bool status { get; set; }
    }
}
