﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.Configuracion.Maestros
{
    public class BERangoVariedad : BEMaster
    {
        public int empresaID { get; set; }
        public int variedadID { get; set; }
        public string empresa { get; set; }
        public string variedad { get; set; }
        public int minimo { get; set; }
        public int maximo { get; set; }
        public string calificacion { get; set; }
        public bool status { get; set; }
    }
}
