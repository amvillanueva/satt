﻿
namespace Agritracer.Domain.Configuracion.Maestros
{
    public class BETablaDetalle
    {
        public int detalleID { get; set; }
        public int maestraID { get; set; }
        public string detalleNombre { get; set; }
        public string detalleDescripcion { get; set; }
        public bool detalleStatus { get; set; }

        public string detalleUsuario { get; set; }
        public int detalleIDServidor { get; set; }
        public string detalleMsgServidor { get; set; }
    }
}
