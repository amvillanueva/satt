﻿using System.Collections.Generic;

namespace Agritracer.Domain.Configuracion.Maestros
{
    public class BETablaMaestra
    {
        public int maestraID { get; set; }
        public string maestraNombre { get; set; }
        public string maestraDescripcion { get; set; }
        public bool maestraStatus { get; set; }

        public string maestraUsuario { get; set; }
        public int maestraIdServidor { get; set; }
        public string maestraMsgServidor { get; set; }

        public List<BETablaDetalle> maestraDetalles { get; set; }
        public string maestraDetallesXML { get; set; }
    }
}
