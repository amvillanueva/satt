﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.Configuracion.Maestros
{
    public class BETrabajadorPersona : BEMaster
    {
        public int trabajadorID { get; set; }
        public int personaID { get; set; }
        public int empresaID { get; set; }
        public string empresaNombre { get; set; }
        public string legajo { get; set; }
        public int planillaID { get; set; }
        public string planillaCodigo { get; set; }
        public string planillaNombre { get; set; }
        public string fechaIngreso { get; set; }
        public string fechaCese { get; set; }
        public string motivoCese { get; set; }
        public bool esSupervisor { get; set; }
        public bool esEmpleado { get; set; }
        public string correo { get; set; }
        public string estado { get; set; }
        public bool status { get; set; }
    }
}
