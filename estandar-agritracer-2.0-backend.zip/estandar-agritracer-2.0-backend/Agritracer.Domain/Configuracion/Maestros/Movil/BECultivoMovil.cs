﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Configuracion.Maestros.Movil
{
    public class BECultivoMovil
    {
        public int cultivoID { get; set; }
        public string cultivoNombre { get; set; }
        public int empresaID { get; set; }
        public bool isMatvariedad { get; set; }
        public int empresaCultivoID { get; set; }
        public bool isCapturarPeso { get; set; }
        public bool isEnviarVehiculo { get; set; }
        public bool isNotificarLMR { get; set; }
        public bool isEnviarTrabajador { get; set; }
        public bool isCerrarLote { get; set; }
    }

}
