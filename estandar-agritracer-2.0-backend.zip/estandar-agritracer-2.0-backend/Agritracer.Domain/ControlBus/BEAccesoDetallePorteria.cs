﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.ControlBus
{
    public class BEAccesoDetallePorteria : BEMaster
    {
        public int controlaccesodetalleID { get; set; }
        public int controlaccesoID { get; set; }
        public string pasajeroDni { get; set; }
        public string pasajeroNombre { get; set; }
        public string pasajeroFecha { get; set; }
        public string pasajeroHora { get; set; }
    }
}
