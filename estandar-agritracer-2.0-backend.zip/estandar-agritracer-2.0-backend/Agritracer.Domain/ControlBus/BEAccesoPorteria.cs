﻿using Agritracer.Domain.Common;
using System.Collections.Generic;

namespace Agritracer.Domain.ControlBus
{
    public class BEAccesoPorteria : BEMaster
    {
        public int controlaccesoID { get; set; }
        public int tipoAccesoID { get; set; }
        public string tipoAccesoNombre { get; set; }
        public int puntoControlID { get; set; }
        public string puntoControlNombre { get; set; }
        public int vehiculoID { get; set; }
        public int motivoID { get; set; }
        public int choferID { get; set; }
        public int empresaID { get; set; }
        public string controlAccesoFecha { get; set; }
        public string controlAccesoHora { get; set; }
        public string vehiculoPlaca { get; set; }
        public string vehiculoTipo { get; set; }
        public string tipoServicio { get; set; }
        public string empresaNombre { get; set; }
        public string empresaRuc { get; set; }
        public string motivoNombre { get; set; }
        public string choferNombre { get; set; }
        public string choferDni { get; set; }
        public int nroPasajeros { get; set; }

        public List<BEAccesoDetallePorteria> detalle { get; set; }
    }
}
