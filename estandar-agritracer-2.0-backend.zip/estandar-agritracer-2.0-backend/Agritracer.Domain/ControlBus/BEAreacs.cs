﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.ControlBus
{
    public class BEArea : BEMaster
    {
        public int areaID { get; set; }
        public string areaCodigo { get; set; }
        public string areaNombre { get; set; }
    }
}
