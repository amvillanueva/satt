﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.ControlBus
{
    public class BECentroCosto : BEMaster
    {
        public int centroCostoID { get; set; }
        public int empresaID { get; set; }
        public string empresaNombre { get; set; }
        public int ubigeoID { get; set; }
        public string ubigeoNombre { get; set; }
        public int areaID { get; set; }
        public string areaNombre { get; set; }
        public int denominacionCecoID { get; set; }
        public string denominacionCecoNombre { get; set; }
        public string centroCostoCodigo { get; set; }
        public string centroCostoNombre { get; set; }
        public string centroCostoOrdenEstadistica { get; set; }
    }
}
