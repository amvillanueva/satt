﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.ControlBus
{
    public class BEChoferPorteria : BEMaster
    {
        public int choferID { get; set; }
        public int empresaID { get; set; }
        public string empresaNombre { get; set; }
        public string choferDni { get; set; }
        public string choferNombre { get; set; }
        public string choferLicenciaRevalidacion { get; set; }
    }
}
