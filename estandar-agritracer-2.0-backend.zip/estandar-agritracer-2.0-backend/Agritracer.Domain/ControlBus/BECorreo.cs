﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.ControlBus
{
    public class BECorreo : BEMaster
    {
        public int correoID { get; set; }
        public int tipoCorreoID { get; set; }
        public string tipoCorreoDescripcion { get; set; }
        public string correoUsuario { get; set; }
        public int correoOrdenID { get; set; }
        public string correoOrdenDescripcion { get; set; }
    }
}
