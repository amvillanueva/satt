﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.ControlBus
{
    public class BEDenominacionCeco : BEMaster
    {
        public int denominacionCecoID { get; set; }
        public int areaID { get; set; }
        public string areaNombre { get; set; }
        public string denominacionCecoNombre { get; set; }
    }
}
