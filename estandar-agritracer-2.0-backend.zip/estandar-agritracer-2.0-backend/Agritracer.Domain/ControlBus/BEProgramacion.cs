﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.ControlBus
{
    public class BEProgramacion : BEMaster
    {
        public int programacionConfiguracionID { get; set; }
        public int programacionID { get; set; }
        public int empresaID { get; set; }
        public string empresaNombre { get; set; }
        public int proveedorID { get; set; }
        public string proveedorNombre { get; set; }
        public int rutaID { get; set; }
        public string rutaDescripcion { get; set; }
        public int tipoBusID { get; set; }
        public string tipoBusNombre { get; set; }
        public int tarifaID { get; set; }
        public string tipoTarifaNombre { get; set; }
        public decimal progMontoTarifa { get; set; }
        public int tipoViajeID { get; set; }
        public string tipoViajeNombre { get; set; }
        public string progFecha { get; set; }
        public string progHoraPartida { get; set; }
        public string progHoraInicio { get; set; }
        public string progHoraRetorno { get; set; }
        public string progHoraFin { get; set; }
        public decimal progDuracion { get; set; }
        public int conductorID { get; set; }
        public string conductorNombreCompleto { get; set; }
        public int busID { get; set; }
        public string busPlaca { get; set; }
        public int progCantidad { get; set; }
        public int centroCostoID { get; set; }
        public string centroCostoCodigo { get; set; }
        public int ubigeoID { get; set; }
        public string ubigeoDescripcion { get; set; }
        public int tipoServicioID { get; set; }
        public string tipoServicioNombre { get; set; }
        public int grupoID { get; set; }
        public string grupoNombre { get; set; }
        public bool progDia1 { get; set; }
        public bool progDia2 { get; set; }
        public bool progDia3 { get; set; }
        public bool progDia4 { get; set; }
        public bool progDia5 { get; set; }
        public bool progDia6 { get; set; }
        public bool progDia7 { get; set; }
        public int progEstado { get; set; }
        public bool flagAutomatico { get; set; }

        public string progCorrelativo { get; set; }
        public int busRemplazoIdaID { get; set; }
        public int busRemplazoVueltaID { get; set; }
        public string busRemplazoPlaca { get; set; }
        public int busTransbordoIdaID { get; set; }
        public int busTransbordoVueltaID { get; set; }
        public string busTransbordoPlaca { get; set; }
        public string progEstadoNombre { get; set; }
        public string progObservacion { get; set; }
        public string progComentarioIda { get; set; }
        public string progComentarioVuelta { get; set; }

        public string progValidadoNombre { get; set; }
        public int progNroPasajerosIda { get; set; }
        public int progNroPasajerosVuelta { get; set; }
    }
}
