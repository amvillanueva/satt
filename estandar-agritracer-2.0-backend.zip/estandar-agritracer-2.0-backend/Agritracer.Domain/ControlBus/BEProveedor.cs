﻿using Agritracer.Domain.Common;
using Agritracer.Domain.Seguridad;
using System.Collections.Generic;

namespace Agritracer.Domain.ControlBus
{
    public class BEProveedor : BEMaster
    {
        public int proveedorID { get; set; }
        public int tipoServicioID { get; set; }
        public string tipoServicioNombre { get; set; }
        public string proveedorRazonSocial { get; set; }
        public string proveedorNombre { get; set; }
        public string proveedorRuc { get; set; }
        public string proveedorDireccion { get; set; }
        public string proveedorContacto { get; set; }
        public string proveedorTelefono { get; set; }
        public List<string> proveedorListaCorreos { get; set; }
        public List<BEUsuarioWeb> listaUsuarios { get; set; }
        public List<BEProveedorTarifa> listaTarifas { get; set; }
    }
}
