﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.ControlBus
{
    public class BEProveedorPorteria : BEMaster
    {
        public int empresaID { get; set; }
        public string empresaNombre { get; set; }
        public string empresaRuc { get; set; }
    }
}
