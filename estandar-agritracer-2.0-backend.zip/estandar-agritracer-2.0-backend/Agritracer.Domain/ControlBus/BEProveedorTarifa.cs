﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.ControlBus
{
    public class BEProveedorTarifa : BEMaster
    {
        public int proveedorTarifaID { get; set; }
        public int proveedorID { get; set; }
        public int tipoTarifaID { get; set; }
        public string tipoTarifaDescripcion { get; set; }
        public int tipoBusID { get; set; }
        public string tipoBusNombre { get; set; }
        public int proveedorTarifaNroViajes { get; set; }
        public int proveedorTarifaAnioFabricacion { get; set; }
    }
}
