﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.ControlBus
{
    public class BEPuntoControl : BEMaster
    {
        public int puntoControlID { get; set; }
        public string puntoControlNombre { get; set; }
        public string puntoControlReferencia { get; set; }
        public decimal puntoControlLatitud { get; set; }
        public decimal puntoControlLongitud { get; set; }
    }
}
