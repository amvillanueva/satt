﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.ControlBus
{
    public class BERestriccion : BEMaster
    {
        public int restriccionID { get; set; }
        public int empresaID { get; set; }
        public string trabajadorCodigo { get; set; }
        public string trabajadorNroDocumento { get; set; }
        public string restriccionDescripcion { get; set; }
    }
}
