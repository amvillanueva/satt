﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.ControlBus
{
    public class BERuta : BEMaster
    {
        public int rutaID { get; set; }
        public int empresaID { get; set; }
        public string empresaNombre { get; set; }
        public int origenID { get; set; }
        public string origenNombre { get; set; }
        public int destinoID { get; set; }
        public string destinoNombre { get; set; }
        public int zonaProcedenciaID { get; set; }
        public string zonaProcedenciaNombre { get; set; }
        public decimal rutaRecorrido { get; set; }
        public decimal rutaDuracion { get; set; }
    }
}
