﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.ControlBus
{
    public class BETarifa : BEMaster
    {
        public int tarifaID { get; set; }
        public int empresaID { get; set; }
        public string empresaNombre { get; set; }
        public int tipoServicioID { get; set; }
        public string tipoServicioNombre { get; set; }
        public int proveedorID { get; set; }
        public string proveedorNombre { get; set; }
        public int rutaID { get; set; }
        public string rutaDescripcion { get; set; }
        public int tipoBusID { get; set; }
        public string tipoBusNombre { get; set; }
        public int tipoTarifaID { get; set; }
        public string tipoTarifaDescripcion { get; set; }
        public decimal tarifaMonto { get; set; }
        public decimal tarifaMontoAnterior { get; set; }
    }
}
