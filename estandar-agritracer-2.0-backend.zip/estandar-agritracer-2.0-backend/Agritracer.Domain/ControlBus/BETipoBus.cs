﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.ControlBus
{
    public class BETipoBus : BEMaster
    {
        public int tipoBusID { get; set; }
        public string tipoBusNombre { get; set; }
    }
}
