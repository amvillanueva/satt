﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.ControlBus
{
    public class BEUbicacion : BEMaster
    {
        public int ubicacionID { get; set; }
        public string ubicacionNombre { get; set; }
        public string ubicacionReferencia { get; set; }
        public string ubicacionLatitud { get; set; }
        public string ubicacionLongitud { get; set; }
    }
}
