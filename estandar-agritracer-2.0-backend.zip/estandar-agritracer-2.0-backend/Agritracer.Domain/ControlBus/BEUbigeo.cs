﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.ControlBus
{
    public class BEUbigeo : BEMaster
    {
        public int ubigeoID { get; set; }
        public int empresaID { get; set; }
        public string empresaNombre { get; set; }
        public string ubigeoCodigo { get; set; }
        public string ubigeoNombre { get; set; }
    }
}
