﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.ControlBus
{
    public class BEVehiculoPorteria : BEMaster
    {
        public int vehiculoID { get; set; }
        public string vehiculoPlaca { get; set; }
        public int tipovehiculoID { get; set; }
        public int empresaID { get; set; }
        public int tiposervicioID { get; set; }
        public string revisionTecnica { get; set; }
        public string soat { get; set; }
        public string permisoCirculacion { get; set; }
        public string revisionTaller { get; set; }
        public string tipoNombre { get; set; }
        public string empresaNombre { get; set; }
        public string servicioNombre { get; set; }
    }
}
