﻿using Agritracer.Domain.Common;
using System.Collections.Generic;

namespace Agritracer.Domain.ControlBus
{
    public class BEViaje : BEMaster
    {
        public int viajeID { get; set; }
        public int programacionViajeID { get; set; }
        public int empresaID { get; set; }
        public string empresaRUC { get; set; }
        public string empresaNombre { get; set; }
        public string empresaDireccion { get; set; }
        public int proveedorID { get; set; }
        public string proveedorNombre { get; set; }
        public string proveedorRuc { get; set; }
        public int rutaID { get; set; }
        public string rutaDescripcion { get; set; }
        public int tipoBusID { get; set; }
        public string tipoBusNombre { get; set; }
        public int tarifaID { get; set; }
        public string tipoTarifaNombre { get; set; }
        public decimal viajeMontoTarifa { get; set; }
        public int tipoViajeID { get; set; }
        public string tipoViajeNombre { get; set; }
        public string viajeFecha { get; set; }
        public string viajeHoraPartida { get; set; }
        public string viajeHoraRetorno { get; set; }
        public string viajeHoraInicio { get; set; }
        public string viajeHoraFin { get; set; }
        public string viajeHoraInicioReal { get; set; }
        public string viajeHoraFinReal { get; set; }
        public decimal viajeDuracion { get; set; }
        public int conductorID { get; set; }
        public string conductorNombreCompleto { get; set; }
        public string conductorLicenciaConducir { get; set; }
        public int busID { get; set; }
        public string busPlaca { get; set; }
        public int centroCostoID { get; set; }
        public string centroCostoCodigo { get; set; }
        public string centroCostoDescripcion { get; set; }
        public int ubigeoID { get; set; }
        public string ubigeoCodigo { get; set; }
        public string ubigeoDescripcion { get; set; }
        public int tipoServicioID { get; set; }
        public string tipoServicioNombre { get; set; }
        public int grupoID { get; set; }
        public string grupoNombre { get; set; }
        public int viajeNroPasajerosIda { get; set; }
        public int viajeNroPasajerosVuelta { get; set; }
        public bool flagViajeManual { get; set; }
        public bool flagViajeValidado { get; set; }
        public bool flagViajeLiquidado { get; set; }
        public int busRemplazoID { get; set; }
        public int busTransbordoID { get; set; }
        public string viajeComentario { get; set; }
        public int viajeEstado { get; set; }
        public int usuarioID { get; set; }
        public string sedeLabores { get; set; }
        public string vigilante { get; set; }
        public List<BEViajeDetalle> detalle { get; set; }

        public string viajeCorrelativo { get; set; }
        public string viajeObservacion { get; set; }
        public string viajeComentarioIda { get; set; }
        public string viajeComentarioVuelta { get; set; }
        public int viajeNroPasajeros { get; set; }
        public bool sincronizadoIniciado { get; set; }
        public bool sincronizadoFinalizado { get; set; }
    }
}
