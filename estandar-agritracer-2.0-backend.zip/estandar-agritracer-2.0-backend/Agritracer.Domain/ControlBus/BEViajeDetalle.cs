﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.ControlBus
{
    public class BEViajeDetalle : BEMaster
    {
        public int viajeDetalleID { get; set; }
        public int viajeID { get; set; }
        public int empresaID { get; set; }
        public string empresaNombre { get; set; }
        public string trabajadorCodigo { get; set; }
        public string trabajadorNombreCompleto { get; set; }
        public string videHoraIngreso { get; set; }
        public string videHoraSalida { get; set; }
        public string trabajadorRestriccion { get; set; }
        public string videObservacion { get; set; }
        public int centroCostoID { get; set; }
        public string centroCostoCodigo { get; set; }
        public string centroCostoDescripcion { get; set; }
        public int areaID { get; set; }
        public string areaDescripcion { get; set; }
        public int usuarioID { get; set; }
        public string areaNombre { get; set; }
        public int tipoViajeID { get; set; }
        public bool videManual { get; set; }
    }
}
