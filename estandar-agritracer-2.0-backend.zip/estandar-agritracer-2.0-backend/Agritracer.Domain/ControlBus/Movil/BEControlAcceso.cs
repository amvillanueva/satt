﻿using Agritracer.Domain.Common;
using System.Collections.Generic;

namespace Agritracer.Domain.ControlBus.Movil
{
    public class BEControlAcceso : BEMaster
    {
        public int controlAccesoID { get; set; }
        public string placa { get; set; }
        public int empresaID { get; set; }
        public string empresaRUC { get; set; }
        public string empresaRazonSocial { get; set; }
        public int tipoServicioID { get; set; }
        public int tipoVehiculoID { get; set; }
        public string tipoVehiculoNombre { get; set; }
        public int tipoMotivoID { get; set; }
        public string tipoMotivoNombre { get; set; }
        public string dniConductor { get; set; }
        public string nombreConductor { get; set; }
        public string fechaHora { get; set; }
        public string horaIngreso { get; set; }
        public string horaSalida { get; set; }
        public int estado { get; set; }
        public int migrado { get; set; }
        public int puntoControlID { get; set; }
        public int tipoControlAccesoID { get; set; }
        public string tipoControlAccesoNombre { get; set; }
        public string usuario { get; set; }
        public List<BEControlAccesoDetalle> detalle { get; set; }
    }
}
