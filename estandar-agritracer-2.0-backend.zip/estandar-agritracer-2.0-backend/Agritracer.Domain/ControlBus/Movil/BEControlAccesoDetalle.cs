﻿namespace Agritracer.Domain.ControlBus.Movil
{
    public class BEControlAccesoDetalle
    {
        public int controlAccesoID { get; set; }
        public string dniPasajero { get; set; }
        public string nombrePasajero { get; set; }
        public string fechaHora { get; set; }
        public string horaIngreso { get; set; }
        public string horaSalida { get; set; }
        public int estado { get; set; }
        public string tipoPersona { get; set; }
    }
}
