﻿using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;

namespace Agritracer.Domain.ControlBus.Movil
{
    public class BEDataMaestra
    {
        public List<BEViaje> viajes { get; set; }
        public List<BEViajeDetalle> pasajeros { get; set; }
        public List<BEProveedor> proveedores { get; set; }
        public List<BEConductor> conductores { get; set; }
        public List<BETipoBus> tipoBuses { get; set; }
        public List<BEBus> buses { get; set; }
        public List<BEPuntoControl> puntoControles { get; set; }
        public List<BERestriccion> restricciones { get; set; }
        public List<BEViajeQR> viajesQR { get; set; }
        public List<BEViajeQRDetalle> viajeDetallesQR { get; set; }
        public List<BEEmpresa> empresa { get; set; }
        public List<BETipoVehiculo> tipoVehiculo { get; set; }
        public List<BEMotivo> motivo { get; set; }
        public List<BETipoServicio> tipoServicio { get; set; }

        public BEDataMaestra()
        {
            viajes = new List<BEViaje>();
            pasajeros = new List<BEViajeDetalle>();
            proveedores = new List<BEProveedor>();
            conductores = new List<BEConductor>();
            tipoBuses = new List<BETipoBus>();
            buses = new List<BEBus>();
            puntoControles = new List<BEPuntoControl>();
            restricciones = new List<BERestriccion>();
            viajesQR = new List<BEViajeQR>();
            viajeDetallesQR = new List<BEViajeQRDetalle>();
            empresa = new List<BEEmpresa>();
            tipoVehiculo = new List<BETipoVehiculo>();
            motivo = new List<BEMotivo>();
            tipoServicio = new List<BETipoServicio>();
        }
    }
}
