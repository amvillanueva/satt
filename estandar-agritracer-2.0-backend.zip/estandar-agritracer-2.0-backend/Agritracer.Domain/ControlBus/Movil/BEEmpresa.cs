﻿namespace Agritracer.Domain.ControlBus.Movil
{
    public class BEEmpresa
    {
        public int empresaID { get; set; }
        public string empresaRuc { get; set; }
        public string empresaNombre { get; set; }
    }
}
