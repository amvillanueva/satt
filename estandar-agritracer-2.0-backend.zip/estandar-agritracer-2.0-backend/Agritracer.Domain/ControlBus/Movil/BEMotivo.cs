﻿namespace Agritracer.Domain.ControlBus.Movil
{
    public class BEMotivo
    {
        public int motivoID { get; set; }
        public string motivoNombre { get; set; }
    }
}
