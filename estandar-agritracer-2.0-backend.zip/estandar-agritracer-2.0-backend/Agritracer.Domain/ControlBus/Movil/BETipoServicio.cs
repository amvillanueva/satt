﻿namespace Agritracer.Domain.ControlBus.Movil
{
    public class BETipoServicio
    {
        public int tipoServicioID { get; set; }
        public string tipoServicioNombre { get; set; }
    }
}
