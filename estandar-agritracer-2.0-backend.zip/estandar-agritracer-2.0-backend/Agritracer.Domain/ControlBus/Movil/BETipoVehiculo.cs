﻿namespace Agritracer.Domain.ControlBus.Movil
{
    public class BETipoVehiculo
    {
        public int tipoVehiculoID { get; set; }
        public string tipoVehiculoNombre { get; set; }
    }
}
