﻿namespace Agritracer.Domain.ControlBus.Movil
{
    public class BEVehiculo
    {
        public string placa { get; set; }
        public int empresaID { get; set; }
        public int tipoVehiculoID { get; set; }
        public int tipoServicioID { get; set; }
    }
}
