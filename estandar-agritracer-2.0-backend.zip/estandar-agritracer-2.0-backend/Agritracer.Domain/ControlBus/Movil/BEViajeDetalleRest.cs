﻿namespace Agritracer.Domain.ControlBus.Movil
{
    public class BEViajeDetalleRest
    {
        public int programacionViajeDetalleID { get; set; }
        public int empresaID { get; set; }
        public string trabajadorCodigo { get; set; }
        public string trabajadorNombre { get; set; }
        public string horaIngreso { get; set; }
        public string horaSalida { get; set; }
        public string restriccion { get; set; }
        public string observacion { get; set; }
        public int centroCostoID { get; set; }
        public int areaID { get; set; }
        public bool manual { get; set; }
    }
}
