﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.ControlBus.Movil
{
    public class BEViajeQR : BEMaster
    {
        public int viajeQrID { get; set; }
        public int viajeProgramacionDetalleID { get; set; }
        public int puntoControlID { get; set; }
        public string viajeQrCorrelativo { get; set; }
        public int empresaID { get; set; }
        public string empresaRUC { get; set; }
        public string empresaNombre { get; set; }
        public int rutaID { get; set; }
        public string rutaDescripcion { get; set; }
        public int proveedorID { get; set; }
        public string proveedorNombre { get; set; }
        public int tipoBusID { get; set; }
        public string tipoBusNombre { get; set; }
        public int busID { get; set; }
        public int conductorID { get; set; }
        public int busRemplazoID { get; set; }
        public int busTransbordoID { get; set; }
        public int tarifaID { get; set; }
        public string tipoTarifaNombre { get; set; }
        public double viajeQrMontoTarifa { get; set; }
        public string viajeQrFecha { get; set; }
        public string viajeQrHoraInicio { get; set; }
        public string viajeQrHoraFin { get; set; }
        public string viajeQrHoraInicioFinal { get; set; }
        public string viajeQrHoraFinFinal { get; set; }
        public int tipoViajeID { get; set; }
        public string tipoViajeNombre { get; set; }
        public int centroCostoID { get; set; }
        public string centroCostoCodigo { get; set; }
        public string centroCostoDescripcion { get; set; }
        public int ubigeoID { get; set; }
        public string ubigeoCodigo { get; set; }
        public string ubigeoDescripcion { get; set; }
        public int tipoServicioID { get; set; }
        public string tipoServicioNombre { get; set; }
        public int grupoID { get; set; }
        public string grupoNombre { get; set; }
        public string viajeQrObservacion { get; set; }
        public string viajeQrComentario { get; set; }
        public bool viajeQrValidado { get; set; }
        public string viajeQrCodigoMovil { get; set; }
        public int viajeQREstado { get; set; }
        public int viajeQRCantPasajeros { get; set; }
        public int usuarioID { get; set; }
    }
}
