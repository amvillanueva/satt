﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.ControlBus.Movil
{
    public class BEViajeQRDetalle : BEMaster
    {
        public int viajeQrDetalleID { get; set; }
        public int viajeQrID { get; set; }
        public int puntoControlID { get; set; }
        public int empresaID { get; set; }
        public string empresaNombre { get; set; }
        public string viqrdeTrabajadorCodigo { get; set; }
        public string viqrdeTrabajadorNombre { get; set; }
        public string viqrdeHoraIngreso { get; set; }
        public string viqrdeHoraSalida { get; set; }
        public string viqrdeRestriccion { get; set; }
        public string viqrdeObservacion { get; set; }
        public int centroCostoID { get; set; }
        public string centroCostoCodigo { get; set; }
        public string centroCostoDescripcion { get; set; }
        public int areaID { get; set; }
        public string areaDescripcion { get; set; }
        public bool viqrdeManual { get; set; }
        public int usuarioID { get; set; }
    }
}
