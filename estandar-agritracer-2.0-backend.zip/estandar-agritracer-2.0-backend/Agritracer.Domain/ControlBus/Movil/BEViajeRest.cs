﻿using Agritracer.Domain.Common;
using System.Collections.Generic;

namespace Agritracer.Domain.ControlBus.Movil
{
    public class BEViajeRest : BEMaster
    {
        public int programacionViajeID { get; set; }
        public int programacionViajeDetalleID { get; set; }
        public int puntoControlID { get; set; }
        public string correlativo { get; set; }
        public int empresaID { get; set; }
        public int rutaID { get; set; }
        public int proveedorID { get; set; }
        public int tipoBusID { get; set; }
        public int busID { get; set; }
        public int conductorID { get; set; }
        public int busRemplazoID { get; set; }
        public int busTransbordoID { get; set; }
        public int tarifaID { get; set; }
        public double montoTarifa { get; set; }
        public string fecha { get; set; }
        public string horaInicio { get; set; }
        public string horaFin { get; set; }
        public string horaInicioReal { get; set; }
        public string horaFinReal { get; set; }
        public int tipoViajeID { get; set; }
        public int centroCostoID { get; set; }
        public int ubigeoID { get; set; }
        public int tipoServicioID { get; set; }
        public int grupoID { get; set; }
        public string grupoNombre { get; set; }
        public string observacion { get; set; }
        public string comentario { get; set; }
        public bool validado { get; set; }
        public int estado { get; set; }
        public int usuarioID { get; set; }
        public List<BEViajeDetalleRest> pasajeros { get; set; }
    }
}
