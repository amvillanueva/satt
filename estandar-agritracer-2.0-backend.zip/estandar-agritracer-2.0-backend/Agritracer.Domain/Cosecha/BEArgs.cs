﻿using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;

namespace Agritracer.Domain.Maestros
{
    public class BEArgs : BEMaster
    {
        public int empresaID { get; set;}
        public int option { get; set; }
        public int valorID { get; set; }
        public DateTime? fecha { get; set; }
        public List<int> codigos { get; set; }
    }
}
