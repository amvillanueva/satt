﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.Cosecha.CierreLote.Movil
{
    public class BECierreLote : BEMaster
    {
        public int loteID { get; set; }
        public int turnoID { get; set; }
        public int moduloID { get; set; }
        public int variedadID { get; set; }
        public string loteNombre { get; set; }
        public string turnoNombre { get; set; }
        public string moduloNombre { get; set; }
        public string variedadDescripcion { get; set; }
        public string kiloBandeja { get; set; }
        public int estado { get; set; }
        public string estadoNombre { get; set; }
        public int grupoID { get; set; }
        public string grupoNombre { get; set; }
        public string fecha { get; set; }
        public double hectareas { get; set; }
        public string anotacion { get; set; }
        public int isaprobado { get; set; }
        public int usuarioMovilID { get; set; }
        public int supervisorID { get; set; }
        public string supervisorNombre { get; set; }
        public double turnoHectareas { get; set; }
        public double acumHectareas { get; set; }
    }
}
