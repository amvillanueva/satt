﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Cosecha.CierreLote.Movil
{
    public class BEFoto
    {
        public string imagenName { set; get; }
    }
}
