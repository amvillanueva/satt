﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Cosecha.CierreLote.Web
{
    public class BECierreLote
    {
        public int cierreTurnoID { get; set; }
        public int turnoID { get; set; }
        public int loteID { get; set; }
        public string fechaCierre { get; set; }
        public bool cierre { get; set; }
        public double hectareas { get; set; }
        public int usuarioID { get; set; }
    }
}
