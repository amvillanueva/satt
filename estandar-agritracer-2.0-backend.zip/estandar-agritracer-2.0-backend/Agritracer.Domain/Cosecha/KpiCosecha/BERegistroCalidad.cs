﻿using Agritracer.Domain.Common;
using System;

namespace Agritracer.Domain.Cosecha.KpiCosecha
{
    public class BERegistroCalidad : BEMaster
    {
        public string fecha { get; set; }

        public string hora { get; set; }

        public string zona { get; set; }

        public string modulo { get; set; }

        public string nombreLote { get; set; }

        public string grupo { get; set; }

        public decimal notaKpi { get; set; }

        public decimal indicadorQS { get; set; }

        public decimal frutosNoCosechados { get; set; }

        public decimal frutosCaidos { get; set; }

        public decimal frutosBuenosEnDescarte { get; set; }

        public int aprobado { get; set; }

    }
}
