﻿namespace Agritracer.Domain.Cosecha
{
    public class BEAlmacen
    {
        public int almacenID { get; set; }
        public int empresaID { get; set; }
        public string empresaNombreCorto { get; set; }
        public string almacenCodERP { get; set; }
        public string almacenDescripcion { get; set; }
        public bool almacenStatus { get; set; }
        public string almacenUsuario { get; set; }
        public int almacenIDServidor { get; set; }
        public string almacenMsgServidor { get; set; }
    }
}
