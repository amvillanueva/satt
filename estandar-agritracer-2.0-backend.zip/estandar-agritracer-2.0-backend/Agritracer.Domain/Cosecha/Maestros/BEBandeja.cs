﻿namespace Agritracer.Domain.Cosecha
{
    public class BEBandeja
    {
        public int bandejaID { get; set; }
        public string bandejaCodigo { get; set; }
        public string bandejaNombre { get; set; }
        public string bandejaAbreviatura { get; set; }
        public decimal bandejaPeso { get; set; }
        public bool bandejaCosechaDirecta { get; set; }
        public int cultivoID { get; set; }
        public int actividadID { get; set; }
        public int tipoCultivo { get; set; }
        public string cultivoNombre { get; set; }
        public bool bandejaStatus { get; set; }
        public string bandejaUsuario { get; set; }
        public int bandejaIDServidor { get; set; }
        public string bandejaMsgServidor { get; set; }
    }
}
