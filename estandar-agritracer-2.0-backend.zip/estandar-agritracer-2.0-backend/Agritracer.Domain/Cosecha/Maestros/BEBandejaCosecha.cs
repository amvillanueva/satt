﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.Cosecha.Maestros
{
    public class BEBandejaCosecha : BEMaster
    {
        public int bandejaCosechaID { get; set; }
        public string codigo { get; set; }
        public string nombre { get; set; }
        public string abreviatura { get; set; }
        public decimal peso { get; set; }
        public int directa { get; set; }
        public int granel { get; set; }
        public int bulk { get; set; }
        public int cultivoID { get; set; }
        public string cultivoNombre { get; set; }
        public bool status { get; set; }
    }
}
