﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Cosecha.Maestros
{
    public class BECampania
    {
        public int campaniaID { get; set; }
        public int fundoID { get; set; }
        public string fundoNombre { get; set; }
        public int moduloID { get; set; }
        public string moduloNombre { get; set; }
        public int cultivoID { get; set; }
        public string cultivoNombre { get; set; }
        public int variedadID { get; set; }
        public string variedadNombre { get; set; }
        public int materialVariedadID { get; set; }
        public string materialVariedadNombre { get; set; }
        public int campaniaNumero { get; set; }
        public float campaniaArea { get; set; }
        public string campaniaOP { get; set; }
        public int campaniaEtapa { get; set; }
        public string campaniaEtapaDescripcion { get; set; }
        public string campaniaFechaIni { get; set; }
        public string campaniaFechaCosecha { get; set; }
        public string campaniaFechaFin { get; set; }
        public bool campaniaEstado { get; set; }
        public bool campaniaCierre { get; set; }
        public bool campaniaStatus { get; set; }
        public string campaniaUsuario { get; set; }
        public int campaniaIDServidor { get; set; }
        public string campaniaMsgServidor { get; set; }
        public List<BECampania> lstHistorico { get; set; }
    }
}
