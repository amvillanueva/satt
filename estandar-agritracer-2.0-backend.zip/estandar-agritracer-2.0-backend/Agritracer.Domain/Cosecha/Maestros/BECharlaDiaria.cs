﻿using Agritracer.Domain.Common;
using System.Collections.Generic;

namespace Agritracer.Domain.Cosecha.Maestros
{
    public class BECharlaDiaria : BEMaster
    {
        public int charlaDiariaID { get; set; }
        public int idTipo { get; set; }
        public string nombreTipo { get; set; }
        public int anio { get; set; }
        public int semana { get; set; }
        public string dia { get; set; }
        public string fecha { get; set; }
        public string tema { get; set; }
        public int idEstado { get; set; }
        public string nombreEstado { get; set; }
    }
}
