﻿using Agritracer.Domain.Common;
using System.Collections.Generic;

namespace Agritracer.Domain.Cosecha.Maestros
{
    public class BECultivo : BEMaster
    {
        public int cultivoID { get; set; }
        public string cultivoNombre { get; set; }
        public bool cultivoFlagWeb {get; set;}
        public bool cultivoFlagMovil { get; set; }
        public bool cultivoFlagStickerGrupo { get; set; }
        public int cultivoProcesoImpresion { get; set; }
        public bool  cultivoStatus { get; set; }

        public IList<BEVariedad> cultivoVariedades { get; set; }
        public string cultivoVariedadesXML { get; set; }

        public string cultivoUsuario { get; set; }
        public int cultivoIDServidor { get; set; }
        public string cultivoMsgServidor { get; set; }
    }
}
