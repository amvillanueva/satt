﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Cosecha.Maestros
{
    public class BEEmpresaCultivo
    {
        public int empresaCultivoID { get; set; }
        public int cultivoID { get; set; }
        public string cultivoNombre { get; set; }
        public decimal cultivoPesoParihuela { get; set;}
        public bool cultivoCapturaPeso { get; set; }
        public bool cultivoCerrarLote { get; set; }
        public bool cultivoStickerGrupo { get; set; }
        public bool cultivoStickerTrabajador { get; set; }
    }
}
