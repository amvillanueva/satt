﻿namespace Agritracer.Domain.Cosecha
{
    public class BEFundo
    {
        public int fundoID { get; set; }
        public int empresaID { get; set; }
        public string empresaNombreCorto { get; set; }
        public int almacenID { get; set; }
        public string almacenDescripcion { get; set; }
        public string fundoNombre { get; set; }
        public string fundoUbicacion { get; set; }
        public double fundoArea { get; set; }
        public bool fundoViewWeb { get; set; }
        public bool fundoViewMovil { get; set; }
        public bool fundoStatus { get; set; }
        public string fundoUsuario { get; set; }
        public int fundoIDServidor { get; set; }
        public string fundoMsgServidor { get; set; }
    }
}
