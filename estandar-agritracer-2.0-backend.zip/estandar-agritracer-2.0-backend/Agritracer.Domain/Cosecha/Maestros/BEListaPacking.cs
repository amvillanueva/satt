﻿using System.Collections.Generic;

namespace Agritracer.Domain.Cosecha
{
    public class BEListaPacking
    {
        public int tablaDetalleID { get; set; }
        public int tablaMaestraID { get; set; }
        public string nombreTablaD { get; set; }
        public string descripcionTD { get; set; }
        public bool estado { get; set; }
    }
}
