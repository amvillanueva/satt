﻿using System.Collections.Generic;

namespace Agritracer.Domain.Cosecha
{
    public class BELote
    {
        public long loteID { get; set; }
        public long turnoID { get; set; }
        public int empresaID { get; set; }
        public string loteCodigo { get; set; }
        public string loteNombre { get; set; }
        public double loteArea { get; set; }
        public string loteDensidad { get; set; }
        public string loteFechaPlantacion { get; set; }
        public string loteSpaceAG { get; set; }
        public bool loteStatus { get; set; }
        public string loteUsuario { get; set; }
        public int loteIDServidor { get; set; }
        public string loteMsgServidor { get; set; }
        public List<BEVariedadLote> loteVariedades { get; set; }
    }
}
