﻿namespace Agritracer.Domain.Cosecha
{
    public class BEMaterialVariedad
    {
        public int materialVariedadID { get; set; }
        public int variedadID { get; set; }
        public string materialVariedadCodERP { get; set; }
        public string materialVariedadNombre     { get; set; }
        public bool materialVariedadGuia { get; set; }
        public bool materialVariedadCalidad { get; set; }
        public bool materialVariedadStatus { get; set; }
        public string materialVariedadUsuario { get; set; }
        public int materialVariedadIDServidor { get; set; }
        public string materialVariedadMsgServidor { get; set; }
    }
}
