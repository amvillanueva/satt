﻿using System.Collections.Generic;

namespace Agritracer.Domain.Cosecha
{
    public class BEModulo
    {
        public int moduloID { get; set; }
        public int fundoID { get; set; }
        public int empresaID { get; set; }
        public int zonaID { get; set; }
        public string moduloCodERP { get; set; }
        public string moduloCodigo { get; set; }
        public string moduloNombre { get; set; }
        public string moduloDescripcion { get; set; }
        public string moduloLugarProd { get; set; }
        public string moduloLetra { get; set; }
        public string moduloTipoBono { get; set; }
        public double moduloArea { get; set; }
        public int cecoID { get; set; }
        public string cecoDescripcion { get; set; }
        public bool moduloStatus { get; set; }
        public string moduloUsuario { get; set; }
        public int moduloIDServidor { get; set; }
        public string moduloMsgServidor { get; set; }
        public List<BETurno> moduloTurnos { get; set; }
        public string moduloTurnosStr { get; set; }
    }
}