﻿using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Cosecha.Maestros
{
    public class BEProductoVariedad : BEMaster
    {
        public int prvaID { get; set; }
        public int variedadID { get; set; }
        public string prvaCodigoERP { get; set; }
        public string prvaNombre { get; set; }
        public bool prvaFlagGuia { get; set; }
        public bool prvaFlagAgriQC { get; set; }
        public bool prvaFlagPorDefecto { get; set; }
    }
}
