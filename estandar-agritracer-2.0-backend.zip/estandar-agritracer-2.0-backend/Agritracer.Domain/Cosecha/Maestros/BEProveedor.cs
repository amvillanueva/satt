﻿using Agritracer.Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Cosecha.Maestros
{
    public class BEProveedor : BEMaster
    {
        public int proveedorID { get; set; }
        public string ruc { get; set; }
        public string nombre { get; set; }
        public string razonSocial { get; set; }
        public string direccion { get; set; }
        public string telefono { get; set; }
        public bool estado { get; set; }
}
}
