﻿using System.Collections.Generic;

namespace Agritracer.Domain.Cosecha
{
    public class BESupervisorCosecha
    {
        public string supervisorID { get; set; }
        public string supervisorDni { get; set; }
        public string supervisorNombres { get; set; }
        public string supervisorConcat { get; set; }
    }
}
