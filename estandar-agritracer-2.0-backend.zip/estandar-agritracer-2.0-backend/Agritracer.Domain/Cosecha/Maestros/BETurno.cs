﻿using System;
using System.Collections.Generic;

namespace Agritracer.Domain.Cosecha
{
    public class BETurno
    {
        public long turnoID { get; set; }
        public int moduloID { get; set; }
        public int empresaID { get; set; }
        public string turnoCodigo { get; set; }
        public string turnoNombre { get; set; }
        public string turnoArea { get; set; }
        public bool turnoStatus { get; set; }
        public string turnoUsuario { get; set; }
        public int turnoIDServidor { get; set; }
        public string turnoMsgServidor { get; set; }
        public List<BELote> turnoLotes { get; set; }
    }
}
