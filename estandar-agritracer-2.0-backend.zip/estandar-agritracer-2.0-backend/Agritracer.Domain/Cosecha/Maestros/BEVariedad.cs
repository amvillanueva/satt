﻿using Agritracer.Domain.Common;

namespace Agritracer.Domain.Cosecha
{
    public class BEVariedad : BEMaster
    {
        public int variedadID { get; set; }
        public int cultivoID { get; set; }
        public int loteID { get; set; }
        public string cultivoNombre { get; set; }
        public string variedadCodigo { get; set; }
        public string variedadNombre { get; set; }
        public bool variedadFlagWeb { get; set; }
        public bool variedadFlagMovil { get; set; }
        public bool variedadStatus { get; set; }
        public string variedadUsuario { get; set; }
        public int variedadIDServidor { get; set; }
        public string variedadMsgServidor { get; set; }
        public int moduloID { get; set; }
    }
}
