﻿namespace Agritracer.Domain.Cosecha
{
    public class BEVariedadLote
    {
        public long variedadloteID { get; set; }
        public int variedadID { get; set; }
        public int cultivoID { get; set; }
        public long loteID { get; set; }
        public bool variedadloteStatus { get; set; }
        public string variedadloteUsuario { get; set; }
        public int variedadloteIDServidor { get; set; }
        public string variedadloteMsgServidor { get; set; }
    }
}
