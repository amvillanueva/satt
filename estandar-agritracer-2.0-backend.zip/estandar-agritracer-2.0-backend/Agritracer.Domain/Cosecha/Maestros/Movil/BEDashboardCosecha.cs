﻿using System;

namespace Agritracer.Domain.Cosecha.Maestros.Movil
{
    public class BEDashboardCosecha
    {
        public String nombreTrabajador { get; set; }
        public String legajoTrabajador { get; set; }
        public String dnitrabajador { get; set; }
        public double bandejacosechaId { get; set; }
        public int vehiculoId { get; set; }
        public double totalKilos { get; set; }
        public double totalbandejaContabilizadas { get; set;}
        public double totalbandejasSumarizadas { get; set;}

        public int totalCantEnviadaDespachoCosecha { get; set; }
    }
}
