﻿using Agritracer.Domain.Acopio;
using Agritracer.Domain.Configuracion.Maestros.Movil;
using Agritracer.Domain.ManoObra.Maestros;
using Agritracer.Domain.ManoObra.Maestros.Movil;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Agritracer.Domain.Cosecha.Maestros.Movil
{
    public class BEDataMaestra
    {
        public List<BEFundo> fundos { get; set; }
        public List<BEModulo> modulos { get; set; }
        public List<BELoteMovil> lotes { get; set; }
        public List<BEBandeja> bandejas { get; set; }
        public List<BECultivoMovil> cultivos { get; set; }
        public List<BEZonaMovil> zonas { get; set; }
        public List<BEVehiculo> vehiculos { get; set; }

        //DESPACHO COSECHA ACOPIO
        public List<BEConductor> conductores { get; set; }
        public List<BEVehiculo> vehiculosAcopio { get; set; }
        public List<Domain.Acopio.BEDespachoCosecha> despachosCosecha { get; set; }
        public List<BEModulo> modulosAcopio { get; set; }
        public List<BETurno> turnos { get; set; }
        public List<BEVariedad> variedades { get; set; }
        public List<BETipoAcopio> tipoAcopios { get; set; }
        public List<Acopio.BEAcopio> acopios { get; set; }
        public List<BEBandejaCosecha> bandejasCosecha { get; set; }



        public BEDataMaestra()
        {

            conductores = new List<BEConductor>();
            vehiculosAcopio = new List<BEVehiculo>();
            despachosCosecha = new List<BEDespachoCosecha>();
            modulosAcopio = new List<BEModulo>();
            turnos = new List<BETurno>();
            variedades = new List<BEVariedad>();
            tipoAcopios = new List<BETipoAcopio>();
            acopios = new List<Acopio.BEAcopio>();
            bandejasCosecha = new List<BEBandejaCosecha>();




        }
    }

}
