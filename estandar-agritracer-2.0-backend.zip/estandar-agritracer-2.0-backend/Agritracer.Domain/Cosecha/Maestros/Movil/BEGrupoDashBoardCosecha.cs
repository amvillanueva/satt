﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Cosecha.Maestros.Movil
{
    public class BEGrupoDashBoardCosecha
    {
        public List<BEDashboardCosecha> dashboard { get; set; }
        public List<BEDashboardCosecha> detalle { get; set; }
        public Dictionary<String, Object> dashboardDescarte { get; set; }
        public List<BEDashboardCosecha> totaldespachoCosecha { get; set; }
    }
}
