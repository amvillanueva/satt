﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Cosecha.Maestros.Movil
{
    public class BELoteMovil
    {
        public int loteId { set; get; }
        public String loteCodigo { set; get; }
        public String loteNombre { set; get; }
        public double loteArea { set; get; }
        public int moduloId { set; get; }
        public int variedadId { set; get; }
        public String variedad { set; get; }
        public int cultivoId { set; get; }
        public int empresaId { set; get; }
        public int turnoId { set; get; }
        public string turnoNombre { set; get; }
        public double turnoArea { set; get; }

    }
}
