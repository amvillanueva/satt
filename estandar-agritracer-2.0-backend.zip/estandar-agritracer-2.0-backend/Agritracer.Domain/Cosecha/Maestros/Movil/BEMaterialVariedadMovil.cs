﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Cosecha.Maestros.Movil
{
    public class BEMaterialVariedadMovil
    {
        public int materiaVariedadID { get; set; }
        public string materialVariedadNombre { get; set; }
        public int variedadlID { get; set; }
    }
}
