﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Cosecha.Maestros.Movil
{
    public class BEParamsDespachoBandeja
    {
        public int vehiculoId { get; set; }
        public int grupoTrabajoId { get; set; }
        public int empresaId { get; set; }
        public int vehiculoUltimoViaje { get; set; }
        public int produccionId { get; set; }
        public int cultivoId { get; set; }
        public int fundoId { get; set; }
        public int moduloId { get; set; }
        public int turnoId { get; set; }
        public int loteId { get; set; }
        public int variedadId { get; set; }
        public int formatoBandejaId { get; set; }
        public int stockJabasGrupo { get; set; }
        public int nroJabasDespachar { get; set; }
        public double kiloDescarte { get; set; }
        public int userId { get; set; }
        public String imei { get; set; }
        public bool isCierreCarga { get; set; }
    }

}
