﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Cosecha.Maestros.Movil
{
    public class BEProduccionMovil
    {
        public int produccionServerId { set; get; }
        public String produccionServerMessage { set; get; }

        public int impresaionId { set; get; }
        public int empresaId { set; get; }
        public int fundoId { set; get; }
        public int moduloId { set; get; }
        public int loteId { set; get; }
        public int cultivoId { set; get; }
        public int variedadId { set; get; }
        public int tipoCultivo { set; get; }
        public int materialVariedad { set; get; }
        public int formatoId { set; get; }
        public int userId { set; get; }
        public int supervisorId { set; get; }
        public int grupoTrabajoId { set; get; }
        public DateTime fechaCaptura { set; get; }
        public String latitud { set; get; }
        public String longitud { set; get; }
        public String dnitrabajador { set; get; }
        public int contador { set; get; }
        public int estado { set; get; }
        public double peso { set; get; }
        public double cantidad { set; get; }
        public String observacion { set; get; }
        public String codeQr { set; get; }
        public bool isObservado { set; get; }
        public bool isPerdido { set; get; }
        public String imei { set; get; }
    }

}
