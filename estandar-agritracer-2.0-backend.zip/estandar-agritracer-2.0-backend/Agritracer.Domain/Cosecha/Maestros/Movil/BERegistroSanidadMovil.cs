﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Cosecha.Maestros.Movil
{
    public class BERegistroSanidadMovil
    {
        public int loteID { get; set; }
        public string lote { get; set; }
        public double dias { get; set; }
        public string fechaInicio { get; set; }
        public string fechaFin { get; set; }
    }
}
