﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Cosecha.Maestros.Movil
{
    public class BETipoCosechaMovil
    {
        public int tipoCosechaID { get; set; }
        public string tipoCosechaNombre { get; set; }
        public string tipoCosechaDescripcion { get; set; }
        public int empresaCultivoID { get; set; }
    }
}
