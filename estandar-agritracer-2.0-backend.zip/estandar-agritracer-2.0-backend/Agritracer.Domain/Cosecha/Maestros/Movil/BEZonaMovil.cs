﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Cosecha.Maestros.Movil
{
    public class BEZonaMovil
    {
        public int zonaID { get; set; }
        public string zonaNombre { get; set; }
    }
}
