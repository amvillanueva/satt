﻿using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;

namespace Agritracer.Domain.Cosecha.Procesos
{
    public class BEGuiaRemisionCampo
    {
        public long guiaremisioncampoID { get; set; }
        public string fechaDespacho { get; set; }
        public string numeroDespacho { get; set; }
        public int empresaID { get; set; }
        public string empresaNombre { get; set; }
        public int cultivoID { get; set; }
        public string cultivoNombre { get; set; }
        public string guiaremisioncamposerie { get; set; }
        public string guiaremisioncamponumero { get; set; }
        public int totalPallets { get; set; }
        public int totalBandejas { get; set; }
        public double pesoNeto { get; set; }
        public int clienteID { get; set; }
        public string clienteRUC { get; set; }
        public string clienteRazonSocial { get; set; }
        public string clienteDireccion { get; set; }
        public int transportistaID { get; set; }
        public string transportistaRazonSocial { get; set; }
        public string transportistaRUC { get; set; }
        public int conductorID { get; set; }
        public string conductorNombre { get; set; }
        public string conductorBrevete { get; set; }
        public int vehiculoID { get; set; }
        public string vehiculoPlaca { get; set; }
        public string vehiculoMarca { get; set; }
        public string vehiculoModelo { get; set; }
        public int motivoTrasladoID { get; set; }
        public string motivoTrasladoNombre { get; set; }
        public int fundoOrigenID { get; set; }
        public string fundoOrigenNombre { get; set; }
        public string fundoOrigenDireccion { get; set; }
        public string fechaTraslado { get; set; }
        public int cantidadParihuelas { get; set; }
        public bool guiaremisioncampoConfirmado { get; set; }
        public bool guiaremisioncampoImpreso { get; set; }
        public bool guiaremisioncampoStatus { get; set; }
        public string guiaremisioncampoUsuario { get; set; }
        public int guiaremisioncampoIDServidor { get; set; }
        public string guiaremisioncampoMsgServidor { get; set; }
        public List<BEGuiaRemisionCampoDetalle> guiaremisioncampoDetalles { get; set; }
        public List<BEGuiaRemisionCampoPallet> guiaremisioncampoPallets { get; set; }
        public string guiaremisioncampoDetallesStr { get; set; }
        public string guiaremisioncampoPalletsStr { get; set; }
    }
}
