﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Cosecha.Procesos
{
    public class BEGuiaRemisionCampoDetalle
    {
        public long guiaremisionDetalleID { get; set; }
        public int guiaremisionItem { get; set; }
        public int fundoID { get; set; }
        public string fundoNombre { get; set; }
        public int moduloID { get; set; }
        public string moduloNombre { get; set; }
        public int variedadID { get; set; }
        public string variedadNombre { get; set; }
        public int materialVariedadID { get; set; }
        public string materialVariedadNombre { get; set; }
        public decimal guiaremisionDetallePesoBruto { get; set; }
        public decimal guiaremisionDetallePesoNeto { get; set; }
        public int guiaremisionDetalleCantidad { get; set; }
        public bool guiaremisionDetalleStatus { get; set; }
        public string guiaremisionDetalleUsuario { get; set; }
    }
}
