﻿using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;

namespace Agritracer.Domain.Cosecha.Procesos
{
    public class BEGuiaRemisionCampoPallet
    {
        public long palletID { get; set; }
        public string fechaPallet { get; set; }
        public string barcodePallet { get; set; }
        public int acopioID { get; set; }
        public string acopioDescripcion { get; set; }
        public int empresaID { get; set; }
        public int cultivoID { get; set; }
        public decimal pesoNeto { get; set; }
        public int numeroBandejasPallet { get; set; }
        public bool palletStatus { get; set; }
        public List<BEGuiaRemisionCampoPalletDetalle> palletDetalles { get; set; }
        public string palletDetallesStr { get; set; }
    }
}
