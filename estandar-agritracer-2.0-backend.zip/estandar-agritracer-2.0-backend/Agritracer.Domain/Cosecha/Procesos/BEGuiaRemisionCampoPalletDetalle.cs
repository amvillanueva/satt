﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Cosecha.Procesos
{
    public class BEGuiaRemisionCampoPalletDetalle
    {
        public int itemPalletDetalle { get; set; }
        public string qrCodeDetalle { get; set; }
        public int fundoID { get; set; }
        public string fundoNombre { get; set; }
        public int moduloID { get; set; }
        public int turnoID { get; set; }
        public string turnoNombre { get; set; }
        public int variedadID { get; set; }
        public string variedadNombre { get; set; }
        public int materialVariedadID { get; set; }
        public string materialVariedadNombre { get; set; }
        public decimal pesoBrutoPalletDetalle { get; set; }
    }
}
