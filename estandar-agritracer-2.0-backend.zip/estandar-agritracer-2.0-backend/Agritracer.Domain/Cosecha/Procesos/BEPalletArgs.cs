﻿namespace Agritracer.Domain.Cosecha.Procesos
{
    public class BEPalletArgs
    {
        public string codigos { get; set; }
        public decimal pesoBruto { get; set; }
        public decimal pesoNeto { get; set; }
        public decimal pesoTara { get; set; }

        public int nroClamshells { get; set; }
        public int tipoBandejaID { get; set; }
        public int tipoClamshellID { get; set; }

        public bool flagMasivo { get; set; }

        public string userLogin { get; set; }
        public string hostName { get; set; }
    }
}
