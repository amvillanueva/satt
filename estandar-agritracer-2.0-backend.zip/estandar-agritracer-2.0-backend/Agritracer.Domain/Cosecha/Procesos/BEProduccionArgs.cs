﻿using System;

namespace Agritracer.Domain.Cosecha.Procesos
{
    public class BEProduccionArgs
    {
        public DateTime fecha { get; set; }
        public DateTime fechaIni { get; set; }
        public DateTime fechaFin { get; set; }

        public int empresaID { get; set; }
        public int cultivoID { get; set; }

        public int tipo { get; set; }

        public int usuarioID { get; set; }
        public string userLogin { get; set; }
        public string hostName { get; set; }

        public int transaccionIdServidor { get; set; }
        public string transaccionMsgServidor { get; set; }
    }
}
