﻿namespace Agritracer.Domain.Cosecha.Procesos
{
    public class BEProduccionCampo
    {
        public string fechaProduccion   { get; set; }

        public int produccionCampoID    { get; set; }
        public int impresionStickerID   { get; set; }

        public int empresaID    { get; set; }
        public int fundoID      { get; set; }
        public int moduloID     { get; set; }
        public int turnoID      { get; set; }
        public int loteID       { get; set; }

        public int supervisorID     { get; set; }
        public int grupoTrabajoID   { get; set; }
        public int usuarioMovilID   { get; set; }

        public int trabajadorID     { get; set; }
        public string dniTrabajador { get; set; }
        public string codigoTrabajador  { get; set; }
        public string codigoQR      { get; set; }

        public int cultivoID        { get; set; }
        public int vehiculoID       { get; set; }
        public int bandejaCosechaID { get; set; }
        public int productoVariedadID   { get; set; }
        public int cantidad         { get; set; }

        public string observacion   { get; set; }

        public int flagObservado    { get; set; }
        public int flagEstado       { get; set; }

        public string empresaNombre { get; set; }

        public string fundoNombre   { get; set; }

        public string moduloNombre  { get; set; }

        public string turnoCodigo   { get; set; }
        public string turnoNombre   { get; set; }

        public string loteCodigo    { get; set; }
        public string loteNombre    { get; set; }

        //--------------------------------------------
        public string codigos   { get; set; }
        public int flag         { get; set; }

        //--------------------------------------------

        public string userLogin     { get; set; }
        public string hostName      { get; set; }

        //---------------------------------------------

        public int transaccionIdServidor        { get; set; }
        public string transaccionMsgServidor    { get; set; }
    }
}
