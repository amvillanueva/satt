﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Cosecha.Procesos
{
    public class BEProduccionFirestore
    {
        public int bandejaId { get; set; }
        public string bandejaNombre { get; set; }
        public decimal cantidad { get; set; }
        public string[] cosechadores { get; set; }
        public int cultivoId { get; set; }
        public string cultivoNombre { get; set; }
        public int empresaId { get; set; }
        public string empresaNombre { get; set; }
        public int fechaRegistro { get; set; }
        public decimal fundoArea { get; set; }
        public int fundoId { get; set; }
        public string fundoNombre { get; set; }
        public string grupoCodigo { get; set; }
        public int grupoId { get; set; }
        public decimal kilos { get; set; }
        public decimal loteArea { get; set; }
        public int loteId { get; set; }
        public string loteNombre { get; set; }
        public decimal moduloArea { get; set; }
        public int moduloId { get; set; }
        public string moduloNombre { get; set; }
        public int moduloZona { get; set; }
        public int supervisorId { get; set; }
        public string supervisorLegajo { get; set; }
        public string supervisorNombre { get; set; }
        public int tipoCosecha { get; set; }
        public decimal turnoArea { get; set; }
        public int turnoId { get; set; }
        public string turnoNombre { get; set; }
        public int variedadId { get; set; }
        public string variedadNombre { get; set; }
    }
}
