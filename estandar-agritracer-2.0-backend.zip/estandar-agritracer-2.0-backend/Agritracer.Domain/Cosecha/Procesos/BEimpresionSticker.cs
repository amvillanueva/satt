﻿using Agritracer.Domain.Common;
using Agritracer.Domain.Common.Maestros;
using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;

namespace Agritracer.Domain.Cosecha.Procesos
{
    public class BEImpresionSticker : BEMaster
    {
        public long impresionStickerID { get; set; }
        public int cultivoID { get; set; }
        public string cultivoNombre { get; set; }
        public int empresaID { get; set; }
        public string empresaNombre { get; set; }
        public int grupoCosechaID { get; set; }
        public int grupoTrabajoID { get; set; }
        public string grupoCosechaCodigo { get; set; }
        public string grupoTrabajoCodigo { get; set; }
        public string grupoCosechaDescripcion { get; set; }
        public string grupoTrabajoNombre { get; set; }
        public int supervisorID { get; set; }
        public string supervisorDNI { get; set; }
        public string supervisorLegajo { get; set; }
        public string supervisorNombreCompleto { get; set; }
        public string impresionStickerFecha { get; set; }
        public int impresionStickerCantidad { get; set; }
        public int impresionStickerEstado { get; set; }
        public string impresionStickerJuliano { get; set; }
        public int bacoID { get; set; }
        public string bacoNombre { get; set; }
        public int zonaProcedenciaID { get; set; }
        public string zonaProcedenciaNombre { get; set; }
        public bool impresionStickerStatus { get; set; }
        public string impresionStickerUsuario { get; set; }
        public int impresionStickerIDServidor { get; set; }
        public string impresionStickerMsgServidor { get; set; }
        public List<BEimpresionStickerDetalle> impresionStickerDetalles { get; set; }
        public string impresionStickerDetallesStr { get; set; }
        public List<BETrabajador> grupoCosechaDetalle { get; set; }
        public int impresionStickerCantidadTrabajadores { get; set; }
    }
}
