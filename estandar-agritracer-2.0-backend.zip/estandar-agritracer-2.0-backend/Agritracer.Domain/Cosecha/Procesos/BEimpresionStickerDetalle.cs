﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Cosecha.Procesos
{
    public class BEimpresionStickerDetalle
    {
        public long impresionStickerDetaID { get; set; }
        public int trabajadorOrden { get; set; }
        public string trabajadorID { get; set; }
        public string trabajadorCodigo { get; set; }
        public string trabajadorNombre { get; set; }
        public string trabajadorConcat { get; set; }
        public int impresionStickerDetaCantidad { get; set; }
        public bool impresionStickerDetaImprimir { get; set; }
        public bool impresionStickerDetaImpreso { get; set; }
        public bool impresionStickerDetaReImpreso { get; set; }
        public bool impresionStickerDetaStatus { get; set; }
        public string impresionStickerDetaUsuario { get; set; }
        public List<BEimpresionStickerDetalleCont> impresionStickerDetaContadores { get; set; }
    }
}
