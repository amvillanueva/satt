﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agritracer.Domain.Cosecha.Procesos
{
    public class BEimpresionStickerDetalleCont
    {
        public long impresionStickerDetaContadorID { get; set; }
        public string trabajadorID { get; set; }
        public string trabajadorCodigo { get; set; }
        public string trabajadorNombre { get; set; }
        public string trabajadorConcat { get; set; }
        public int impresionStickerDetaContadorContador { get; set; }
        public int impresionStickerDetaContadorTotal { get; set; }
        public string impresionStickerDetaContadorBarcode { get; set; }
        public bool impresionStickerDetaContadorStatus { get; set; }
        public string impresionStickerDetaContadorFECHA { get; set; }
        public string impresionStickerDetaContadorEMPRESA { get; set; }
        public string impresionStickerDetaContadorTRABAJADOR { get; set; }
        public string impresionStickerDetaContadorTRABAJADORORD { get; set; }
        public string impresionStickerDetaContadorTRABAJADORNOM { get; set; }
    }
}
