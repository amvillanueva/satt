﻿using Agritracer.Domain.ManoObra.Maestros;
using System.Collections.Generic;

namespace Agritracer.Domain.Cosecha.Procesos
{
    public class BEImpresionStickerResumen
    {
        public long impresionStickerID { get; set; }
        public int cultivoID { get; set; }
        public int empresaID { get; set; }
        public bool impresionStickerStatus { get; set; }
    }
}
